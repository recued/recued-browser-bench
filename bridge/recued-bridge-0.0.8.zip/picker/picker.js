"use strict";(()=>{var _=`/* Recued canonical design tokens \u2014 D-174 P6 "near-monochrome ramp + one
 * accent + one danger". THE single source of truth for the colour system,
 * shared across every surface (webclient, Browser Bridge, dashboard,
 * marketplace). Previously this :root block was hand-copied into four
 * places and had drifted (the Bridge ran a divergent warm palette); this
 * file ends that.
 *
 * SOURCE OF TRUTH. Edit here, then run \`npm run -w @recued/ui-shared
 * generate:tokens\` to refresh \`tokens.generated.ts\` (the string form a
 * worker / JS surface inlines). A guard test fails CI if the two drift.
 *
 * Consume one of two ways:
 *   - file:   <link rel="stylesheet" href="tokens.css">  (static HTML
 *             surfaces copy this file into their build output)
 *   - string: import { THEME_TOKENS_CSS } from '@recued/ui-shared/theme'
 *             (SSR worker / JS injection \u2014 no extra request, no FOUC)
 *
 * Surface-LOCAL aliases (dashboard \`--accent-light\`, marketplace
 * \`--bg-card\`) stay in that surface's own CSS, layered AFTER this file.
 * The back-compat alias block below mirrors what ui-shared
 * \`PRIMITIVE_STYLES\` already injects so a surface linking only this file
 * still resolves legacy \`var(--fail)\` / \`var(--ok)\` references; that
 * duplication consolidates here over time. */

:root {
  /* Tell the UA to render native controls + CSS system colours
   * (ButtonText / ButtonFace / Canvas / form widgets / scrollbars) for the
   * ACTIVE theme. Without this a bare <button> resolves \`color: ButtonText\`
   * = black even on our dark surfaces, so its label is unreadable. Flipped
   * to \`dark\` in the dark blocks below. */
  color-scheme: light;
  /* Canonical D-174 tokens (light). */
  --bg: #f8fafc;
  --surface: #ffffff;
  --surface-sunk: #f4f6f8;
  --border: #e4e4e7;
  --border-strong: #d4d4d8;
  --fg-subtle: #a1a1aa;
  --fg-muted: #6f6f78;
  --fg: #27272a;
  --fg-strong: #18181b;
  --brand: #0e7490;
  --accent: #0e7490;
  --accent-weak: rgba(14, 116, 144, 0.10);
  --danger: #dc2626;
  --danger-weak: #fef2f2;
  --on-accent: #ffffff;
  --on-danger: #ffffff;

  /* Back-compat aliases \u2192 canonical. No new hues: success/warning carry
   * meaning by glyph + label + weight (D-174 / WCAG 1.4.1), so --ok/--warn
   * resolve to neutral surfaces, never a green/amber. */
  --bg-soft: var(--surface-sunk);
  --bg-elev: var(--surface);
  --surface-subtle: var(--surface-sunk);
  --border-subtle: var(--border);
  --muted: var(--fg-muted);
  --fail: var(--danger);
  --fail-soft: var(--danger-weak);
  --danger-bg: var(--danger-weak);
  --accent-soft: var(--accent-weak);
  --accent-bg: var(--accent-weak);
  --accent-fg: var(--on-accent);
  --ok: var(--fg);
  --ok-soft: var(--surface-sunk);
  --ok-subtle: var(--surface-sunk);
  --ok-bg: var(--surface-sunk);
  --ok-fg: var(--fg);
  --success: var(--ok);
  --warn: var(--fg);
  /* The name components actually use (about fifty places). Undefined, every
   * one fell back to its own literal amber in both themes, 2.8:1 on dark \u2014
   * against the rule above. Same neutral as --warn. */
  --warning: var(--warn);
  --warn-soft: var(--surface-sunk);
  --warn-bg: var(--surface-sunk);
  --muted-bg: var(--surface-sunk);
  --muted-fg: var(--fg-muted);
  --fail-subtle: var(--danger-weak);
  --accent-subtle: var(--accent-weak);
}

/* Dark palette. Two activation paths share the SAME values (kept in sync
 * by hand \u2014 CSS can't DRY across a media-query boundary):
 *   1. \`:root[data-theme="dark"]\` \u2014 the user pinned Dark via the in-app
 *      theme toggle. Wins regardless of OS preference.
 *   2. \`@media (prefers-color-scheme: dark) :root:not([data-theme])\` \u2014 the
 *      OS prefers dark AND the user hasn't pinned a theme (no data-theme
 *      attribute = "System"). Pinning Light sets \`data-theme="light"\`,
 *      which this \`:not([data-theme])\` excludes, so Light always wins. */
:root[data-theme="dark"] {
  color-scheme: dark;
  --bg: #09090b;
  --surface: #18181b;
  --surface-sunk: #242428;
  --border: #27272a;
  --border-strong: #3f3f46;
  --fg-subtle: #52525b;
  --fg-muted: #a1a1aa;
  --fg: #e4e4e7;
  --fg-strong: #fafafa;
  --accent: #22c1d6;
  --accent-weak: rgba(34, 193, 214, 0.15);
  --danger: #f87171;
  --danger-weak: rgba(248, 113, 113, 0.12);
  --on-accent: #061315;
  --on-danger: #18181b;
}

@media (prefers-color-scheme: dark) {
  :root:not([data-theme]) {
    color-scheme: dark;
    --bg: #09090b;
    --surface: #18181b;
    --surface-sunk: #242428;
    --border: #27272a;
    --border-strong: #3f3f46;
    --fg-subtle: #52525b;
    --fg-muted: #a1a1aa;
    --fg: #e4e4e7;
    --fg-strong: #fafafa;
    --accent: #22c1d6;
    --accent-weak: rgba(34, 193, 214, 0.15);
    --danger: #f87171;
    --danger-weak: rgba(248, 113, 113, 0.12);
    --on-accent: #061315;
    --on-danger: #18181b;
  }
}
`;var I=["data-test-id","data-testid","data-test","data-qa","data-cy","data-automation-id","data-automationid","data-component","data-tracking-id","data-name","data-id","data-key"],ee=["name","role","type","for"],N=[...I,"name","aria-label","role","type","placeholder","title","alt","for"],O=new Set([...I,...ee]),V=[/:r[0-9a-z]+:/i,/«r[0-9a-z]+»/i,/^css-[a-z0-9]{4,}$/i,/^sc-[a-zA-Z0-9]{4,}/,/^ember\d+$/i,/^mui-\d+$/i,/^radix-/i,/headlessui-/i,/_{2,}(?=[a-z0-9]{4,}$)[a-z0-9]*\d[a-z0-9]*$/i,/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}/i,/^[0-9a-f]{8,}$/i,/\d{6,}/],F=t=>V.some(e=>e.test(t)),ge={precedence:N,identifier_like:[...O],generated:V.map(t=>[t.source,t.flags]),max_value_chars:80,max_depth:8},te=/^-?[A-Za-z_][\w-]*$/,ne=t=>te.test(t),$=t=>t.replace(/\\/g,"\\\\").replace(/"/g,'\\"'),B=t=>t.length>0&&t.length<=80&&!/[\n\r\t]/.test(t)&&!t.includes("{{"),q=t=>{let e=t.id;return e.length===0||F(e)||e.includes("{{")?null:ne(e)?`#${e}`:B(e)?`${t.tag}[id="${$(e)}"]`:null},U=t=>{let e=new Map(t.attributes.map(([r,a])=>[r,a]));for(let r of N){let a=e.get(r);if(!(a===void 0||!B(a))&&!(O.has(r)&&F(a)))return`${t.tag}[${r}="${$(a)}"]`}return null},W=t=>q(t)??U(t),H=t=>W(t)??`${t.tag}:nth-of-type(${t.nthOfType})`,re=t=>q(t)!==null?"id":U(t)!==null?"attr":"positional",z=(t,e,r={})=>{let a=r.maxDepth??8,s=re(t),i=W(t);if(i!==null&&e(i)===1)return{selector:i,unique:!0,anchor:s};let d=[H(t)];{let p=d.join(" > ");if(e(p)===1)return{selector:p,unique:!0,anchor:s}}let f=t.parent,u=0;for(;f!==null&&u<a;){d.unshift(H(f));let p=d.join(" > ");if(e(p)===1)return{selector:p,unique:!0,anchor:s};f=f.parent,u+=1}let l=d.join(" > ");return{selector:l,unique:e(l)===1,anchor:s}},oe=t=>{let e=1,r=t.previousElementSibling;for(;r!==null;)r.tagName===t.tagName&&(e+=1),r=r.previousElementSibling;return e},S=t=>({tag:t.tagName.toLowerCase(),id:t.id??"",classes:Array.from(t.classList),attributes:Array.from(t.attributes).filter(e=>e.name!=="id"&&e.name!=="class"&&e.name!=="style").map(e=>[e.name.toLowerCase(),e.value]),get parent(){let e=t.parentElement;return e!==null?S(e):null},nthOfType:oe(t)});var ae=t=>t<0?"invalid selector":t===0?"no match":t===1?"1 match":`${t} matches`,ie=(t,e=140)=>{if(t===null)return null;let r=t.replace(/\s+/g," ").trim();return r.length<=e?r:`${r.slice(0,Math.max(0,e-1))}\u2026`},K=(t,e)=>{let r=e.trim();if(r==="")return{count:0,sample:null,summary:"empty selector",ok:!1};let a=t.count(r),s=a>0?ie(t.readText(r)):null;return{count:a,sample:s,summary:ae(a),ok:a===1}};var X="recued.bridge.picker.result",P=t=>{let e=t.trim();return e.length>0&&!e.includes("{{")};var j=(t,e,r=document)=>{if(r.documentElement.hasAttribute("data-recued-owner-surface")||e!==void 0&&location.href!==e)return{blocked:!0};let a=r.querySelector(t);if(!a)return{missing:!0};let s=a.localName;if(s!=="input"&&s!=="textarea"&&s!=="select")return{outputs:{text:a.innerText}};let i=a;return i.type==="password"||i.type==="hidden"||/(^|\s)(current-password|new-password|one-time-code|cc-\S+)(\s|$)/i.test(i.getAttribute("autocomplete")??"")?{protected:!0}:s==="select"?{outputs:{text:[...a.selectedOptions].map(d=>d.text).join(`
`)}}:i.type==="checkbox"||i.type==="radio"?{outputs:{text:String(i.checked)}}:{outputs:{text:i.value}}};var Y="__recued-element-picker",se="2147483647",le=_.replaceAll(':root[data-theme="dark"]',':host([data-theme="dark"])').replaceAll(":root:not([data-theme])",":host(:not([data-theme]))").replaceAll(":root {",":host {"),ce=`${le}
  :host {
    --picker-surface: var(--surface);
    --picker-surface-sunk: var(--surface-sunk);
    --picker-border: var(--border);
    --picker-border-strong: var(--border-strong);
    --picker-fg-muted: var(--fg-muted);
    --picker-fg: var(--fg);
    --picker-fg-strong: var(--fg-strong);
    --picker-accent: var(--accent);
    --picker-accent-weak: var(--accent-weak);
    --picker-danger: var(--danger);
    --picker-on-accent: var(--on-accent);
    all: initial !important;
    position: fixed !important;
    z-index: ${se} !important;
    top: 0 !important;
    left: 0 !important;
    width: 0 !important;
    height: 0 !important;
    display: block !important;
    pointer-events: none !important;
    color-scheme: light !important;
  }

  *, *::before, *::after {
    box-sizing: border-box;
  }

  .highlight {
    position: fixed;
    display: none;
    border: 2px solid var(--picker-accent);
    border-radius: 4px;
    background: var(--picker-accent-weak);
    pointer-events: none;
    transition: left 40ms ease-out, top 40ms ease-out, width 40ms ease-out,
      height 40ms ease-out;
  }

  .panel {
    position: fixed;
    right: 16px;
    bottom: 16px;
    width: 380px;
    max-width: calc(100vw - 32px);
    padding: 16px;
    border: 1px solid var(--picker-border);
    border-radius: 14px;
    background: var(--picker-surface);
    box-shadow: 0 18px 50px rgba(24, 24, 27, 0.22),
      0 2px 8px rgba(24, 24, 27, 0.08);
    color: var(--picker-fg);
    font: 13px/1.45 Inter, ui-sans-serif, system-ui, -apple-system,
      BlinkMacSystemFont, "Segoe UI", sans-serif;
    -webkit-font-smoothing: antialiased;
    pointer-events: auto;
  }

  .title {
    display: flex;
    align-items: center;
    gap: 10px;
    margin: 0 0 5px;
    color: var(--picker-fg-strong);
    font-size: 16px;
    font-weight: 750;
    letter-spacing: -0.025em;
    line-height: 1.2;
  }

  .title::before {
    width: 10px;
    height: 10px;
    flex: none;
    border-radius: 4px;
    background: var(--picker-accent);
    box-shadow: 0 0 0 5px var(--picker-accent-weak);
    content: "";
  }

  .hint {
    margin: 0 0 14px 20px;
    color: var(--picker-fg-muted);
    font-size: 12px;
  }

  .label {
    display: block;
    margin: 0 0 6px;
    color: var(--picker-fg);
    font-size: 12px;
    font-weight: 650;
  }

  .selector {
    display: block;
    width: 100%;
    min-height: 66px;
    padding: 10px 11px;
    resize: vertical;
    border: 1px solid var(--picker-border-strong);
    border-radius: 9px;
    outline: 0;
    background: var(--picker-surface-sunk);
    color: var(--picker-fg-strong);
    font: 12px/1.5 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas,
      monospace;
  }

  .selector::placeholder {
    color: var(--picker-fg-muted);
  }

  .selector:hover {
    border-color: var(--picker-fg-muted);
  }

  .selector:focus-visible {
    border-color: var(--picker-accent);
    box-shadow: 0 0 0 3px var(--picker-accent-weak);
  }

  .preview {
    min-height: 44px;
    margin: 10px 0 14px;
    padding: 9px 10px;
    border: 1px solid var(--picker-border);
    border-radius: 9px;
    background: var(--picker-surface-sunk);
    color: var(--picker-fg-muted);
    font-size: 12px;
  }

  .preview-summary {
    color: var(--picker-fg);
    font-weight: 650;
  }

  .preview-summary[data-tone="accent"] {
    color: var(--picker-accent);
  }

  .preview-summary[data-tone="danger"] {
    color: var(--picker-danger);
  }

  .preview-guidance,
  .preview-sample {
    color: var(--picker-fg-muted);
  }

  .preview-sample {
    margin-top: 4px;
    overflow-wrap: anywhere;
  }

  .actions {
    display: flex;
    justify-content: flex-end;
    gap: 8px;
  }

  .button {
    min-width: 82px;
    min-height: 38px;
    padding: 0 14px;
    border: 1px solid transparent;
    border-radius: 9px;
    outline: 0;
    font: 650 13px/1 Inter, ui-sans-serif, system-ui, -apple-system,
      BlinkMacSystemFont, "Segoe UI", sans-serif;
    cursor: pointer;
  }

  .button:focus-visible {
    box-shadow: 0 0 0 3px var(--picker-accent-weak);
  }

  .button-secondary {
    border-color: var(--picker-border-strong);
    background: var(--picker-surface);
    color: var(--picker-fg);
  }

  .button-secondary:hover {
    border-color: var(--picker-fg-muted);
    background: var(--picker-surface-sunk);
  }

  .button-primary {
    background: var(--picker-accent);
    color: var(--picker-on-accent);
  }

  .button-primary:hover:not(:disabled) {
    filter: brightness(0.94);
  }

  .button:disabled {
    cursor: not-allowed;
    opacity: 0.48;
  }

  @media (max-width: 440px) {
    .panel {
      right: 10px;
      bottom: 10px;
      left: 10px;
      width: auto;
      max-width: none;
    }

    .button {
      flex: 1;
    }
  }

  @media (prefers-color-scheme: dark) {
    :host(:not([data-theme])) {
      color-scheme: dark !important;
    }
  }

  @media (prefers-reduced-motion: reduce) {
    .highlight {
      transition: none;
    }
  }
`,ue=t=>{let e=a=>{try{return t.querySelectorAll(a).length}catch{return-1}};return{count:e,readText:a=>{try{let s=j(a,void 0,t);return"outputs"in s&&typeof s.outputs.text=="string"?s.outputs.text:null}catch{return null}},matchCount:e}},G=t=>{let e=t.doc??document,r=ue(e);e.getElementById(Y)?.remove();let a="hovering",s=!1,i=e.createElement("div");i.id=Y;let d=i.attachShadow({mode:"closed"}),f=e.createElement("style");f.textContent=ce,d.appendChild(f);let u=e.createElement("div");u.className="highlight",d.appendChild(u);let l=e.createElement("section");l.className="panel",l.setAttribute("role","dialog"),l.setAttribute("aria-modal","false"),l.setAttribute("aria-labelledby","__recued-picker-title"),l.setAttribute("aria-describedby","__recued-picker-hint"),d.appendChild(l);let p=e.createElement("h2");p.id="__recued-picker-title",p.className="title",p.textContent="Watch this element",l.appendChild(p);let b=e.createElement("p");b.id="__recued-picker-hint",b.className="hint",b.textContent="Hover the page and click the element to watch.",l.appendChild(b);let k=e.createElement("label");k.className="label",k.htmlFor="__recued-picker-selector",k.textContent="CSS selector",l.appendChild(k);let c=e.createElement("textarea");c.id="__recued-picker-selector",c.className="selector",c.rows=2,c.spellcheck=!1,c.autocapitalize="none",c.autocomplete="off",c.placeholder="Click an element\u2026",c.setAttribute("aria-describedby","__recued-picker-preview"),l.appendChild(c);let g=e.createElement("div");g.id="__recued-picker-preview",g.className="preview",g.setAttribute("role","status"),g.setAttribute("aria-live","polite"),g.textContent="Choose an element to preview its selector.",l.appendChild(g);let w=e.createElement("div");w.className="actions",l.appendChild(w);let M=(n,o)=>{let m=e.createElement("button");return m.type="button",m.textContent=n,m.className=`button ${o}`,m},R=M("Cancel","button-secondary"),v=M("Watch","button-primary");v.disabled=!0,w.appendChild(R),w.appendChild(v);let y=n=>{if(n===null){u.style.display="none";return}let o=n.getBoundingClientRect();u.style.display="block",u.style.left=`${o.left}px`,u.style.top=`${o.top}px`,u.style.width=`${o.width}px`,u.style.height=`${o.height}px`},Z=n=>{let o=e.createElement("span");o.className="preview-summary",o.dataset.tone=n.count<0?"danger":n.ok?"accent":"neutral",o.textContent=n.summary;let m=[o];if(n.count>1){let h=e.createElement("span");h.className="preview-guidance",h.textContent=" \u2014 tighten the selector to one element",m.push(h)}if(n.sample!==null){let h=e.createElement("div");h.className="preview-sample",h.textContent=`\u201C${n.sample}\u201D`,m.push(h)}g.replaceChildren(...m)},C=()=>{let n=c.value,o=K(r,n);if(Z(o),v.disabled=!P(n)||o.count<=0,o.count>0)try{y(e.querySelector(n.trim()))}catch{y(null)}else y(null)},J=n=>{a="selected";let o=z(S(n),r.matchCount);c.value=o.selector,b.textContent="Edit the selector if needed, then Watch. Click the page to pick again.",C(),c.focus({preventScroll:!0})},E=()=>{e.removeEventListener("mousemove",A,!0),e.removeEventListener("click",L,!0),e.removeEventListener("keydown",D,!0),i.remove()},Q=()=>{s||(s=!0,E())},x=n=>{s||(s=!0,E(),t.onResult(n))},T=()=>i.isConnected?!1:(E(),!0);function A(n){if(T()||a!=="hovering")return;let o=n.target;o===null||i.contains(o)||y(o)}function L(n){if(T()||!n.isTrusted)return;let o=n.target;o!==null&&i.contains(o)||(n.preventDefault(),n.stopPropagation(),typeof n.stopImmediatePropagation=="function"&&n.stopImmediatePropagation(),o!==null&&J(o))}function D(n){T()||n.isTrusted&&n.key==="Escape"&&(n.preventDefault(),n.stopPropagation(),x({status:"cancelled"}))}return R.addEventListener("click",n=>{n.isTrusted&&x({status:"cancelled"})}),v.addEventListener("click",n=>{if(!n.isTrusted)return;let o=c.value.trim();P(o)&&x({status:"picked",selector:o,page_url:e.location.href,sample_text:r.readText(o)})}),c.addEventListener("input",()=>{a="selected",C()}),e.addEventListener("mousemove",A,!0),e.addEventListener("click",L,!0),e.addEventListener("keydown",D,!0),(e.body??e.documentElement).appendChild(i),{destroy:Q}};var de=()=>{let t=globalThis;try{t.__recuedElementPickerHandle?.destroy()}catch{}let e=r=>{t.__recuedElementPickerHandle=void 0;let a=globalThis.chrome,s={type:X,result:r};try{let i=a?.runtime?.sendMessage?.(s);i&&typeof i.then=="function"&&i.catch(()=>{})}catch{}};t.__recuedElementPickerHandle=G({onResult:e})};de();})();
//# sourceMappingURL=picker.js.map
