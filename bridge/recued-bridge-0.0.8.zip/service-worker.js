var yh=new TextEncoder;var fi=["read","write","admin","destructive"];var bh=new Set(fi);var Sh=Object.freeze(Object.fromEntries(fi.map((e,t)=>[e,t]))),Rh=Object.freeze({read:"Read",write:"Write",admin:"Admin",destructive:"Destructive"});var hi=new Set(["http","dom","ai","chat","mcp","storage","connection","cli"]);var qn=["task","note","commitment","project","booking","asset"],Th=new Set(qn);var zd=["live","stale_unreachable","tombstoned","orphaned"],Ch=new Set(zd),Qd=["source_wins","recued_wins","manual_merge"],Ih=new Set(Qd),Jd=["low","medium","high"],kh=new Set(Jd);var Zd=["user_open","user_edit","recipe_query","ai_packet_inclusion","mcp_read"],vh=new Set(Zd),eu=["outbound","inbound","internal"],wh=new Set(eu),tu=["pending","fulfilled","cancelled","expired"],Oh=new Set(tu),nu=["not_due","due_soon","overdue","no_deadline"],xh=new Set(nu),ru=["strict_expire","escalate_overdue","indefinite"],Ph=new Set(ru),ou=["user_declared","mail_extracted","meeting_extracted","recipe_emitted","peer_received","evidence_captured","rule_emitted"],Nh=new Set(ou);var iu=["crm_field","mail","message"],Dh=new Set(iu),su=["crm_field"],Lh=new Set(su);var au=["mail","calendar","memory","engagement_email","engagement_meeting","engagement_note","engagement_call","engagement_task","engagement_event","engagement_email_message","engagement_voice_call","engagement_call_history"],Mh=new Set(au),Bh=8*1024,cu=["active","paused","completed","archived"],Uh=new Set(cu);var lu=["pending","confirmed","completed","cancelled","no_show"];var Fh=new Set(lu);var Kh=1440*60*1e3;var lt=["stripe.event.v1","paddle.notification.v1","lemonsqueezy.webhook.v1","slack.request.v0","slack.slash-command.v1","telegram.bot-webhook.v1","github.webhook.v1","cal.webhook.v1","generic.static-header-token.v1","generic.raw-body-hmac-sha256.v1","generic.timestamped-raw-body-hmac-sha256.v1","generic.http-basic.v1","recued-peer.exchange.v1"],bi=/^[a-z][a-z0-9_]{0,63}$/;var Si=/^[A-Za-z0-9][A-Za-z0-9._:/-]{0,127}$/,Ri=/^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)*\.v[0-9]+$/;var du=new Set(["__proto__","constructor","prototype"]),uu=e=>!du.has(e);var Kt={kind:"closed",values:["delivery"]},we=["test","live","custom"],Se=["application/json"],Vt=1080*60*60*1e3,qe={tombstone_horizon_ms:Vt,identity:{kind:"stable_provider_id"}},yi={tombstone_horizon_ms:Vt,identity:{kind:"stable_provider_id_or_signed_timestamp_body"}},Ht={tombstone_horizon_ms:Vt,identity:{kind:"received_at_body_window",window_ms:300*1e3}},pu={tombstone_horizon_ms:Vt,identity:{kind:"signed_timestamp_body"}},_u=[{profile_id:"stripe.event.v1",vendor:"stripe",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"provider_readback_required",decoder_kind:"json",decoded_schema_id:"stripe.event.v1",event_types:{kind:"open",known_values:["checkout.session.completed","customer.subscription.created","customer.subscription.deleted","customer.subscription.updated","invoice.paid","invoice.payment_failed"]},fields:[{key:"endpoint_secret",label:"Endpoint signing secret",kind:"secret",required:!0,source:"vendor_generated"}],registration_modes:["manual","managed_endpoint"],supported_environments:["test","live"],allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!0,handshakes:[]},{profile_id:"paddle.notification.v1",vendor:"paddle",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"paddle.notification.v1",event_types:{kind:"open",known_values:["address.created","address.imported","address.updated","adjustment.created","adjustment.updated","api_key.created","api_key.expired","api_key.expiring","api_key.revoked","api_key.updated","api_key_exposure.created","business.created","business.imported","business.updated","client_token.created","client_token.revoked","client_token.updated","customer.created","customer.imported","customer.updated","discount.created","discount.imported","discount.updated","discount_group.created","discount_group.updated","flow_session.abandoned","flow_session.completed","flow_session.created","funnel_session.abandoned","funnel_session.completed","funnel_session.created","invoice.canceled","invoice.issued","invoice.overdue","invoice.paid","payment_method.deleted","payment_method.saved","payout.created","payout.paid","price.created","price.imported","price.updated","product_collection.created","product_collection.updated","product.created","product.imported","product.updated","report.created","report.updated","subscription.activated","subscription.canceled","subscription.created","subscription.imported","subscription.past_due","subscription.paused","subscription.resumed","subscription.trialing","subscription.updated","transaction.billed","transaction.canceled","transaction.completed","transaction.created","transaction.paid","transaction.past_due","transaction.payment_failed","transaction.ready","transaction.revised","transaction.updated"]},fields:[{key:"endpoint_secret_key",label:"Endpoint secret key",kind:"secret",required:!0,source:"vendor_generated",help_url:"https://developer.paddle.com/webhooks/about/signature-verification/"}],registration_modes:["manual","managed_endpoint"],supported_environments:["test","live"],allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!0,handshakes:[]},{profile_id:"lemonsqueezy.webhook.v1",vendor:"lemonsqueezy",mechanism_kind:"raw_body_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"lemonsqueezy.webhook.v1",event_types:{kind:"open",known_values:["order_created","order_refunded","customer_updated","subscription_created","subscription_updated","subscription_cancelled","subscription_resumed","subscription_expired","subscription_paused","subscription_unpaused","subscription_payment_success","subscription_payment_failed","subscription_payment_recovered","subscription_payment_refunded","license_key_created","license_key_updated","affiliate_activated"]},fields:[{key:"signing_secret",label:"Signing secret",kind:"secret",required:!0,source:"owner",help_url:"https://docs.lemonsqueezy.com/help/webhooks/signing-requests"}],registration_modes:["manual"],supported_environments:["test","live"],allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:Ht,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"slack.request.v0",vendor:"slack",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"slack.request.v0",event_types:{kind:"open",known_values:["event_callback"]},fields:[{key:"signing_secret",label:"Signing secret",kind:"secret",required:!0,source:"vendor_generated"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:["application/json","application/x-www-form-urlencoded"],max_body_bytes:1048576,max_events_per_delivery:1,deduplication:yi,managed_registration_requires_connection:!1,handshakes:["slack_url_verification"]},{profile_id:"slack.slash-command.v1",vendor:"slack",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"form_urlencoded",decoded_schema_id:"slack.slash-command.v1",event_types:{kind:"closed",values:["slash_command"]},fields:[{key:"signing_secret",label:"Signing secret",kind:"secret",required:!0,source:"vendor_generated"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:["application/x-www-form-urlencoded"],max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"telegram.bot-webhook.v1",vendor:"telegram",mechanism_kind:"static_header_token",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"telegram.bot-update.v1",event_types:{kind:"open",known_values:["message","edited_message","callback_query"]},fields:[{key:"secret_token",label:"Webhook secret token",kind:"secret",required:!0,source:"recued_generated"}],registration_modes:["manual","managed_endpoint"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!0,handshakes:[]},{profile_id:"github.webhook.v1",vendor:"github",mechanism_kind:"raw_body_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"github.webhook.v1",event_types:{kind:"open",known_values:["check_run","check_suite","create","delete","deployment","deployment_status","discussion","discussion_comment","fork","issue_comment","issues","pull_request","pull_request_review","pull_request_review_comment","push","release","repository","status","workflow_job","workflow_run"]},fields:[{key:"webhook_secret",label:"Webhook secret",kind:"secret",required:!0,source:"recued_generated",help_url:"https://docs.github.com/en/webhooks/using-webhooks/validating-webhook-deliveries"}],registration_modes:["manual","managed_endpoint"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!0,handshakes:[]},{profile_id:"cal.webhook.v1",vendor:"cal.com",mechanism_kind:"raw_body_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"provider_readback_required",decoder_kind:"json",decoded_schema_id:"cal.webhook.v1",event_types:{kind:"closed",values:["RECORDING_TRANSCRIPTION_GENERATED","BOOKING_CANCELLED","BOOKING_RESCHEDULED","BOOKING_NO_SHOW_UPDATED","BOOKING_PAID"]},fields:[{key:"signing_secret",label:"Cal.com webhook signing secret",kind:"secret",required:!0,source:"owner",help_url:"https://cal.com/docs/developing/guides/automation/webhooks"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:qe,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"generic.static-header-token.v1",vendor:"generic",mechanism_kind:"static_header_token",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"generic.delivery.v1",event_types:Kt,fields:[{key:"header_name",label:"Header name",kind:"text",required:!0,source:"owner"},{key:"header_token",label:"Header token",kind:"secret",required:!0,source:"owner"}],registration_modes:["manual","operation_bound"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:Ht,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"generic.raw-body-hmac-sha256.v1",vendor:"generic",mechanism_kind:"raw_body_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"generic.delivery.v1",event_types:Kt,fields:[{key:"signature_header",label:"Signature header",kind:"text",required:!0,source:"owner"},{key:"signing_secret",label:"Signing secret",kind:"secret",required:!0,source:"owner"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:Ht,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"generic.timestamped-raw-body-hmac-sha256.v1",vendor:"generic",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"generic.delivery.v1",event_types:Kt,fields:[{key:"signature_header",label:"Timestamped signature header",kind:"text",required:!0,source:"owner"},{key:"signing_secret",label:"Signing secret",kind:"secret",required:!0,source:"owner"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:pu,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"generic.http-basic.v1",vendor:"generic",mechanism_kind:"http_basic",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"generic.delivery.v1",event_types:Kt,fields:[{key:"username",label:"Username",kind:"username",required:!0,source:"owner"},{key:"password",label:"Password",kind:"password",required:!0,source:"owner"}],registration_modes:["manual"],supported_environments:we,allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:Ht,managed_registration_requires_connection:!1,handshakes:[]},{profile_id:"recued-peer.exchange.v1",vendor:"recued",mechanism_kind:"timestamped_hmac",transport_assurance:"authenticated",minimum_source_truth_policy:"delivery_payload_allowed",decoder_kind:"json",decoded_schema_id:"recued-peer.exchange.v1",event_types:{kind:"open",known_values:["appointment.request","appointment.reply"]},fields:[{key:"signing_secret",label:"Peer signing secret",kind:"secret",required:!0,source:"recued_generated"}],registration_modes:["manual"],supported_environments:["test","live"],allowed_methods:["POST"],allowed_content_types:Se,max_body_bytes:1048576,max_events_per_delivery:1,deduplication:yi,managed_registration_requires_connection:!1,handshakes:[]}],mu=e=>Object.freeze({...e,event_types:e.event_types.kind==="closed"?Object.freeze({kind:"closed",values:Object.freeze([...e.event_types.values])}):Object.freeze({kind:"open",known_values:Object.freeze([...e.event_types.known_values])}),fields:Object.freeze(e.fields.map(t=>Object.freeze({...t}))),registration_modes:Object.freeze([...e.registration_modes]),supported_environments:Object.freeze([...e.supported_environments]),allowed_methods:Object.freeze([...e.allowed_methods]),allowed_content_types:Object.freeze([...e.allowed_content_types]),deduplication:Object.freeze({...e.deduplication,identity:Object.freeze({...e.deduplication.identity})}),handshakes:Object.freeze([...e.handshakes])}),Yn=Object.create(null);for(let e of _u){if(Object.prototype.hasOwnProperty.call(Yn,e.profile_id))throw new Error(`Duplicate D-201 webhook profile descriptor '${e.profile_id}'`);Yn[e.profile_id]=mu(e)}var dt=Object.freeze(Yn),Ai=(e=dt)=>{let t=[],n=new Set(lt);for(let r of lt)Object.prototype.hasOwnProperty.call(e,r)||t.push(`registry: missing required profile '${r}'`);for(let[r,o]of Object.entries(e)){let a=`profile '${r}'`;n.has(r)||t.push(`${a}: registry key is not in WEBHOOK_PROFILE_IDS`),o.profile_id!==r&&t.push(`${a}: profile_id must equal its registry key`),Ri.test(o.profile_id)||t.push(`${a}: profile_id has invalid shape`),o.transport_assurance==="notification_only"&&o.minimum_source_truth_policy!=="provider_readback_required"&&t.push(`${a}: notification_only profiles must require provider read-back`),o.transport_assurance==="notification_only"&&o.mechanism_kind!=="unauthenticated_pointer"&&t.push(`${a}: notification_only assurance requires unauthenticated_pointer mechanism_kind`),o.mechanism_kind==="unauthenticated_pointer"&&o.transport_assurance!=="notification_only"&&t.push(`${a}: unauthenticated_pointer mechanism_kind must be labelled notification_only`),o.vendor==="generic"&&o.transport_assurance==="notification_only"&&t.push(`${a}: generic profiles may not use notification_only assurance`);let i=o.event_types.kind==="closed"?o.event_types.values:o.event_types.known_values;o.event_types.kind==="closed"&&i.length===0&&t.push(`${a}: a closed event catalog must not be empty`);let s=new Set;for(let f of i)Si.test(f)||t.push(`${a}: invalid event type '${f}'`),s.has(f)&&t.push(`${a}: duplicate event type '${f}'`),s.add(f);o.vendor==="generic"&&(o.event_types.kind!=="closed"||o.event_types.values.length!==1||o.event_types.values[0]!=="delivery")&&t.push(`${a}: generic v1 profiles must expose only the closed 'delivery' event`),o.registration_modes.length===0&&t.push(`${a}: registration_modes must not be empty`),o.supported_environments.length===0&&t.push(`${a}: supported_environments must not be empty`),(o.allowed_methods.length===0||o.allowed_methods.some(f=>!/^[A-Z]+$/.test(f)))&&t.push(`${a}: allowed_methods must contain uppercase HTTP methods`),(!Number.isInteger(o.max_body_bytes)||o.max_body_bytes<=0)&&t.push(`${a}: max_body_bytes must be a positive integer`),(!Number.isInteger(o.max_events_per_delivery)||o.max_events_per_delivery<=0)&&t.push(`${a}: max_events_per_delivery must be a positive integer`);let c=o.deduplication;if(c==null||typeof c!="object"||!Number.isSafeInteger(c.tombstone_horizon_ms)||c.tombstone_horizon_ms<=0)t.push(`${a}: deduplication tombstone horizon must be a positive safe integer`);else{Object.keys(c).sort().join(",")!=="identity,tombstone_horizon_ms"&&t.push(`${a}: deduplication must contain only identity and tombstone_horizon_ms`);let f=c.identity;f==null||typeof f!="object"?t.push(`${a}: deduplication identity must be declared`):f.kind==="received_at_body_window"?(Object.keys(f).sort().join(",")!=="kind,window_ms"&&t.push(`${a}: received-at body identity must contain only kind and window_ms`),!Number.isSafeInteger(f.window_ms)||f.window_ms<=0?t.push(`${a}: received-at body identity window must be a positive safe integer`):f.window_ms>c.tombstone_horizon_ms&&t.push(`${a}: received-at body identity window must not outlive its tombstone horizon`)):f.kind!=="stable_provider_id"&&f.kind!=="stable_provider_id_or_signed_timestamp_body"&&f.kind!=="signed_timestamp_body"?t.push(`${a}: unsupported deduplication identity kind`):Object.keys(f).join(",")!=="kind"&&t.push(`${a}: stable or signed deduplication identity must contain only kind`)}o.managed_registration_requires_connection&&!o.registration_modes.some(f=>f!=="manual")&&t.push(`${a}: managed_registration_requires_connection needs a managed registration mode`);let d=new Set;for(let f of o.fields)(!bi.test(f.key)||!uu(f.key))&&t.push(`${a}: invalid or reserved field key '${f.key}'`),d.has(f.key)&&t.push(`${a}: duplicate field key '${f.key}'`),d.add(f.key)}return t},Ei=Ai();if(Ei.length>0)throw new Error(`Invalid D-201 webhook profile registry:
${Ei.join(`
`)}`);var ut=["notification","approval","messenger"];var gu=["inline","landing-page","notify-only"],Ti=new Set(gu);var jh=30*6e4;var Ci="email";var Oe=["slack","telegram","whatsapp","discord","teams"],Jn=["dm","group","channel","thread"],wi=new Set(Jn);var Gt=["webhook","socket","poll"],Qn=new Set(Gt);var Zn=["hmac","secret_token","ed25519"],Oi=new Set(Zn),er=["profile_email","none"],xi=new Set(er),tr=["bot_token","oauth","cloud_api"],Pi=new Set(tr),jt={bot_token:["bearer"],cloud_api:["bearer"],oauth:["oauth2_refresh"]},nr=["GET","POST"],Ni=new Set(nr),rr=["bearer_header","url_token","bot_header"],Di=new Set(rr),Xe="{token}",Ii=/^[a-z][a-z0-9_]*$/;function or(e){let t=[];if(e===null||typeof e!="object"||Array.isArray(e))return["expected object"];let n=e;if((typeof n.vendor!="string"||!Ii.test(n.vendor))&&t.push(`field 'vendor' must match ${Ii.source}`),(typeof n.display_name!="string"||n.display_name.length===0)&&t.push("field 'display_name' must be a non-empty string"),!Array.isArray(n.surfaces)||n.surfaces.length===0)t.push("field 'surfaces' must be a non-empty array");else{let r=new Set;n.surfaces.forEach((o,a)=>{typeof o!="string"||!wi.has(o)?t.push(`surfaces[${a}] must be one of ${Jn.join(" / ")}`):r.has(o)?t.push(`surfaces[${a}] duplicate surface '${o}'`):r.add(o)})}if(n.ingress===null||typeof n.ingress!="object"||Array.isArray(n.ingress))t.push("field 'ingress' must be an object");else{let r=n.ingress,o=typeof r.mode=="string"&&Qn.has(r.mode)?r.mode:null;o===null&&t.push(`ingress.mode must be one of ${Gt.join(" / ")}`);let a=Array.isArray(r.supported_modes)?r.supported_modes:null;if(a===null||a.length===0)t.push("ingress.supported_modes must be a non-empty array");else{let s=new Set;a.forEach((c,d)=>{typeof c!="string"||!Qn.has(c)?t.push(`ingress.supported_modes[${d}] must be one of ${Gt.join(" / ")}`):s.has(c)?t.push(`ingress.supported_modes[${d}] duplicate mode '${c}'`):s.add(c)}),o!==null&&!s.has(o)&&t.push("ingress.supported_modes must include ingress.mode")}if(a?.includes("webhook")===!0?((typeof r.verification!="string"||!Oi.has(r.verification))&&t.push(`ingress.verification must be one of ${Zn.join(" / ")} when webhook is supported`),(typeof r.secret_field!="string"||r.secret_field.length===0)&&t.push("ingress.secret_field must be a non-empty string when webhook is supported")):(r.verification!==void 0&&t.push("ingress.verification is only valid when webhook is supported"),r.secret_field!==void 0&&t.push("ingress.secret_field is only valid when webhook is supported")),(typeof r.id_field!="string"||r.id_field.length===0)&&t.push("ingress.id_field must be a non-empty string"),r.mode_roles!==void 0)if(r.mode_roles===null||typeof r.mode_roles!="object"||Array.isArray(r.mode_roles))t.push("ingress.mode_roles must be an object");else{let s=n.roles!==null&&typeof n.roles=="object"&&!Array.isArray(n.roles)?n.roles:null;for(let[c,d]of Object.entries(r.mode_roles)){if(a!==null&&!a.includes(c)){t.push(`ingress.mode_roles['${c}'] is not one of ingress.supported_modes`);continue}if(d===null||typeof d!="object"||Array.isArray(d)){t.push(`ingress.mode_roles['${c}'] must be an object`);continue}let f=Object.entries(d);f.length===0&&t.push(`ingress.mode_roles['${c}'] declares no narrowing \u2014 omit it instead`);for(let[u,m]of f)ut.includes(u)?typeof m!="boolean"?t.push(`ingress.mode_roles['${c}'].${u} must be a boolean`):m===!0&&s!==null&&s[u]!==!0?t.push(`ingress.mode_roles['${c}'].${u} may not grant a role absent from 'roles'`):m===!0&&t.push(`ingress.mode_roles['${c}'].${u} repeats the ceiling \u2014 narrowing only`):t.push(`ingress.mode_roles['${c}'].${u} is not a role axis`);s!==null&&ut.filter(m=>(d[m]??s[m])===!0).length===0&&t.push(`ingress.mode_roles['${c}'] leaves the mode with no role at all`)}}}if(n.recipient===null||typeof n.recipient!="object"||Array.isArray(n.recipient))t.push("field 'recipient' must be an object");else{let r=n.recipient;(typeof r.field!="string"||r.field.length===0)&&t.push("recipient.field must be a non-empty string"),typeof r.numeric_ok!="boolean"&&t.push("recipient.numeric_ok must be a boolean")}if(n.identity===null||typeof n.identity!="object"||Array.isArray(n.identity))t.push("field 'identity' must be an object");else{let r=n.identity;(typeof r.platform_id_source!="string"||!xi.has(r.platform_id_source))&&t.push(`identity.platform_id_source must be one of ${er.join(" / ")}`)}if(n.projection===null||typeof n.projection!="object"||Array.isArray(n.projection))t.push("field 'projection' must be an object");else{let r=n.projection;typeof r.structured_tags!="boolean"&&t.push("projection.structured_tags must be a boolean"),typeof r.structured_mentions!="boolean"&&t.push("projection.structured_mentions must be a boolean")}if((typeof n.auth!="string"||!Pi.has(n.auth))&&t.push(`field 'auth' must be one of ${tr.join(" / ")}`),n.roles===null||typeof n.roles!="object"||Array.isArray(n.roles))t.push("field 'roles' must be an object");else{let r=n.roles;for(let o of ut)typeof r[o]!="boolean"&&t.push(`roles.${o} must be a boolean`);r.notification===!1&&r.approval===!1&&r.messenger===!1&&t.push("field 'roles' declares no role at all \u2014 a vendor that can neither notify, approve, nor converse cannot do anything"),n.capability==="notify-only"&&r.approval===!0&&t.push("field 'capability' is 'notify-only' but roles.approval is true \u2014 you cannot approve where you cannot render; an ask fanned out here could never be answered")}if((typeof n.capability!="string"||!Ti.has(n.capability))&&t.push("field 'capability' must be a NotificationChannelCapability"),n.health_probe===null||typeof n.health_probe!="object"||Array.isArray(n.health_probe))t.push("field 'health_probe' must be an object");else{let r=n.health_probe,o=typeof r.url=="string"&&r.url.length>0?r.url:null;o===null&&t.push("health_probe.url must be a non-empty string"),(typeof r.method!="string"||!Ni.has(r.method))&&t.push(`health_probe.method must be one of ${nr.join(" / ")}`);let a=typeof r.auth=="string"&&Di.has(r.auth)?r.auth:null;if(a===null&&t.push(`health_probe.auth must be one of ${rr.join(" / ")}`),o!==null){let i=null;try{i=new URL(o.split(Xe).join("probe-token"))}catch{i=null}if(i===null?t.push("health_probe.url must be an absolute URL"):i.protocol!=="https:"&&t.push("health_probe.url must use https (the probe carries the vendor's credential)"),a!==null){let s=o.includes(Xe);a==="url_token"&&!s&&t.push(`health_probe.url must contain the ${Xe} placeholder when health_probe.auth is 'url_token' (else the probe would run unauthenticated)`),a==="bearer_header"&&s&&t.push(`health_probe.url must not contain the ${Xe} placeholder when health_probe.auth is 'bearer_header'`)}}}return t}function Li(e){let t=or(e);if(t.length>0)throw new Error(`invalid MessengerVendorDeclaration '${String(e.vendor)}': ${t.join("; ")}`)}function Ye(e){return Li(e),e}function Mi(e){let t=[],n=new Set;return e.forEach((r,o)=>{for(let a of or(r))t.push(`[${o}] ${a}`);n.has(r.vendor)?t.push(`[${o}] duplicate vendor '${r.vendor}' \u2014 only one entry per vendor allowed`):n.add(r.vendor)}),t}var Ne=[Ye({vendor:"slack",display_name:"Slack",surfaces:["dm","group","channel","thread"],ingress:{mode:"socket",supported_modes:["socket","webhook"],verification:"hmac",secret_field:"signing_secret",id_field:"event_id"},recipient:{field:"channel_id",numeric_ok:!1},identity:{platform_id_source:"profile_email"},projection:{structured_tags:!1,structured_mentions:!1},auth:"bot_token",roles:{notification:!0,approval:!0,messenger:!0},capability:"inline",health_probe:{url:"https://slack.com/api/auth.test",method:"POST",auth:"bearer_header"}}),Ye({vendor:"telegram",display_name:"Telegram",surfaces:["dm","group","channel"],ingress:{mode:"poll",supported_modes:["poll","webhook"],verification:"secret_token",secret_field:"webhook_secret",id_field:"update_id"},recipient:{field:"chat_id",numeric_ok:!0},identity:{platform_id_source:"none"},projection:{structured_tags:!1,structured_mentions:!1},auth:"bot_token",roles:{notification:!0,approval:!0,messenger:!0},capability:"inline",health_probe:{url:`https://api.telegram.org/bot${Xe}/getMe`,method:"GET",auth:"url_token"}}),Ye({vendor:"whatsapp",display_name:"WhatsApp Business API",surfaces:["dm"],ingress:{mode:"webhook",supported_modes:["webhook"],verification:"hmac",secret_field:"app_secret",id_field:"message_id"},recipient:{field:"wa_id",numeric_ok:!0},identity:{platform_id_source:"none"},projection:{structured_tags:!1,structured_mentions:!1},auth:"cloud_api",roles:{notification:!1,approval:!1,messenger:!0},capability:"inline",health_probe:{url:"https://graph.facebook.com/v22.0/me",method:"GET",auth:"bearer_header"}}),Ye({vendor:"discord",display_name:"Discord",surfaces:["dm","channel","thread"],ingress:{mode:"socket",supported_modes:["socket","webhook"],mode_roles:{webhook:{messenger:!1}},verification:"ed25519",secret_field:"public_key",id_field:"interaction_id"},recipient:{field:"channel_id",numeric_ok:!0},identity:{platform_id_source:"none"},projection:{structured_tags:!1,structured_mentions:!1},auth:"bot_token",roles:{notification:!0,approval:!0,messenger:!0},capability:"inline",health_probe:{url:"https://discord.com/api/v10/users/@me",method:"GET",auth:"bot_header"}}),Ye({vendor:"teams",display_name:"Microsoft Teams",surfaces:["dm"],ingress:{mode:"poll",supported_modes:["poll"],id_field:"message_id"},recipient:{field:"chat_id",numeric_ok:!1},identity:{platform_id_source:"none",principal_id_field:"id"},projection:{structured_tags:!1,structured_mentions:!1},auth:"oauth",roles:{notification:!0,approval:!0,messenger:!1},capability:"landing-page",health_probe:{url:"https://graph.microsoft.com/v1.0/me",method:"GET",auth:"bearer_header"},capability_probe:{url:"https://graph.microsoft.com/v1.0/me/chats?$top=1",refusal:"This looks like a personal Microsoft account. Teams messaging needs a work or school Microsoft 365 account \u2014 the kind you sign into at teams.microsoft.com rather than teams.live.com. Sign in with one of those and enrol again."}})],Bi=(e,t=Ne)=>{for(let n of t)if(n.vendor===e)return n;return null};var Ui=(e,t=Ne)=>typeof e=="string"&&Bi(e,t)!==null,Fi=[Ci];{let e=Fi.filter(t=>Ui(t));if(e.length>0)throw new Error(`MESSENGER_DOOR_VENDORS names a declared chat transport: ${e.join(", ")}`)}var ki=Mi(Ne);if(ki.length>0)throw new Error(`MESSENGER_VENDOR_DECLARATIONS boot validation failed: ${ki.join("; ")}`);var Ki=new Set(Ne.map(e=>e.vendor)),fu=new Set(Oe),Xn=Oe.filter(e=>!Ki.has(e)),zn=[...Ki].filter(e=>!fu.has(e));if(Xn.length>0||zn.length>0)throw new Error("messenger registry boot validation failed \u2014 MESSENGER_VENDOR_SLUGS and MESSENGER_VENDOR_DECLARATIONS disagree: "+[Xn.length>0?`slug(s) with no declaration: ${Xn.join(", ")}`:"",zn.length>0?`declaration(s) with no slug: ${zn.join(", ")}`:""].filter(Boolean).join("; "));var vi=Ne.filter(e=>jt[e.auth].length===0);if(vi.length>0)throw new Error("messenger registry boot validation failed \u2014 vendor(s) declared with a credential model the send path cannot deliver: "+vi.map(e=>`${e.vendor} (auth: '${e.auth}')`).join(", ")+". Wire the kind first \u2014 a deliverable shape in MESSENGER_AUTH_KIND_CONNECTION_TYPES, a token refresher for kind: 'notification', and an enroll card \u2014 or the connection would enroll, probe healthy, and then silently never deliver a single message.");var Qh=[...Oe,"email","in-app"];var Ie=e=>{if(typeof e!="string")return!1;let t=e.trim();if(!/^https:\/\//iu.test(t))return!1;try{let n=new URL(t);return n.protocol==="https:"&&n.hostname.length>0&&n.username.length===0&&n.password.length===0&&n.hash.length===0}catch{return!1}};var Hi=["none","bearer","basic","header","query","oauth2_refresh","managed_oauth","oauth2_client_credentials","atproto_session","request_signature","body_field"];var Jh=new Set(Object.values(jt).flat());var yu=new Set(["__proto__","constructor","prototype"]),Wt=32,Vi=e=>{let t=Gi(e,"header_name");return t.ok?{ok:!0,entries:t.entries.map(n=>({header_name:n.name,value:n.value}))}:t},Gi=(e,t)=>{if(!Array.isArray(e))return{ok:!1,issue:{code:"not_array"}};if(e.length===0)return{ok:!1,issue:{code:"empty"}};if(e.length>Wt)return{ok:!1,issue:{code:"too_many"}};let n=[];for(let r=0;r<e.length;r+=1){let o=e[r],a=typeof o=="object"&&o!==null&&!Array.isArray(o),i=d=>a&&Object.prototype.hasOwnProperty.call(o,d)?o[d]:void 0,s=i(t),c=i("value");if(typeof s!="string"||s.trim()==="")return{ok:!1,issue:{code:"name_missing",index:r}};if(yu.has(s))return{ok:!1,issue:{code:"name_reserved",index:r}};if(typeof c!="string"||c.trim()==="")return{ok:!1,issue:{code:"value_missing",index:r}};n.push({name:s,value:c})}return{ok:!0,entries:n}},ji=e=>{let t=Gi(e,"field_name");return t.ok?{ok:!0,entries:t.entries.map(n=>({field_name:n.name,value:n.value}))}:t};var Zh=5*6e4;var ey=900*1e3;var pt="https://login.microsoftonline.com/common/oauth2/v2.0/authorize",_t="https://login.microsoftonline.com/common/oauth2/v2.0/token";var ir="offline_access",sr="User.Read",Wi="Files.Read",$i="Sites.Read.All",qi="Files.ReadWrite",Yi="Sites.ReadWrite.All";var zi=["crm.objects.deals.read","crm.objects.contacts.read","crm.objects.companies.read","crm.schemas.deals.read","crm.schemas.contacts.read","crm.schemas.companies.read","oauth"],Qi="https://api.hubapi.com",Ji="https://app.hubspot.com/oauth/authorize",Zi="https://api.hubapi.com/oauth/v1/token",es="https://api.hubapi.com/oauth/v1/access-tokens",ts="X-HubSpot-Signature-v3",ns="6h",$t="v60.0",rs="https://login.salesforce.com/services/oauth2/authorize",os="https://login.salesforce.com/services/oauth2/token",is="https://test.salesforce.com/services/oauth2/authorize",ss="https://test.salesforce.com/services/oauth2/token",as=["api","refresh_token","offline_access"],cs="https://login.salesforce.com",ls="6h",ds="X-Salesforce-Streaming-CometD";var Eu=`/cometd/${$t}/`,bu=`/services/Soap/c/${$t}`,Su=$t.replace(/^v/,""),us=["base","deals:read","deals:full","contacts:read"],ps="https://api.pipedrive.com",_s="https://oauth.pipedrive.com/oauth/authorize",ms="https://oauth.pipedrive.com/oauth/token",gs="Authorization",fs="6h",hs=["task","event","email_message","voice_call","call_history"],ys=["task_relation","event_relation","email_message_relation"],Ru=[...hs,...ys];var Es=["com.intuit.quickbooks.accounting"],bs="https://appcenter.intuit.com/connect/oauth2",Ss="https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer",ar="https://quickbooks.api.intuit.com",Rs="https://sandbox-quickbooks.api.intuit.com",As="/v3/company/{realm_id}",Ts=`${ar}/v3/company/REALM_ID`,Cs="intuit-signature",Is="6h",ks=["https://www.googleapis.com/auth/drive.readonly","https://www.googleapis.com/auth/drive.file"],vs="https://accounts.google.com/o/oauth2/v2/auth",ws="https://oauth2.googleapis.com/token",Os="https://www.googleapis.com/drive/v3",xs={access_type:"offline",prompt:"consent"},Ps="x-goog-channel-token",Ns="6h",Ds=["account_info.read","files.metadata.read","files.content.read"],Ls="https://www.dropbox.com/oauth2/authorize",Ms="https://api.dropboxapi.com/oauth2/token",Bs="https://api.dropboxapi.com",Us={token_access_type:"offline"},Fs="X-Dropbox-Signature",Ks="6h",ze="https://graph.microsoft.com/v1.0",Hs=[Wi,qi,ir,sr],Vs="X-OneDrive-Unused-Webhook-Signature",Gs="6h",js="https://api.box.com/2.0",Ws=["root_readonly"],$s="https://account.box.com/api/oauth2/authorize",qs="https://api.box.com/oauth2/token",Ys="Box-Signature-Primary",Xs="6h",zs=[$i,Yi,ir,sr],Qs="X-SharePoint-Unused-Webhook-Signature",Js="6h";var Au=/^[a-z][a-z0-9_]*$/,Tu={vendor:"hubspot",display_name:"HubSpot",description:"CRM platform \u2014 deals, contacts, companies. A Service Key, or your own OAuth app.",default_base_url:Qi,also_accepts_auth:["bearer"],oauth:{authorize_url:Ji,token_endpoint:Zi,scopes:zi,client_secret_required:!0,access_token_introspect_url:es},webhook_signature_header:ts,default_cadence:ns},Cu={vendor:"salesforce",display_name:"Salesforce",description:"CRM platform \u2014 opportunities, contacts, accounts. OAuth + CometD streaming acceleration. Sandbox + production orgs.",default_base_url:cs,oauth:{authorize_url:rs,token_endpoint:os,sandbox_authorize_url:is,sandbox_token_endpoint:ss,scopes:as,client_secret_required:!0,supports_pkce:!0,runtime_base:{token_response_field:"instance_url",allowed_hostname_suffixes:["salesforce.com"]}},webhook_signature_header:ds,default_cadence:ls},Iu={vendor:"pipedrive",display_name:"Pipedrive",description:"CRM platform \u2014 deals, people, and organizations. OAuth 2.0 via your own Pipedrive app; catalog-backed reads and approval-gated deal creation.",default_base_url:ps,oauth:{authorize_url:_s,token_endpoint:ms,scopes:us,client_secret_required:!0,token_auth_style:"basic",runtime_base:{token_response_field:"api_domain",allowed_hostname_suffixes:["pipedrive.com"]}},webhook_signature_header:gs,default_cadence:fs},ku={vendor:"quickbooks",display_name:"QuickBooks Online",description:"Accounting & bookkeeping \u2014 invoices, bills, expenses, payments, customers, vendors, chart of accounts. OAuth 2.0 via your own Intuit app; per-company realm. Reads live-verified (sandbox).",default_base_url:Ts,oauth:{authorize_url:bs,token_endpoint:Ss,scopes:Es,client_secret_required:!0},realm_base:{production:ar,sandbox:Rs,path_template:As},webhook_signature_header:Cs,default_cadence:Is},vu={vendor:"google",display_name:"Google Drive",description:"Cloud file storage \u2014 list, read, and download documents from a Drive folder (e.g. a receipts/invoices folder); uploads ask. OAuth 2.0 via your own Google Cloud app.",default_base_url:Os,oauth:{authorize_url:vs,token_endpoint:ws,scopes:ks,client_secret_required:!0,authorize_params:xs,supports_pkce:!0},webhook_signature_header:Ps,default_cadence:Ns},wu={vendor:"dropbox",display_name:"Dropbox",description:"Cloud file storage \u2014 mirror file/folder metadata into your warehouse; file bytes stay remote and are fetched only for an explicit read. The app pack adds approval-gated organize actions. OAuth 2.0 via your own Dropbox app.",default_base_url:Bs,oauth:{authorize_url:Ls,token_endpoint:Ms,scopes:Ds,client_secret_required:!0,authorize_params:Us,supports_pkce:!0},webhook_signature_header:Fs,default_cadence:Ks},Ou={vendor:"onedrive",display_name:"OneDrive",description:"Cloud file storage \u2014 mirror file/folder metadata into your warehouse via Microsoft Graph; file bytes stay remote and are fetched only for an explicit read. OAuth 2.0 via your own Microsoft Entra app.",default_base_url:ze,oauth:{authorize_url:pt,token_endpoint:_t,scopes:Hs,client_secret_required:!0,supports_pkce:!0},webhook_signature_header:Vs,default_cadence:Gs},xu={vendor:"box",display_name:"Box",description:"Cloud file storage \u2014 mirror file/folder metadata into your warehouse via the Box events + folders API; file bytes stay remote and are fetched only for an explicit read. OAuth 2.0 via your own Box app.",default_base_url:js,oauth:{authorize_url:$s,token_endpoint:qs,scopes:Ws,client_secret_required:!0,supports_pkce:!0},webhook_signature_header:Ys,default_cadence:Xs},Pu={vendor:"sharepoint",display_name:"SharePoint",description:"SharePoint document libraries \u2014 mirror file/folder metadata into your warehouse via Microsoft Graph; file bytes stay remote and are fetched only for an explicit read. Point it at a document library drive. OAuth 2.0 via your own Microsoft Entra app.",default_base_url:ze,oauth:{authorize_url:pt,token_endpoint:_t,scopes:zs,client_secret_required:!0,supports_pkce:!0},webhook_signature_header:Qs,default_cadence:Js},Zs=[Tu,Cu,Iu,ku,vu,wu,Ou,xu,Pu];var ea=e=>{let t=[];Au.test(e.vendor)||t.push(`vendor must match /^[a-z][a-z0-9_]*$/: '${e.vendor}'`),(typeof e.display_name!="string"||e.display_name.length===0)&&t.push("display_name must be non-empty"),(typeof e.description!="string"||e.description.length===0)&&t.push("description must be non-empty"),e.default_base_url.startsWith("https://")||t.push(`default_base_url must be https://: '${e.default_base_url}'`),Ie(e.oauth.authorize_url)||t.push("oauth.authorize_url must be a complete HTTPS URL with no embedded username or password and no URL fragment"),Ie(e.oauth.token_endpoint)||t.push("oauth.token_endpoint must be a complete HTTPS URL with no embedded username or password and no URL fragment"),e.oauth.scopes.length===0&&t.push("oauth.scopes must be non-empty");for(let o of e.oauth.scopes)if(typeof o!="string"||o.length===0){t.push("oauth.scopes entries must be non-empty strings");break}e.oauth.access_token_introspect_url!==void 0&&!Ie(e.oauth.access_token_introspect_url)&&t.push("oauth.access_token_introspect_url must be a complete HTTPS URL with no embedded username or password and no URL fragment"),e.oauth.token_auth_style!==void 0&&e.oauth.token_auth_style!=="body"&&e.oauth.token_auth_style!=="basic"&&t.push(`oauth.token_auth_style must be 'body' | 'basic': '${e.oauth.token_auth_style}'`);let n=e.oauth.sandbox_authorize_url!==void 0,r=e.oauth.sandbox_token_endpoint!==void 0;if(n!==r&&t.push("oauth.sandbox_authorize_url and oauth.sandbox_token_endpoint must be set together (both or neither)"),e.oauth.sandbox_authorize_url!==void 0&&!Ie(e.oauth.sandbox_authorize_url)&&t.push("oauth.sandbox_authorize_url must be a complete HTTPS URL with no embedded username or password and no URL fragment"),e.oauth.sandbox_token_endpoint!==void 0&&!Ie(e.oauth.sandbox_token_endpoint)&&t.push("oauth.sandbox_token_endpoint must be a complete HTTPS URL with no embedded username or password and no URL fragment"),e.oauth.runtime_base!==void 0){let o=e.oauth.runtime_base;if(o.token_response_field!=="instance_url"&&o.token_response_field!=="api_domain"&&t.push("oauth.runtime_base.token_response_field must be 'instance_url' | 'api_domain'"),!Array.isArray(o.allowed_hostname_suffixes)||o.allowed_hostname_suffixes.length===0)t.push("oauth.runtime_base.allowed_hostname_suffixes must be a non-empty array");else{let a=new Set;for(let i of o.allowed_hostname_suffixes){if(typeof i!="string"||i!==i.toLowerCase()||!/^[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/.test(i)||i.includes("..")){t.push("oauth.runtime_base.allowed_hostname_suffixes entries must be lowercase DNS suffixes");break}if(a.has(i)){t.push("oauth.runtime_base.allowed_hostname_suffixes entries must be unique");break}a.add(i)}}}if(e.webhook_signature_header.length===0&&t.push("webhook_signature_header must be non-empty"),e.default_cadence!=="1h"&&e.default_cadence!=="6h"&&e.default_cadence!=="24h"&&t.push(`default_cadence must be one of '1h' | '6h' | '24h': '${e.default_cadence}'`),e.realm_base!==void 0){let o=e.realm_base;(typeof o.production!="string"||!o.production.startsWith("https://"))&&t.push(`realm_base.production must be https://: '${o.production}'`),(typeof o.sandbox!="string"||!o.sandbox.startsWith("https://"))&&t.push(`realm_base.sandbox must be https://: '${o.sandbox}'`),(typeof o.path_template!="string"||!o.path_template.includes("{realm_id}"))&&t.push(`realm_base.path_template must contain the {realm_id} placeholder: '${o.path_template}'`)}if(e.oauth.authorize_params!==void 0)for(let[o,a]of Object.entries(e.oauth.authorize_params))qt.has(o)&&t.push(`oauth.authorize_params may not override the reserved key '${o}'`),(typeof a!="string"||a.length===0)&&t.push(`oauth.authorize_params['${o}'] must be a non-empty string`);return t},qt=new Set(["response_type","client_id","redirect_uri","scope","state","code_challenge","code_challenge_method"]);var ta=e=>{let t=[],n=new Set;for(let r of e){let o=ea(r);for(let a of o)t.push(`${r.vendor}: ${a}`);n.has(r.vendor)?t.push(`duplicate vendor segment: '${r.vendor}'`):n.add(r.vendor)}return t},Xi=ta(Zs);if(Xi.length>0)throw new Error(`CONNECTION_VENDOR_PROVIDERS boot validation failed: ${Xi.join("; ")}`);var sy=new TextEncoder;var cr=["binance_hmac_sha256"],na=e=>typeof e=="string"&&cr.includes(e);var lr=Hi.filter(e=>e!=="managed_oauth");var ra=/^[a-z][a-z0-9_]*$/,Du=e=>e!=null&&typeof e=="object"&&!Array.isArray(e)&&Object.values(e).every(t=>typeof t=="string"),Lu=e=>{switch(e.code){case"not_array":return"auth.header_names must be a non-empty array of non-empty strings";case"empty":return"auth.header_names must be a non-empty array of non-empty strings";case"too_many":return`auth.header_names may contain at most ${Wt} entries`;case"name_missing":return`auth.header_names[${e.index}] must be a non-empty string`;case"name_reserved":return`auth.header_names[${e.index}] must not be a reserved object key (__proto__ / constructor / prototype)`;case"value_missing":return`auth.header_names[${e.index}] is invalid`}},Mu=e=>{switch(e.code){case"not_array":case"empty":return"auth.field_names must be a non-empty array of non-empty strings";case"too_many":return`auth.field_names may contain at most ${Wt} entries`;case"name_missing":return`auth.field_names[${e.index}] must be a non-empty string`;case"name_reserved":return`auth.field_names[${e.index}] must not be a reserved object key (__proto__ / constructor / prototype)`;case"value_missing":return`auth.field_names[${e.index}] is invalid`}},Bu=(e,t)=>{let n=[],r=(i,s)=>{n.push(s),t?.({path:["auth",...i],message:s})};if(e==null||typeof e!="object"||Array.isArray(e))return r([],"auth must be an object"),n;let o=e,a=o.type;if(typeof a!="string"||!lr.includes(a))return r(["type"],`auth.type must be one of ${lr.join("|")}; got ${JSON.stringify(a)}`),n;switch(a){case"oauth2_refresh":if(Ie(o.authorize_url)||r(["authorize_url"],"auth.authorize_url must be a complete HTTPS URL with no embedded username or password and no URL fragment"),Ie(o.token_endpoint)||r(["token_endpoint"],"auth.token_endpoint must be a complete HTTPS URL with no embedded username or password and no URL fragment"),o.authorize_params!==void 0)if(!Du(o.authorize_params))r(["authorize_params"],"auth.authorize_params must be a string\u2192string object when present");else for(let[i,s]of Object.entries(o.authorize_params))qt.has(i)&&r(["authorize_params",i],`auth.authorize_params may not override the reserved OAuth-start key '${i}'`),s.length===0&&r(["authorize_params",i],`auth.authorize_params['${i}'] must be a non-empty string`);o.supports_pkce!==void 0&&typeof o.supports_pkce!="boolean"&&r(["supports_pkce"],"auth.supports_pkce must be a boolean when present");break;case"oauth2_client_credentials":Ie(o.token_endpoint)||r(["token_endpoint"],"auth.token_endpoint must be a complete HTTPS URL with no embedded username or password and no URL fragment"),o.token_auth_style!==void 0&&o.token_auth_style!=="body"&&o.token_auth_style!=="basic"&&r(["token_auth_style"],"auth.token_auth_style must be 'body' or 'basic' when present"),o.scope!==void 0&&(typeof o.scope!="string"||o.scope.trim().length===0)&&r(["scope"],"auth.scope must be a non-empty string when present");break;case"header":if(!Array.isArray(o.header_names))r(["header_names"],"auth.header_names must be a non-empty array of non-empty strings");else{let i=Vi(o.header_names.map(s=>({header_name:s,value:"x"})));i.ok||r("index"in i.issue?["header_names",i.issue.index]:["header_names"],Lu(i.issue))}break;case"query":(typeof o.param_name!="string"||o.param_name.length===0)&&r(["param_name"],"auth.param_name must be a non-empty string");break;case"body_field":if(!Array.isArray(o.field_names))r(["field_names"],"auth.field_names must be a non-empty array of non-empty strings");else{let i=ji(o.field_names.map(s=>({field_name:s,value:"x"})));i.ok||r("index"in i.issue?["field_names",i.issue.index]:["field_names"],Mu(i.issue))}break;case"request_signature":na(o.scheme)||r(["scheme"],`auth.scheme must be one of ${cr.join("|")}; got ${JSON.stringify(o.scheme)}`);break;default:break}return n},dr=(e,t)=>{let n=[],r=(i,s)=>{n.push(s),t?.({path:i,message:s})};if(e==null||typeof e!="object"||Array.isArray(e))return r([],"connection requirement must be an object"),n;let o=e;return(typeof o.api_base!="string"||!o.api_base.startsWith("https://"))&&r(["api_base"],`api_base must be an https:// URL; got ${JSON.stringify(o.api_base)}`),o.per_org!==void 0&&typeof o.per_org!="boolean"&&r(["per_org"],"per_org must be a boolean when present"),(typeof o.vendor!="string"||!ra.test(o.vendor))&&r(["vendor"],`vendor must match ${ra.source}; got ${JSON.stringify(o.vendor)}`),(o.auth!=null&&typeof o.auth=="object"&&!Array.isArray(o.auth)?o.auth.type:void 0)==="oauth2_refresh"?(typeof o.authority!="string"||o.authority.length===0)&&r(["authority"],"authority (OAuth issuer host) is required for an oauth2_refresh descriptor"):o.authority!==void 0&&(typeof o.authority!="string"||o.authority.length===0)&&r(["authority"],"authority must be a non-empty string when present"),o.identity_endpoint!==void 0&&(typeof o.identity_endpoint!="string"||!o.identity_endpoint.startsWith("https://"))&&r(["identity_endpoint"],"identity_endpoint must be an https:// URL when present"),n.push(...Bu(o.auth,t)),o.from_pack!==void 0&&(typeof o.from_pack!="string"||!/^[a-z0-9][a-z0-9-]*[a-z0-9]$/.test(o.from_pack))&&r(["from_pack"],`from_pack must be a pack slug when present; got ${JSON.stringify(o.from_pack)}`),n};var Uu={authority:"login.microsoftonline.com",api_base:ze,vendor:"onedrive",identity_endpoint:`${ze}/me`,auth:{type:"oauth2_refresh",authorize_url:pt,token_endpoint:_t,supports_pkce:!0}},ia={onedrive:[Uu]};var oa=Object.entries(ia).flatMap(([e,t])=>t.flatMap((n,r)=>dr(n).map(o=>`${e}[${r}]: ${o}`)));if(oa.length>0)throw new Error(`CONNECTION_REQUIREMENT_SEED shape validation failed: ${oa.join("; ")}`);var Hu=["data.contact.engagements.body_content"],yy=new Set(Hu);var Vu=["recipe","ingredient","operation_group","channel_binding","policy","composition","reception_template","saved_view","asset_class"],Gu=["entity_schema","operation_wrapper","producer"],ju=["inline","landing-page","notify-only"];var ur=/^[a-z0-9][a-z0-9-]*[a-z0-9]$/;var Ey=new Set(Vu),by=new Set(Gu),Sy=new Set(ju);var Wu="core",$u=/^[a-z0-9][a-z0-9_-]*[a-z0-9]$/,sa=e=>{if(typeof e!="string"||e.length===0)return null;let t=e.split(".");if(t.length<3)return null;let[n,r,...o]=t;if(!ur.test(n)||!ur.test(r)||!o.every(i=>$u.test(i)))return null;let a=o.join(".");return n===Wu?{tier:"kernel",domain:r,op:a,raw:e}:{tier:"pack",publisher:n,pack:r,operation:a,pack_ref:`${n}.${r}`,raw:e}};var Cy=25*1024*1024;var Iy=512*1024*1024;var qu=["segment_index","chunk_offset","chunk_length","chunk_count","total_bytes"],pr="session",mt="__cu_",ky=`${mt}staged`,vy=`${mt}offset`,wy=`${mt}length`,Oy=`${mt}field`,xy=`${mt}walk`,Py=3600*1e3,Yu=new Set(["method","path","query","headers","body"]),Ny=new Set([...Yu,"max_polls","done","failed","retry_after"]);var Dy={init:new Set(["total_bytes","chunk_count","chunk_length"]),append:new Set([...qu,pr]),finalize:new Set([pr,"chunk_count","total_bytes"]),status:new Set([pr])};var Xu=[...hi],Ly=new Set(Xu);var me=class extends Error{constructor(n,r,o,a,i){super(r);this.code=n;this.status=o;this.method=a;this.details=i;this.name="RpcError"}code;status;method;details};var Qu=["pending","running","succeeded","failed","cancelled","killed","in_doubt"];var Fy=[...Qu,"awaiting_approval","awaiting_peer"];var Yt=["user","chat","mcp","messenger","reception","webhook","schedule","reactive","housekeeping"];var Ky=Object.freeze(["read","write"]);var mr=["read_dom","click","fill","wait_for_selector","extract_table","screenshot","os_notification","inspect","describe","list_tabs","open_tab","wait_for_element","read_table","screenshot_page","submit","pick","reread","press","scroll","navigate","go_back","reload_page","close_tab","hover","download_file","upload_file"];var Xt="acted_on";var zt=["next","previous","top","bottom"];var aa={enter:["Enter","Enter",13],escape:["Escape","Escape",27],esc:["Escape","Escape",27],tab:["Tab","Tab",9],space:[" ","Space",32],backspace:["Backspace","Backspace",8],delete:["Delete","Delete",46],arrowup:["ArrowUp","ArrowUp",38],arrowdown:["ArrowDown","ArrowDown",40],arrowleft:["ArrowLeft","ArrowLeft",37],arrowright:["ArrowRight","ArrowRight",39],up:["ArrowUp","ArrowUp",38],down:["ArrowDown","ArrowDown",40],left:["ArrowLeft","ArrowLeft",37],right:["ArrowRight","ArrowRight",39],home:["Home","Home",36],end:["End","End",35],pageup:["PageUp","PageUp",33],pagedown:["PageDown","PageDown",34]},ca={"/":["Slash",191],".":["Period",190],",":["Comma",188],"-":["Minus",189],"=":["Equal",187],";":["Semicolon",186],"'":["Quote",222],"[":["BracketLeft",219],"]":["BracketRight",221],"\\":["Backslash",220],"`":["Backquote",192]},Ju={control:"ctrlKey",ctrl:"ctrlKey",meta:"metaKey",cmd:"metaKey",command:"metaKey",alt:"altKey",option:"altKey",shift:"shiftKey"},gr=e=>{if(typeof e!="string")return null;let t=e.trim().split("+").map(c=>c.trim());if(t.length===0||t.length>5||t.some(c=>c===""))return null;let n={name:"",key:"",code:"",keyCode:0,ctrlKey:!1,metaKey:!1,altKey:!1,shiftKey:!1};for(let c of t.slice(0,-1)){let d=Ju[c.toLowerCase()];if(d===void 0||n[d])return null;n[d]=!0}let r=t.at(-1),o=r.toLowerCase(),a=Object.hasOwn(aa,o)?aa[o]:void 0,i=/^f([1-9]|1[0-2])$/.exec(o);if(a)[n.key,n.code,n.keyCode]=a;else if(i)n.key=`F${i[1]}`,n.code=n.key,n.keyCode=111+Number(i[1]);else if(/^[a-z]$/.test(o))n.key=n.shiftKey?o.toUpperCase():o,n.code=`Key${o.toUpperCase()}`,n.keyCode=o.toUpperCase().charCodeAt(0);else if(/^[0-9]$/.test(r))n.key=r,n.code=`Digit${r}`,n.keyCode=r.charCodeAt(0);else if(Object.hasOwn(ca,r))n.key=r,[n.code,n.keyCode]=ca[r];else return null;let s=n.key===" "?"Space":n.key.length===1?n.key.toLowerCase():n.key;return n.name=[n.ctrlKey?"Control":"",n.metaKey?"Meta":"",n.altKey?"Alt":"",n.shiftKey?"Shift":"",s].filter(c=>c!=="").join("+"),n};var fr=1e4,Qt=800,Jt=1e4,Zt=1e4,hr=8e3,yr="The page changed since it was inspected: inspect it again.",Er="The page has reloaded, gone to another address or closed since it was read: list the tabs for its current page handle, then inspect it.";var br=(e,t,n)=>`${e} now shows ${t}, where the page's last read showed ${n}: the page changed it since it was inspected. Inspect it again.`;var Sr=1e4,Rr=3e4;var Ar=500;var Tr=1568,Cr=2e6,gt=25e5;var Zu=10*6e4;var Ir=128,en=e=>{if(!e||typeof e!="object"||Array.isArray(e))return!1;let t=e;if(Object.keys(t).some(n=>!["tab_id","document_id","url"].includes(n))||!Number.isSafeInteger(t.tab_id)||t.tab_id<0||typeof t.document_id!="string"||t.document_id.length<1||t.document_id.length>128||typeof t.url!="string"||t.url.length>8192)return!1;try{let n=new URL(t.url);return["http:","https:"].includes(n.protocol)&&!n.username&&!n.password}catch{return!1}},kr=3e4,tn=6e4,vr=["capacity_gap_logged_in","capacity_gap_tab_unavailable","capacity_gap_permission_missing","selector_not_found","authority_invalid","authority_expired","authority_invalid_grant_scope","ingredient_domain_signature_invalid","tab_navigation_blocked","idempotency_violation","delivery_uncertain","value_not_applied","field_protected","mv3_lifecycle_killed","queue_full","unknown"],wr=32,je=1440*60*1e3,Or=["storage","alarms","offscreen","notifications","tabs","scripting","sidePanel"],xr=["cookies","webRequest","webRequestBlocking","history","bookmarks","tabCapture","desktopCapture","pageCapture","proxy","vpnProvider","debugger","<all_urls>"],Qe=["server_url","webclient_token","server_public_key","pair_metadata","cert_pin_state","chrome_permissions_state","idempotency_cache","pending_outbox","blocked_sites","approval_notices_shown"],nn=(e,t,n)=>n.publisher_id!==t.publisher_id||n.slug!==t.slug||n.version!==t.version||!te(e,t.domain_allowlist)?!1:te(e,n.granted_origins),te=(e,t)=>{if(t.length===0)return!1;for(let n of t){if(e===n)return!0;let r=_r(e),o=_r(n);if(!(!r||!o)&&!(r.scheme!==o.scheme&&o.scheme!=="*")&&ep(r.host,o.host)&&tp(r.path,o.path))return!0}return!1},_r=e=>{let t=e.match(/^([\w*]+):\/\/([^/]+)(\/.*)?$/);if(!t)return null;let[,n,r,o]=t;return{scheme:n,host:r,path:o??"/"}},rn=e=>_r(e)!==null,ep=(e,t)=>{if(e===t||t==="*")return!0;if(t.startsWith("*.")){let n=t.slice(2);return e===n||e.endsWith("."+n)}return!1},tp=(e,t)=>{if(t==="/*"||t==="/*"||t===e)return!0;if(t.endsWith("/*")){let n=t.slice(0,-2);return e===n||e.startsWith(n+"/")}return!1};var np=["user","crm_user","crm_automation","integration","import","system_process","unknown"],la=new Set(np);var rp=["inbound","outbound","internal","unknown"],da=new Set(rp);var op=["exact","probable","none"],Gy=new Set(op);var ip=["exact_only","probable","all"],jy=new Set(ip);var sp=["pending","scheduled","completed","cancelled","rescheduled","failed","no_answer","point_in_time"],Wy=new Set(sp);var ap=["none","mail_link","calendar_link","inline_body","truncated_inline","mirror_blob_pending","mirror_blob"],$y=new Set(ap);var cp=["contact","deal","account","owner","mail_twin","calendar_twin"],qy=new Set(cp);var lp=["quota_suspended","rate_limit_active","permission_revoked","partial_api_failure","body_redacted","association_rescan_pending","webhook_delivery_degraded","tz_inferred","authorship_unknown","attachment_metadata_only","sample_floor_unmet"],dp=new Set(lp),ua=e=>typeof e=="string"&&dp.has(e);var Yy=1440*60*1e3,Xy=10080*60*1e3;var zy=2160*60*60*1e3;var up=/^[a-z][a-z0-9]*(?:_[a-z0-9]+)*$/;var Pr=e=>e===null||typeof e!="object"||Array.isArray(e)?{ok:!1,issues:["expected object"]}:{ok:!0,value:e},ge=e=>t=>{if(t===null||typeof t!="object"||Array.isArray(t))return{ok:!1,issues:["expected object"]};let n=t,r=[];for(let o of Object.keys(e))e[o](n[o])||r.push(`field '${o}' failed validation`);return r.length>0?{ok:!1,issues:r}:{ok:!0,value:n}},ne=e=>typeof e=="string",X=e=>e===void 0||typeof e=="string",R=e=>typeof e=="number"&&Number.isFinite(e),Nr=e=>e===void 0||R(e),ae=e=>e===null||R(e),le=e=>Array.isArray(e)&&e.every(t=>typeof t=="string"),ft=e=>{if(e===void 0)return!0;if(!Array.isArray(e))return!1;for(let t of e){if(t===null||typeof t!="object"||Array.isArray(t))return!1;let n=t;if(typeof n.entity!="string"||typeof n.name!="string")return!1}return!0},pp=ft,_p=ge({name:X,entity:X,interaction_count:R,last_interaction:R,recent_subjects:le,cursor_at:R,window_ms:R}),mp=ge({brief:ne,attendees:le,related_thread_ids:le,generated_at:R,window_ms:R,attendees_resolved:ft}),gp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.reschedule_count)||n.push("field 'reschedule_count' must be a finite number"),(!Array.isArray(t.recent_at)||!t.recent_at.every(R))&&n.push("field 'recent_at' must be an array of numbers"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),X(t.reason)||n.push("field 'reason' must be string when present"),R(t.window_ms)||n.push("field 'window_ms' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},fp=ge({thread_id:ne,message_count:R,participant_count:R,span_days:R,has_unread:e=>typeof e=="boolean",subject:X,participant_contacts:pp,latest_received_at:Nr}),hp=ge({text:ne,language:X,duration_s:Nr,model:X}),yp=ge({caption:ne,model:X}),Ep=ge({text:ne,page_count:Nr,model:X}),bp=ge({dimensions:R,model:ne}),Sp=ge({name:X,entity:X,mail_count_window:R,mail_count_total:R,meeting_count_window:R,meeting_count_total:R,mean_reply_latency_ms:ae,reply_sample_count:R,last_meeting_at:ae,last_inbound_at:ae,computed_at:R,window_ms:R}),Rp=ge({name:X,entity:X,inbound_count_window:R,reply_sample_count_window:R,reply_rate_window:ae,reply_sample_count:R,mean_reply_latency_ms:ae,p50_reply_latency_ms:ae,p95_reply_latency_ms:ae,computed_at:R,window_ms:R}),Ap=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=e;return ne(t.email)&&R(t.count)&&X(t.name)&&X(t.entity)},Tp=e=>Array.isArray(e)&&e.every(Ap),Cp=ge({name:X,entity:X,events_total:R,events_window:R,top_co_attendees:Tp,last_event_at:ae,computed_at:R,window_ms:R}),Ip=e=>e===null||e==="accelerating"||e==="stable"||e==="decelerating",kp=ge({name:X,entity:X,events_total:R,events_window_short:R,events_window_long:R,per_week_window_short:R,per_month_window_long:R,trend:Ip,last_event_at:ae,computed_at:R,window_ms:R}),vp=e=>e==="signature_parse"||e==="domain_only",wp=e=>e==="free_mail"||e==="business",Ca=e=>e===null||typeof e=="string",Op=ge({name:X,entity:X,domain:ne,company_name:Ca,source:vp,domain_category:wp,reasoning:ne,computed_at:R}),xp=["executive","engineering","product","sales","marketing","operations","support","research","other"],Pp=new Set(xp),Np=e=>typeof e=="string"&&Pp.has(e),Dp=ge({name:X,entity:X,title:ne,category:Np,reasoning:ne,computed_at:R}),Lp=ge({summary:ne,key_points:le,attendees_considered:le,attendees_considered_resolved:ft,corpus_size:R,computed_at:R}),Mp=new Set(["high","medium","low"]),Bp=e=>typeof e=="string"&&Mp.has(e),Up=e=>e==="deterministic"||e==="ai",Fp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=e;return!(typeof t.thread_id!="string"||t.thread_id===""||typeof t.subject!="string"||!R(t.last_message_at)||!R(t.overlap_count)||!Bp(t.relevance)||!Up(t.source)||t.reasoning!==void 0&&typeof t.reasoning!="string")},Kp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!Array.isArray(t.threads)||!t.threads.every(Fp))&&n.push("field 'threads' must be an array of RelatedThread"),R(t.candidate_count)||n.push("field 'candidate_count' must be a finite number"),typeof t.ai_invoked!="boolean"&&n.push("field 'ai_invoked' must be a boolean"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Hp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(typeof t.topic_name!="string"||t.topic_name==="")&&n.push("field 'topic_name' must be a non-empty string"),typeof t.summary!="string"&&n.push("field 'summary' must be a string"),(!le(t.members)||t.members.length===0)&&n.push("field 'members' must be a non-empty array of mail message ids"),(!le(t.thread_ids)||t.thread_ids.length===0)&&n.push("field 'thread_ids' must be a non-empty array of thread ids"),le(t.theme_tokens)||n.push("field 'theme_tokens' must be an array of strings"),R(t.thread_count)||n.push("field 'thread_count' must be a finite number"),typeof t.ai_invoked!="boolean"&&n.push("field 'ai_invoked' must be a boolean"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),R(t.window_ms)||n.push("field 'window_ms' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},sn=e=>Array.isArray(e)&&e.length>0&&e.every(t=>typeof t=="string"),Vp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return sn(t.contacts)||n.push("field 'contacts' must be a non-empty array of canonical emails"),sn(t.members)||n.push("field 'members' must be a non-empty array of calendar event ids"),R(t.event_count)||n.push("field 'event_count' must be a finite number"),R(t.last_event_at)||n.push("field 'last_event_at' must be a finite number"),R(t.first_event_at)||n.push("field 'first_event_at' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),ft(t.contacts_resolved)||n.push("field 'contacts_resolved' must be an array of { entity, name } when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Gp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(typeof t.domain!="string"||t.domain.length===0)&&n.push("field 'domain' must be a non-empty string"),Ca(t.organization_name)||n.push("field 'organization_name' must be a string or null"),sn(t.contacts)||n.push("field 'contacts' must be a non-empty array of canonical emails"),R(t.contact_count)||n.push("field 'contact_count' must be a finite number"),R(t.last_interaction_at)||n.push("field 'last_interaction_at' must be a finite number"),R(t.first_seen_at)||n.push("field 'first_seen_at' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),ft(t.contacts_resolved)||n.push("field 'contacts_resolved' must be an array of { entity, name } when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},jp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return sn(t.members)||n.push("field 'members' must be a non-empty array of mail ids"),R(t.member_count)||n.push("field 'member_count' must be a finite number"),(typeof t.model!="string"||t.model.length===0)&&n.push("field 'model' must be a non-empty string"),R(t.avg_intra_similarity)||n.push("field 'avg_intra_similarity' must be a finite number"),R(t.last_ingested_at)||n.push("field 'last_ingested_at' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Wp=e=>e==="none"||e==="moderate"||e==="significant",pa=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=e;return R(t.start_at)&&R(t.end_at)&&R(t.sample_count)},_a=e=>Array.isArray(e)&&e.every(R),$p=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(typeof t.source_topic!="string"||t.source_topic==="")&&n.push("field 'source_topic' must be a non-empty string"),R(t.psi)||n.push("field 'psi' must be a finite number"),Wp(t.severity)||n.push("field 'severity' must be one of 'none' | 'moderate' | 'significant'"),pa(t.baseline_window)||n.push("field 'baseline_window' must be { start_at, end_at, sample_count }"),pa(t.recent_window)||n.push("field 'recent_window' must be { start_at, end_at, sample_count }"),_a(t.baseline_distribution)||n.push("field 'baseline_distribution' must be an array of numbers"),_a(t.recent_distribution)||n.push("field 'recent_distribution' must be an array of numbers"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),t.dismissed_at!==void 0&&!R(t.dismissed_at)&&n.push("field 'dismissed_at' must be a finite number when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},qp=e=>{if(e===null)return!0;if(typeof e!="object"||Array.isArray(e))return!1;let t=e;return R(t.ts)&&ne(t.error_code)&&ne(t.error_message)},Yp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.call_count)||n.push("field 'call_count' must be a finite number"),R(t.error_count)||n.push("field 'error_count' must be a finite number"),R(t.error_rate)||n.push("field 'error_rate' must be a finite number"),ae(t.latency_p50_ms)||n.push("field 'latency_p50_ms' must be a finite number or null"),ae(t.latency_p95_ms)||n.push("field 'latency_p95_ms' must be a finite number or null"),ae(t.last_call_at)||n.push("field 'last_call_at' must be a finite number or null"),qp(t.last_failure)||n.push("field 'last_failure' must be { ts, error_code, error_message } or null"),R(t.window_ms)||n.push("field 'window_ms' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Xp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=e;return ne(t.recipe_id)&&R(t.call_count)&&R(t.last_used_at)},zp=e=>Array.isArray(e)&&e.every(Xp),Qp=e=>Array.isArray(e)&&e.length===24&&e.every(R),Jp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.call_count)||n.push("field 'call_count' must be a finite number"),ae(t.last_used_at)||n.push("field 'last_used_at' must be a finite number or null"),zp(t.recipes)||n.push("field 'recipes' must be an array of { recipe_id, call_count, last_used_at }"),R(t.distinct_recipes)||n.push("field 'distinct_recipes' must be a finite number"),R(t.unattributed_call_count)||n.push("field 'unattributed_call_count' must be a finite number"),Qp(t.hour_histogram)||n.push("field 'hour_histogram' must be a 24-element array of finite numbers"),R(t.window_ms)||n.push("field 'window_ms' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Zp=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.sample_count)||n.push("field 'sample_count' must be a finite number"),ae(t.median_duration_ms)||n.push("field 'median_duration_ms' must be a finite number or null"),ae(t.p95_duration_ms)||n.push("field 'p95_duration_ms' must be a finite number or null"),ae(t.median_payload_bytes)||n.push("field 'median_payload_bytes' must be a finite number or null"),ae(t.p95_payload_bytes)||n.push("field 'p95_payload_bytes' must be a finite number or null"),ae(t.recommended_max_payload_bytes)||n.push("field 'recommended_max_payload_bytes' must be a finite number or null"),R(t.bytes_coverage)||n.push("field 'bytes_coverage' must be a finite number"),R(t.window_ms)||n.push("field 'window_ms' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},e_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.score)||t.score<0||t.score>100)&&n.push("field 'score' must be a finite number in [0, 100]"),le(t.signals)||n.push("field 'signals' must be string[]"),ne(t.reasoning)||n.push("field 'reasoning' must be a string"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},ma=new Set(["accelerating","stable","stalling"]),t_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(typeof t.velocity!="string"||!ma.has(t.velocity))&&n.push(`field 'velocity' must be one of ${[...ma].join(" / ")}`),(!R(t.recent_activity_count)||t.recent_activity_count<0)&&n.push("field 'recent_activity_count' must be a non-negative finite number"),(!R(t.days_in_stage)||t.days_in_stage<0)&&n.push("field 'days_in_stage' must be a non-negative finite number"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},n_=new Set(["rising","flat","falling"]),r_=e=>typeof e=="string"&&n_.has(e),o_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return!1;let t=e;if(!R(t.local)||!R(t.recency))return!1;for(let n of Object.keys(t))if(!R(t[n]))return!1;return!0},i_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.score)||t.score<0||t.score>100)&&n.push("field 'score' must be a finite number in [0, 100]"),R(t.last_meaningful_touch)||n.push("field 'last_meaningful_touch' must be a finite number"),o_(t.signal_breakdown)||n.push("field 'signal_breakdown' must be { local: number, recency: number, hubspot?: number, salesforce?: number }"),r_(t.trajectory)||n.push("field 'trajectory' must be one of rising / flat / falling"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},s_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.days)||t.days<0)&&n.push("field 'days' must be a non-negative finite number"),R(t.last_inbound_event_at)||n.push("field 'last_inbound_event_at' must be a finite number"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ia=["accelerating","steady","decaying"],a_=new Set(Ia),c_=e=>typeof e=="string"&&a_.has(e),l_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return c_(t.trajectory)||n.push(`field 'trajectory' must be one of ${Ia.join(" / ")}`),(!R(t.weighted_recent)||t.weighted_recent<0)&&n.push("field 'weighted_recent' must be a non-negative finite number"),(!R(t.weighted_baseline)||t.weighted_baseline<0)&&n.push("field 'weighted_baseline' must be a non-negative finite number"),(!R(t.total_recent)||t.total_recent<0)&&n.push("field 'total_recent' must be a non-negative finite number"),(!R(t.total_baseline)||t.total_baseline<0)&&n.push("field 'total_baseline' must be a non-negative finite number"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},ka=["rep_pushing","mutual","prospect_pulling"],d_=new Set(ka),u_=e=>typeof e=="string"&&d_.has(e),p_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.inbound_count)||t.inbound_count<0)&&n.push("field 'inbound_count' must be a non-negative finite number"),(!R(t.outbound_count)||t.outbound_count<0)&&n.push("field 'outbound_count' must be a non-negative finite number"),(!R(t.ratio)||t.ratio<0)&&n.push("field 'ratio' must be a non-negative finite number"),u_(t.bucket)||n.push(`field 'bucket' must be one of ${ka.join(" / ")}`),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},__=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.last_touch_at)||t.last_touch_at<0)&&n.push("field 'last_touch_at' must be a non-negative finite number"),t.vendor!==null&&typeof t.vendor!="string"&&n.push("field 'vendor' must be a vendor id string or null"),t.entity!==null&&typeof t.entity!="string"&&n.push("field 'entity' must be a string or null"),t.authorship!==null&&!la.has(t.authorship)&&n.push("field 'authorship' must be a valid Authorship enum or null"),t.direction!==null&&!da.has(t.direction)&&n.push("field 'direction' must be a valid Direction enum or null"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),R(t.last_touch_at)&&t.last_touch_at>0&&(t.vendor===null&&n.push("field 'vendor' must be populated when 'last_touch_at' > 0"),t.entity===null&&n.push("field 'entity' must be populated when 'last_touch_at' > 0"),t.authorship===null&&n.push("field 'authorship' must be populated when 'last_touch_at' > 0"),t.direction===null&&n.push("field 'direction' must be populated when 'last_touch_at' > 0")),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},va=["fast","normal","long","slipping","none"],m_=new Set(va),g_=e=>typeof e=="string"&&m_.has(e),f_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return g_(t.bucket)||n.push(`field 'bucket' must be one of ${va.join(" / ")}`),(!R(t.last_meeting_at)||t.last_meeting_at<0)&&n.push("field 'last_meeting_at' must be a non-negative finite number"),(!R(t.next_outbound_at)||t.next_outbound_at<0)&&n.push("field 'next_outbound_at' must be a non-negative finite number"),R(t.lag_ms)||n.push("field 'lag_ms' must be a finite number (-1 when no follow-up)"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},h_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.out_of_band_count)||t.out_of_band_count<0)&&n.push("field 'out_of_band_count' must be a non-negative finite number"),(!R(t.latest_unmatched_at)||t.latest_unmatched_at<0)&&n.push("field 'latest_unmatched_at' must be a non-negative finite number"),typeof t.confidence_gate_passed!="boolean"&&n.push("field 'confidence_gate_passed' must be boolean"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},wa=["narrow","developing","multi_threaded","silent"],y_=new Set(wa),E_=e=>typeof e=="string"&&y_.has(e),b_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.distinct_contacts)||t.distinct_contacts<0)&&n.push("field 'distinct_contacts' must be a non-negative finite number"),(!R(t.recency_weighted_score)||t.recency_weighted_score<0)&&n.push("field 'recency_weighted_score' must be a non-negative finite number"),E_(t.bucket)||n.push(`field 'bucket' must be one of ${wa.join(" / ")}`),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},S_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return typeof t.reentered!="boolean"&&n.push("field 'reentered' must be boolean"),(!R(t.dormancy_days)||t.dormancy_days<0)&&n.push("field 'dormancy_days' must be a non-negative finite number"),(!R(t.last_reentry_at)||t.last_reentry_at<0)&&n.push("field 'last_reentry_at' must be a non-negative finite number"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Oa=["champion","mixed","blocker","unknown"],R_=new Set(Oa),A_=e=>typeof e=="string"&&R_.has(e),T_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return(!R(t.total_deals)||t.total_deals<0)&&n.push("field 'total_deals' must be a non-negative finite number"),(!R(t.won_deals)||t.won_deals<0)&&n.push("field 'won_deals' must be a non-negative finite number"),(!R(t.lost_deals)||t.lost_deals<0)&&n.push("field 'lost_deals' must be a non-negative finite number"),(!R(t.open_deals)||t.open_deals<0)&&n.push("field 'open_deals' must be a non-negative finite number"),(!R(t.win_rate)||t.win_rate<0||t.win_rate>1)&&n.push("field 'win_rate' must be a finite number in [0, 1]"),A_(t.bucket)||n.push(`field 'bucket' must be one of ${Oa.join(" / ")}`),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},C_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return typeof t.is_multi_account!="boolean"&&n.push("field 'is_multi_account' must be boolean"),t.mail_domain!==null&&typeof t.mail_domain!="string"&&n.push("field 'mail_domain' must be a string or null"),le(t.crm_company_domains)||n.push("field 'crm_company_domains' must be string[]"),R(t.cursor_at)||n.push("field 'cursor_at' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},xa=["warming","steady","cooling","volatile","insufficient_signal"],I_=new Set(xa),k_=e=>typeof e=="string"&&I_.has(e),ga=5,fa=64,v_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];if(k_(t.tone)||n.push(`field 'tone' must be one of ${xa.join(" / ")}`),(!R(t.score)||t.score<-1||t.score>1)&&n.push("field 'score' must be a finite number in [-1, 1]"),!le(t.key_phrases))n.push("field 'key_phrases' must be string[]");else{let r=t.key_phrases;r.length>ga&&n.push(`field 'key_phrases' length must be \u2264 ${ga}`);for(let o of r){if(o.length>fa){n.push(`field 'key_phrases' entries must be \u2264 ${fa} chars (rejects body-shaped tokens)`);break}if(!up.test(o)){n.push("field 'key_phrases' entries must be snake_case lowercase tokens (matched by PROMPT_BIAS_HINT_RE) \u2014 rejects body-shaped strings");break}}}return(!R(t.samples)||t.samples<0)&&n.push("field 'samples' must be a non-negative finite number"),(!R(t.cursor_at)||t.cursor_at<0)&&n.push("field 'cursor_at' must be a non-negative finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Pa=["send_email","schedule_meeting","wait","investigate","escalate","review_contact","no_action"],w_=new Set(Pa),O_=e=>typeof e=="string"&&w_.has(e),ha=200,x_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return O_(t.action)||n.push(`field 'action' must be one of ${Pa.join(" / ")}`),(!R(t.confidence)||t.confidence<0||t.confidence>1)&&n.push("field 'confidence' must be a finite number in [0, 1]"),ne(t.rationale)?t.rationale.length>ha&&n.push(`field 'rationale' must be \u2264 ${ha} chars (rejects body-shaped strings)`):n.push("field 'rationale' must be a string"),(!R(t.samples)||t.samples<0)&&n.push("field 'samples' must be a non-negative finite number"),(!R(t.valid_until_at)||t.valid_until_at<0)&&n.push("field 'valid_until_at' must be a non-negative finite number"),(!R(t.computed_at)||t.computed_at<0)&&n.push("field 'computed_at' must be a non-negative finite number"),(!R(t.cursor_at)||t.cursor_at<0)&&n.push("field 'cursor_at' must be a non-negative finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Na=["pending","fulfilled","broken","expired","cancelled"],P_=new Set(Na),N_=e=>typeof e=="string"&&P_.has(e),Da=["mail","calendar","memory","engagement_email","engagement_meeting","engagement_note","engagement_call","engagement_task","engagement_event","engagement_email_message","engagement_voice_call","engagement_call_history","attachment"],D_=new Set(Da),L_=e=>typeof e=="string"&&D_.has(e),ya=200,Ea=200,ba=1e3,Sa=200,Ra=8,Aa=50,La=3,Ma=254,M_=/^[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)+$/,B_=e=>typeof e=="string"&&e.length>=La&&e.length<=Ma&&M_.test(e),U_=(e,t)=>{if(e===null||typeof e!="object"||Array.isArray(e))return[`${t} must be an object`];let n=e,r=[];return L_(n.source)||r.push(`${t}.source must be one of ${Da.join(" / ")}`),(!ne(n.source_id)||n.source_id.length===0||n.source_id.length>Sa)&&r.push(`${t}.source_id must be a non-empty string \u2264 ${Sa} chars`),(!R(n.source_at)||n.source_at<0)&&r.push(`${t}.source_at must be a non-negative finite number`),n.vendor_url!==void 0&&((!ne(n.vendor_url)||n.vendor_url.length>ba)&&r.push(`${t}.vendor_url must be a string \u2264 ${ba} chars when present`),n.source!=="attachment"&&r.push(`${t}.vendor_url permitted only when source = 'attachment' (got source = ${JSON.stringify(n.source)})`)),n.filename!==void 0&&((!ne(n.filename)||n.filename.length===0||n.filename.length>Ea)&&r.push(`${t}.filename must be a non-empty string \u2264 ${Ea} chars when present`),n.source!=="attachment"&&r.push(`${t}.filename permitted only when source = 'attachment' (got source = ${JSON.stringify(n.source)})`)),r},F_=(e,t)=>{if(e===null||typeof e!="object"||Array.isArray(e))return[`${t} must be an object`];let n=e,r=[];return(!ne(n.commitment_id)||n.commitment_id.length===0)&&r.push(`${t}.commitment_id must be a non-empty string`),ne(n.text)?n.text.length>ya?r.push(`${t}.text must be \u2264 ${ya} chars (rejects body-shaped strings)`):n.text.length===0&&r.push(`${t}.text must be a non-empty string`):r.push(`${t}.text must be a string`),N_(n.status)||r.push(`${t}.status must be one of ${Na.join(" / ")}`),B_(n.actor_email)||r.push(`${t}.actor_email must be a canonical email shape (\u2265 ${La} chars, \u2264 ${Ma} chars, single '@' separating local from FQDN \u2014 rejects body-shaped strings)`),X(n.actor_name)||r.push(`${t}.actor_name must be string when present`),n.due_at!==void 0&&(!R(n.due_at)||n.due_at<0)&&r.push(`${t}.due_at must be a non-negative finite number when present`),Array.isArray(n.evidence_links)?n.evidence_links.length>Ra?r.push(`${t}.evidence_links length must be \u2264 ${Ra}`):n.evidence_links.length===0?r.push(`${t}.evidence_links must contain at least one entry (every commitment carries evidence per \xA7 P6.B)`):n.evidence_links.forEach((o,a)=>{r.push(...U_(o,`${t}.evidence_links[${a}]`))}):r.push(`${t}.evidence_links must be an array`),(!R(n.extracted_at)||n.extracted_at<0)&&r.push(`${t}.extracted_at must be a non-negative finite number`),(!R(n.confidence)||n.confidence<0||n.confidence>1)&&r.push(`${t}.confidence must be a finite number in [0, 1]`),r},K_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return Array.isArray(t.commitments)?t.commitments.length>Aa?n.push(`field 'commitments' length must be \u2264 ${Aa}`):t.commitments.forEach((r,o)=>{n.push(...F_(r,`commitments[${o}]`))}):n.push("field 'commitments' must be an array"),(!R(t.samples)||t.samples<0)&&n.push("field 'samples' must be a non-negative finite number"),(!R(t.cursor_at)||t.cursor_at<0)&&n.push("field 'cursor_at' must be a non-negative finite number"),(!R(t.computed_at)||t.computed_at<0)&&n.push("field 'computed_at' must be a non-negative finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ba=["subscriber","lead","mql","sql","opportunity","customer","evangelist"],H_=new Set(Ba),V_=e=>typeof e=="string"&&H_.has(e),G_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return V_(t.stage)||n.push(`field 'stage' must be one of ${Ba.join(" / ")}`),ne(t.reasoning)||n.push("field 'reasoning' must be a string"),le(t.signals)||n.push("field 'signals' must be string[]"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ua=["lead","prospect","customer","prior_customer","partner","other"],j_=new Set(Ua),W_=e=>typeof e=="string"&&j_.has(e),$_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return W_(t.stage)||n.push(`field 'stage' must be one of ${Ua.join(" / ")}`),ne(t.reasoning)||n.push("field 'reasoning' must be a string"),le(t.signals)||n.push("field 'signals' must be string[]"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),X(t.name)||n.push("field 'name' must be string when present"),X(t.entity)||n.push("field 'entity' must be string when present"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Fa=["cold_outbound","inbound_inquiry","referral","event","unknown"],q_=new Set(Fa),Y_=e=>typeof e=="string"&&q_.has(e),X_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return Y_(t.first_touch_source)||n.push(`field 'first_touch_source' must be one of ${Fa.join(" / ")}`),R(t.first_touch_at)||n.push("field 'first_touch_at' must be a finite number"),ne(t.first_touch_channel)||n.push("field 'first_touch_channel' must be a string"),le(t.signals)||n.push("field 'signals' must be string[]"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},on=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.score)||n.push("field 'score' must be a finite number"),R(t.sample_count)||n.push("field 'sample_count' must be a finite number"),R(t.confidence)||n.push("field 'confidence' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ka=["aligned","inbound_heavy","outbound_heavy","insufficient_data"],z_=new Set(Ka),Q_=e=>typeof e=="string"&&z_.has(e),J_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.inbound_count)||n.push("field 'inbound_count' must be a finite number"),R(t.outbound_count)||n.push("field 'outbound_count' must be a finite number"),Q_(t.imbalance_signal)||n.push(`field 'imbalance_signal' must be one of ${Ka.join(" / ")}`),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Z_=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.count)||n.push("field 'count' must be a finite number"),t.oldest_overdue_at!==null&&!R(t.oldest_overdue_at)&&n.push("field 'oldest_overdue_at' must be a finite number or null"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},em=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.density)||n.push("field 'density' must be a finite number"),R(t.signal_count)||n.push("field 'signal_count' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},tm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return typeof t.stalled!="boolean"&&n.push("field 'stalled' must be a boolean"),le(t.signals)||n.push("field 'signals' must be string[]"),t.last_activity_at!==null&&!R(t.last_activity_at)&&n.push("field 'last_activity_at' must be a finite number or null"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},nm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.decay_score)||n.push("field 'decay_score' must be a finite number"),t.last_access_at!==null&&!R(t.last_access_at)&&n.push("field 'last_access_at' must be a finite number or null"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},rm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return R(t.pressure_score)||n.push("field 'pressure_score' must be a finite number"),R(t.open_count)||n.push("field 'open_count' must be a finite number"),R(t.age_weighted_score)||n.push("field 'age_weighted_score' must be a finite number"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ha=["insufficient_data","reliable","mixed","risky"],om=new Set(Ha),im=e=>typeof e=="string"&&om.has(e),sm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return im(t.band)||n.push(`field 'band' must be one of ${Ha.join(" / ")}`),t.source_score!==null&&!R(t.source_score)&&n.push("field 'source_score' must be a finite number or null"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Va=["email_preferred","call_preferred","text_preferred","meeting_preferred","mixed_no_clear_preference"],am=new Set(Va),cm=e=>typeof e=="string"&&am.has(e),lm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];if(cm(t.preference)||n.push(`field 'preference' must be one of ${Va.join(" / ")}`),t.score_breakdown===null||typeof t.score_breakdown!="object"||Array.isArray(t.score_breakdown))n.push("field 'score_breakdown' must be a Record<string, number>");else for(let[r,o]of Object.entries(t.score_breakdown))R(o)||n.push(`field 'score_breakdown.${r}' must be a finite number`);return R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},dm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return typeof t.gap_present!="boolean"&&n.push("field 'gap_present' must be a boolean"),le(t.gap_signals)||n.push("field 'gap_signals' must be string[]"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Ga=["exact","probable","low"],um=new Set(Ga),pm=e=>typeof e=="string"&&um.has(e),_m=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];return le(t.duplicate_candidate_set)||n.push("field 'duplicate_candidate_set' must be string[]"),pm(t.dedupe_confidence)||n.push(`field 'dedupe_confidence' must be one of ${Ga.join(" / ")}`),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},mm=e=>{if(e===null||typeof e!="object"||Array.isArray(e))return{ok:!1,issues:["expected object"]};let t=e,n=[];if(typeof t.degraded!="boolean"&&n.push("field 'degraded' must be a boolean"),!Array.isArray(t.reasons))n.push("field 'reasons' must be SourceDegradationReason[]");else for(let r=0;r<t.reasons.length;r++)ua(t.reasons[r])||n.push(`field 'reasons[${r}]' (${JSON.stringify(t.reasons[r])}) is not a registered SourceDegradationReason`);return t.last_seen_at!==null&&!R(t.last_seen_at)&&n.push("field 'last_seen_at' must be a finite number or null"),R(t.computed_at)||n.push("field 'computed_at' must be a finite number"),n.length>0?{ok:!1,issues:n}:{ok:!0,value:t}},Re=e=>{let t=e;return t.canonical_email??t.email??""},gm=e=>{let t=e;return Array.isArray(t.attendees)?[...t.attendees]:[]},Ta=e=>e.thread_id??"",fm=e=>{let t=e;if(t.domain)return t.domain;let n=t.canonical_email??"",r=n.indexOf("@");return r>0?n.slice(r+1):""},hm=e=>e.source_topic??"",aE={contact_timeline_rollup:{return_shape:"{ contact: REF<contacts>, entries: [{ at: number, kind: string, record_id: string, summary: string }], first_at: number, last_at: number, count: number }",shape:"per_record",valid_scopes:["contact"],policy:"aggregate",producer_kind:"reactive",aggregates_from:["mail","calendar","audit"],recompute_cadence:"6h",supports_unfold:!0,value_schema:_p,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Contact timeline rollup",description:"Condensed recent-activity digest per contact (last 30 days mail / calendar / memory).",user_value:"Cheap, MCP/chat-friendly summary of what is happening with each contact \u2014 alert recipes and AI agents read this for context without paginating through full timelines."},calendar_event_rollup:{return_shape:"{ event_id: REF<calendar>, title: string, start_at: number, end_at: number, organizer: REF<contacts>, attendees: [REF<contacts>], related_threads: [REF<mail>], summary: string }",shape:"per_record",valid_scopes:["calendar"],policy:"dependent",producer_kind:"reactive",value_schema:mp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"ttl",ttl_days:7,as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"lossy",name:"Meeting context rollup",description:"Meeting prep rollup for an upcoming calendar event. Pre-summarized attendee patterns, related threads, recent significant events.",user_value:"Time-anchored alert recipes use this to render meeting briefs without scanning the full timeline at trigger time."},meeting_reschedule_pattern:{return_shape:"{ contact: REF<contacts>, reschedule_count: number, cancel_count: number, last_reschedule_at: number, window_ms: number }",shape:"per_record",valid_scopes:["contact"],policy:"aggregate",producer_kind:"reactive",aggregates_from:["calendar"],recompute_cadence:"7d",supports_unfold:!0,value_schema:gp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Meeting reschedule pattern",description:"Per-contact tally of how often a meeting on their calendar gets moved or cancelled.",user_value:"Alert recipes flag chronic reschedulers so the user can adjust expectations or proactively reach out."},thread_signals:{return_shape:"{ thread_id: REF<mail>, subject: string, message_count: number, participant_count: number, participant_contacts: [{ name: string, entity: REF<contacts> }], span_days: number, latest_received_at: number, has_unread: boolean }",shape:"per_record",valid_scopes:["mail"],policy:"aggregate",aggregates_from:["mail"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:fp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Thread signals",description:"Per-thread summary signals (message count, participant count, span, unread).",user_value:"Triage thread importance without re-reading every message."},transcript:{return_shape:"{ file: REF<file>, text: string, language: string, duration_s: number, model: string }",shape:"per_record",valid_scopes:["file"],policy:"dependent",producer_kind:"housekeeping",value_schema:hp,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_then_byok",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"forward_only",compression_class:"derived",prompt_bias_hints:["may_mistranscribe_unclear_audio"],name:"File transcript",description:"Voice-to-text transcript for a fixed audio file.",user_value:"Search and reason over voice notes without replaying audio."},caption:{return_shape:"{ file: REF<file>, caption: string, model: string }",shape:"per_record",valid_scopes:["file"],policy:"dependent",producer_kind:"housekeeping",value_schema:yp,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"forward_only",compression_class:"derived",prompt_bias_hints:["describes_visible_content_without_full_context"],name:"File caption",description:"Image-to-text caption for a fixed image file.",user_value:"Understand image attachments without opening each file."},extracted_text:{return_shape:"{ file: REF<file>, text: string, page_count: number, model: string }",shape:"per_record",valid_scopes:["file"],policy:"dependent",producer_kind:"housekeeping",value_schema:Ep,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"forward_only",compression_class:"derived",prompt_bias_hints:["ocr_may_drop_layout_or_tables"],name:"File extracted text",description:"Document-to-text extraction for a fixed document file.",user_value:"Search and reason over document attachments without manually opening them."},embedding:{return_shape:"{ dimensions: number, model: string }",shape:"per_record",valid_scopes:["mail"],policy:"dependent",producer_kind:"housekeeping",value_schema:bp,sidecar:"vector_index",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"lossless",name:"Mail embedding",description:"Semantic vector for mail bodies \u2014 drives similarity search + semantic clustering.",user_value:"Find similar messages without exact-match keyword search."},purpose:{return_shape:"{ category: string, confidence: number, reasoning: string }",shape:"per_record",valid_scopes:["mail"],policy:"dependent",producer_kind:"housekeeping",value_schema:Pr,sidecar:"none",emits_confidence:!0,temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"lossy",prompt_bias_hints:["closed_set_classification_no_hybrid_intent"],name:"Mail purpose",description:"Classified intent of an inbound message (request / update / follow-up / other).",user_value:"Route messages by intent rather than rule-based filters."},summary:{return_shape:"{ summary: string, key_points: [string] }",shape:"per_record",valid_scopes:["mail"],policy:"dependent",producer_kind:"housekeeping",value_schema:Pr,sidecar:"fts",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"lossy",prompt_bias_hints:["caps_output_at_250_words","narrative_form_loses_quantitative_detail"],name:"Mail summary",description:"AI-condensed summary of a mail body \u2014 keeps the gist when the original is long.",user_value:"Skim long mail at a glance; the FTS index makes summaries searchable too."},action_items:{return_shape:"{ action_items: [{ description: string, owner: string, due: string }] }",shape:"per_record",valid_scopes:["mail"],policy:"dependent",producer_kind:"housekeeping",value_schema:Pr,sidecar:"none",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"lossy",prompt_bias_hints:["extracts_explicit_asks_misses_implicit_obligations","caps_at_top_n_actions"],name:"Mail action items",description:"Extracted to-dos / commitments from a mail body.",user_value:"Surface what each message asks of you without re-reading."},behavioral_signature:{return_shape:"[{ entity: REF<contacts>, name: string, mail_count_window: number, mail_count_total: number, meeting_count_window: number, meeting_count_total: number, mean_reply_latency_ms: number, reply_sample_count: number, last_meeting_at: number, last_inbound_at: number, computed_at: number, window_ms: number }]",shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["mail","calendar"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:Sp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",coverage_quality_threshold:100,name:"Behavioral signature",description:"Per-contact patterns \u2014 typical reply latency, mail volume cadence, meeting frequency.",user_value:"Tailor follow-up timing to each contact\u2019s rhythm."},reply_patterns:{return_shape:"{ entity: REF<contacts>, name: string, inbound_count_window: number, reply_sample_count_window: number, reply_rate_window: number, reply_sample_count: number, mean_reply_latency_ms: number, p50_reply_latency_ms: number, p95_reply_latency_ms: number, computed_at: number, window_ms: number }",shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["mail"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:Rp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Reply patterns",description:"Per-contact reply-latency distribution + typical response style.",user_value:"Predict whether a thread will get a fast or slow reply."},attendee_patterns:{return_shape:"[{ entity: REF<contacts>, name: string, events_total: number, events_window: number, top_co_attendees: [{ email: REF<contacts>, entity: REF<contacts>, name: string, count: number }], last_event_at: number, computed_at: number, window_ms: number }]",shape:"per_record",valid_scopes:["contact","calendar"],policy:"aggregate",aggregates_from:["calendar"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:Cp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Attendee patterns",description:"Co-attendance graph \u2014 which contacts cluster together on calendar events.",user_value:"Spot working groups + meeting cliques that aren\u2019t formally labelled."},meeting_frequency:{return_shape:"{ entity: REF<contacts>, name: string, events_total: number, events_window_short: number, events_window_long: number, per_week_window_short: number, per_month_window_long: number, trend: string, last_event_at: number, computed_at: number, window_ms: number }",shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["calendar"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:kp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Meeting frequency",description:"Per-contact rolling meeting cadence (per-week / per-month) plus a 90d trend signal.",user_value:"Identify contacts whose meeting load is changing \u2014 a leading indicator for projects ramping up or down."},company:{return_shape:"{ domain: string, company_name: string, source: string, domain_category: string, reasoning: string, computed_at: number }",shape:"per_record",valid_scopes:["contact"],policy:"dependent",producer_kind:"housekeeping",value_schema:Op,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"perspective",lifecycle_policy:"historical",as_of_field:"computed_at",identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",prompt_bias_hints:["prefers_signature_block_evidence_over_inference","falls_back_to_email_domain_when_no_signature"],name:"Company",description:"Inferred employer for a contact, derived from email domain + AI signature parsing.",user_value:"Group contacts by org without manual tagging."},role:{return_shape:"{ title: string, category: string, reasoning: string, computed_at: number }",shape:"per_record",valid_scopes:["contact"],policy:"dependent",producer_kind:"housekeeping",value_schema:Dp,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"perspective",lifecycle_policy:"historical",as_of_field:"computed_at",identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",prompt_bias_hints:["prefers_signature_block_evidence_over_inference","closed_set_role_categories"],name:"Role",description:"Inferred job title + role category from a contact\u2019s mail signatures.",user_value:"Filter by role when a domain has many contacts (engineering vs. sales)."},preparation_notes:{return_shape:"{ summary: string, key_points: [string], attendees_considered: [REF<contacts>], corpus_size: number, computed_at: number }",shape:"per_record",valid_scopes:["calendar"],policy:"dependent",producer_kind:"housekeeping",value_schema:Lp,sidecar:"fts",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"ttl",ttl_days:30,as_of_field:"computed_at",compression_class:"lossy",prompt_bias_hints:["summarizes_corpus_through_llm_compression","caps_at_5_bullets"],name:"Meeting preparation notes",description:"Pre-event prep distilled from prior threads + memory mentioning the attendees.",user_value:"Walk into a meeting with the relevant context surfaced automatically."},related_threads:{return_shape:"{ threads: [{ thread_id: REF<mail>, subject: string, last_message_at: number, overlap_count: number, relevance: string, source: string, reasoning: string }], candidate_count: number, ai_invoked: boolean, computed_at: number }",shape:"per_record",valid_scopes:["calendar"],policy:"dependent",producer_kind:"housekeeping",value_schema:Kp,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"ttl",ttl_days:30,as_of_field:"computed_at",compression_class:"derived",name:"Related threads",description:"Mail threads detected as topically related to a calendar event.",user_value:"Pull the thread history into the meeting brief automatically."},connection_health_trend:{return_shape:"{ call_count: number, error_count: number, error_rate: number, latency_p50_ms: number, latency_p95_ms: number, last_call_at: number, last_failure: { ts: number, error_code: string, error_message: string }, window_ms: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api","connection.mcp","connection.notification"],policy:"aggregate",aggregates_from:["audit"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:Yp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",as_of_field:"computed_at",aggregate_window_axis:"ingestion_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Connection health trend",description:"Rolling health signal per connection record \u2014 error rate, latency p50/p95, last-failure cause.",user_value:"Spot a flaky connection before a recipe fails on it; surfaced inline on the Connections page.",tags:["department:eng"]},connection_last_used_pattern:{return_shape:"{ call_count: number, last_used_at: number, recipes: [{ recipe_id: string, call_count: number, last_used_at: number }], distinct_recipes: number, unattributed_call_count: number, hour_histogram: [number], window_ms: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api","connection.mcp","connection.notification"],policy:"aggregate",aggregates_from:["audit"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:Jp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",as_of_field:"computed_at",aggregate_window_axis:"ingestion_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Connection last-used pattern",description:"Per-connection cadence of recipe usage \u2014 how often, by which recipes, at what hours.",user_value:"Surface idle connections that can be retired; size pool / refresh cadence to actual usage.",tags:["department:eng"]},connection_optimal_batch_size:{return_shape:"{ sample_count: number, median_duration_ms: number, p95_duration_ms: number, median_payload_bytes: number, p95_payload_bytes: number, recommended_max_payload_bytes: number, bytes_coverage: number, window_ms: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api","connection.mcp"],policy:"aggregate",aggregates_from:["audit"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:Zp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",as_of_field:"computed_at",aggregate_window_axis:"ingestion_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Connection optimal batch size",description:"Inferred batch size that balances throughput against rate-limit / timeout risk per connection.",user_value:"Recipes auto-tune fan-out without a config knob; learns the right batch from observed responses.",tags:["department:eng"]},deal_health_score:{return_shape:"{ deal_id: string, score: number, factors: [{ name: string, impact: number, reasoning: string }], computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"dependent",producer_kind:"housekeeping",value_schema:e_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_then_byok",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"computed_at",compression_class:"derived",prompt_bias_hints:["blends_quantitative_signals_with_qualitative_assessment","caps_breakdown_at_one_sentence_per_dimension"],name:"Deal health score",description:"AI-derived 0-100 health signal per CRM deal \u2014 synthesises stage, age, recent activity, contact engagement.",user_value:"Surface deals at risk before pipeline review reveals them.",tags:["department:sales"]},deal_velocity_signal:{return_shape:"{ deal_id: string, velocity: string, stage_dwell_days: number, last_movement_at: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:t_,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Deal velocity signal",description:"Deterministic aggregate over recent vendor activity \u2014 accelerating / stable / stalling, plus days-in-stage.",user_value:"Pipeline reviews surface stalled deals automatically; no separate report.",tags:["department:sales"]},engagement_score_per_contact:{return_shape:"{ score: number, last_meaningful_touch: number, signal_breakdown: { local: number, recency: number, [vendor]: number }, trajectory: string, cursor_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.contact","connection.api.salesforce.contact","connection.api.pipedrive.person"],policy:"aggregate",aggregates_from:["mail","calendar","connection.api.hubspot.contact","connection.api.salesforce.contact","connection.api.pipedrive.person"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:i_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Engagement score per contact",description:"Per-CRM-contact 0-100 engagement score from mail + calendar + vendor activity. Carries per-source decomposition + recent trajectory.",user_value:"Quantify contact engagement across channels without reading every thread; spot rising / falling relationships at a glance.",tags:["department:sales"]},engagement_silence_duration:{return_shape:"{ contact: REF<contacts>, last_engagement_at: number, silence_days: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:s_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"cursor_at",compression_class:"derived",populates_coverage:!0,name:"Engagement silence duration",description:"Days since the last meaningful inbound engagement on the deal. Folds the full per-type engagement surface (HubSpot 5 + Salesforce 4-5 engagement types).",user_value:"Flag stalled deals before pipeline review reveals them \u2014 alert recipes fire when silence exceeds the deal stage threshold.",tags:["department:sales"]},engagement_velocity_signal:{return_shape:"{ contact: REF<contacts>, velocity: string, recent_touch_count: number, baseline_touch_count: number, change_ratio: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:l_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"cursor_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",populates_coverage:!0,name:"Engagement velocity signal",description:"Touches/week trajectory on the deal \u2014 accelerating / steady / decaying. Recent (30d) window vs the baseline (30-90d) window; authorship-weighted (automation + system_process count at 0.25); excludes internal direction; dedupe_acceptance: exact_only.",user_value:"See whether engagement is heating up or cooling off without scrolling activity timelines \u2014 alert recipes fire on decaying trajectories for high-value deals.",tags:["department:sales"]},inbound_outbound_ratio:{return_shape:"{ contact: REF<contacts>, inbound_count: number, outbound_count: number, ratio: number, window_ms: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:p_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"cursor_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",populates_coverage:!0,name:"Inbound/outbound ratio",description:"Rep effort vs prospect engagement on the deal. Outbound counts only user / crm_user authorship; inbound excludes automation + system_process. Internal direction excluded from both buckets. Includes no_answer / failed sends as outbound effort (the rep made the attempt) but never as prospect engagement.",user_value:"Spot deals where the rep is talking to themselves \u2014 high outbound + zero inbound is a stalled-deal signal.",tags:["department:sales"]},last_meaningful_touch:{return_shape:"{ contact: REF<contacts>, last_touch_at: number, kind: string, record_id: string, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:__,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"last_touch_at",compression_class:"derived",populates_coverage:!0,name:"Last meaningful touch",description:"Most recent substantive engagement on the deal, filtered against tracking-pixel + workflow auto-logs. Authorship NOT IN crm_automation / system_process; excludes pending tasks, scheduled meetings, no_answer calls, failed email sends. Direction-agnostic (any meaningful inbound or outbound counts).",user_value:"See the actual last meaningful touch without scrolling through opens + bounces + auto-replies \u2014 the truth about engagement recency.",tags:["department:sales"]},meeting_to_followup_lag:{return_shape:"{ meeting_id: REF<calendar>, followup_at: number, lag_ms: number, followup_id: REF<mail>, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history","mail","calendar"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:f_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"last_meeting_at",compression_class:"derived",populates_coverage:!0,name:"Meeting \u2192 follow-up lag",description:"Time from latest completed meeting \u2192 next outbound rep touch on the deal. Bucketed fast/normal/long/slipping/none. Slipping-deal signal \u2014 alerts when the rep hasn't followed up after a deal meeting. Folds calendar + CRM meeting evidence + mail/CRM email outbound; excludes scheduled/cancelled/rescheduled meetings + non-rep authorship.",user_value:"Catch deals slipping after a meeting before pipeline review \u2014 alert recipes fire when post-meeting follow-up runs long.",tags:["department:sales"]},out_of_band_engagement:{return_shape:"{ contact: REF<contacts>, channel: string, count: number, last_at: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.salesforce.email_message","mail"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:h_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"latest_unmatched_at",compression_class:"derived",populates_coverage:!0,name:"Out-of-band engagement",description:"Outbound rep mails to deal contacts that didn't land as a CRM engagement. Surfaces the visibility gap where the rep's real work isn't visible to CRM-only views. Mail-to-CRM matching prefers Message-ID; falls back to (from + to + sent_at + subject_hash) quadruple. 30-min grace window after CRM landing. Confidence gate: alerts only when contact has clear primary-deal signal.",user_value:"See the deal work that isn't in CRM \u2014 alert recipes fire on out-of-band outbound that should be logged.",tags:["department:sales"]},account_engagement_breadth:{return_shape:"{ account_id: string, distinct_contacts: number, distinct_channels: number, recent_breadth: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.company","connection.api.salesforce.account"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history","mail","calendar"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:b_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"cursor_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",populates_coverage:!0,name:"Account engagement breadth",description:"Distinct contacts at the account engaging in the recent 90d window. Recency-weighted (30d half-life per contact) \u2014 MEDDIC-flavored multi-threading read. Excludes internal direction, automation/system_process authorship, non-evidence lifecycle states.",user_value:"Spot accounts with single-threaded relationships \u2014 alert recipes fire when account breadth narrows below the threshold for the deal stage.",tags:["department:sales"]},account_reentry_signal:{return_shape:"{ account_id: string, last_active_at: number, reentry_at: number, silence_days: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.company","connection.api.salesforce.account"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history","mail","calendar"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:S_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"last_reentry_at",compression_class:"derived",populates_coverage:!0,name:"Account re-entry signal",description:"Dormant account suddenly active in the last 14d \u2014 surfaces reactivation leads. Boolean state-at-observation (\u2265 60 days zero qualifying engagement, then recent activity). Excludes internal direction, automation/system_process authorship, non-evidence lifecycle states.",user_value:"Catch dormant accounts coming back into play \u2014 alert recipes fire on the reactivation, not after the rep finds out late.",tags:["department:sales"]},champion_deal_count:{return_shape:"{ contact: REF<contacts>, deal_count: number, deal_ids: [string], computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.contact","connection.api.salesforce.contact"],policy:"aggregate",aggregates_from:["connection.api.hubspot.deal","connection.api.salesforce.opportunity","connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:T_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"cursor_at",aggregate_window_axis:"event_time",aggregate_window_ms:365*24*60*60*1e3,identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",populates_coverage:!0,name:"Champion deal count",description:"Per-contact count of deals the contact has touched, segmented by closed-won / closed-lost / open. Computes win_rate over the closed sample + categorical bucket (champion / mixed / blocker / unknown). Cross-deal perspective for one contact \u2014 surfaces who carries multiple wins (cultivate as advocate) vs who keeps appearing on losses (potential blocker).",user_value:"See champions vs blockers across your book \u2014 alert recipes fire on contacts with patterned losses or carry your top advocates.",tags:["department:sales"]},multi_account_contact:{return_shape:"{ contact: REF<contacts>, account_ids: [string], account_count: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.contact","connection.api.salesforce.contact"],policy:"aggregate",aggregates_from:["connection.api.hubspot.contact","connection.api.salesforce.contact","mail"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:C_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"perspective",lifecycle_policy:"historical",as_of_field:"cursor_at",identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",populates_coverage:!0,name:"Multi-account contact",description:"Contact's professional mail domain \u2260 CRM company affiliation domain \u2014 likely job change, reactivation lead. Compares canonical mail domain (excluding free-mail providers) against HubSpot company.domain or Salesforce Account.Website. Empty CRM-domain set \u2192 false (insufficient signal).",user_value:"Catch contacts who changed jobs before they go cold \u2014 alert recipes fire when their mail starts coming from a different professional domain.",tags:["department:sales"]},engagement_sentiment_trend:{return_shape:"{ contact: REF<contacts>, sentiment_baseline: number, sentiment_recent: number, trend: string, sample_count: number, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:v_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"cursor_at",aggregate_window_axis:"event_time",aggregate_window_ms:1440*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"lossy",populates_coverage:!0,prompt_bias_hints:["favors_recency_when_volatile","caps_key_phrases_at_five","tone_inferred_from_preview_when_full_body_unavailable"],body_state_acceptance:["mail_link","calendar_link","inline_body","truncated_inline"],authorship_acceptance:["user","crm_user","unknown"],lifecycle_state_acceptance:["point_in_time","completed"],dedupe_acceptance:"exact_only",name:"Engagement sentiment trend",description:"Tone trajectory across a deal's recent engagement window. AI-surface; folds qualifying engagement rows (authorship NOT IN crm_automation/system_process; lifecycle in evidence states; direction-agnostic) into a closed-bucket tone read + score in [-1, 1] + up to 5 short key-phrase tokens. Persists scalar derivatives only \u2014 never raw body text.",user_value:"See whether the deal's tone is warming, cooling, or volatile without scrolling activity timelines \u2014 recipe alerts fire on cooling deals before the rep notices.",tags:["department:sales"]},next_best_action:{return_shape:"{ contact: REF<contacts>, action: string, priority: string, reasoning: string, computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"aggregate",aggregates_from:["connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:x_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"computed_at",aggregate_window_ms:1440*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",populates_coverage:!0,prompt_bias_hints:["favors_conservative_action_when_uncertain","wait_when_signal_insufficient","caps_rationale_at_one_sentence"],body_state_acceptance:["mail_link","calendar_link","inline_body"],authorship_acceptance:["user","crm_user","unknown"],lifecycle_state_acceptance:["point_in_time","completed"],dedupe_acceptance:"exact_only",name:"Next best action",description:"Recommendation derived from the deal's recent engagement context. AI-surface; closed action bucket (send_email / schedule_meeting / wait / investigate / escalate / review_contact / no_action) + confidence in [0, 1] + \u2264 200-char rationale. Skips truncated-inline body rows (full body context required for action recommendation). Persists scalar values only.",user_value:'Get a quick "what should I do next on this deal" read backed by mail + meetings + CRM activity \u2014 recipes can dispatch on the action enum or surface the rationale in a daily digest.',tags:["department:sales"]},commitment_tracker:{return_shape:"{ commitments: [{ description: string, owner: REF<contacts>, due_at: number, status: string, source_record: string }], computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.contact","connection.api.salesforce.contact","connection.api.pipedrive.person"],policy:"aggregate",aggregates_from:["mail","calendar","audit","connection.api.hubspot.email","connection.api.hubspot.meeting","connection.api.hubspot.note","connection.api.hubspot.call","connection.api.hubspot.task","connection.api.salesforce.task","connection.api.salesforce.event","connection.api.salesforce.email_message","connection.api.salesforce.voice_call","connection.api.salesforce.call_history"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:K_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"time_bound",identity_aggregation:"perspective",lifecycle_policy:"historical",as_of_field:"computed_at",identity_extractor:Re,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",populates_coverage:!0,prompt_bias_hints:["caps_text_at_short_paraphrase","rejects_speculative_commitments","requires_explicit_due_phrasing","never_extracts_from_automation_authored_rows","evidence_links_required_for_every_commitment"],body_state_acceptance:["inline_body"],authorship_acceptance:["user","crm_user","unknown"],lifecycle_state_acceptance:["point_in_time","completed"],dedupe_acceptance:"exact_only",name:"Commitment tracker",description:"Commitments (\"you said you'd send X by Friday\") extracted from mail / calendar / memory / CRM engagements. Authorship-filtered (user / crm_user / unknown only \u2014 automation/system_process rows can't make commitments). Body-state requires inline_body (full-context required for accurate extraction; truncated previews skipped). Per-contact perspective: row keyed on canonical contact email; deal/account context lives in D-120 link-graph evidence_links. AI-surface; manual trust default per D-132 \u2014 user must promote after MANUAL_RUN_THRESHOLD runs. Privacy-tier separated from the deterministic P6.A pack: ships in the post-substrate-canary `crm-commitment-tracker` pack which carries an implicit MCP body-content permission grant on install per spec \xA7 A.9.5.",user_value:"Track follow-through across mail / calendar / memory \u2014 the alert recipe fires when a commitment's due date approaches and the commitment is still pending, so users can keep their word without manually scanning timelines.",tags:["department:sales","domain:crm","kind:ai_surface","shape:per_record"]},lifecycle_stage_inferred:{return_shape:"{ stage: string, reasoning: string, signals: [string], computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.contact"],policy:"dependent",producer_kind:"housekeeping",value_schema:G_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_then_byok",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"computed_at",compression_class:"derived",prompt_bias_hints:["favors_conservative_classification_when_uncertain","caps_reasoning_at_one_sentence"],name:"Inferred lifecycle stage (HubSpot)",description:"AI-classified lifecycle stage for a HubSpot contact. Normalised vocabulary, derived from contact meta + Recued local mail/calendar activity.",user_value:"Surface the gap when your HubSpot lifecyclestage drifts away from observed engagement; flag contacts who are acting more advanced (or less) than HubSpot says.",tags:["department:sales","platform:hubspot"]},attribution_signal:{return_shape:"{ first_touch_source: string, first_touch_at: number, first_touch_channel: string, signals: [string], computed_at: number }",shape:"per_record",valid_scopes:["connection.api.hubspot.deal","connection.api.salesforce.opportunity"],policy:"dependent",producer_kind:"housekeeping",value_schema:X_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"forward_only",compression_class:"lossless",name:"Deal attribution signal",description:"First-touch attribution per CRM deal. Deterministic join of deal create + linked contacts + Recued mail timeline; cross-vendor (HubSpot deals + Salesforce opportunities).",user_value:"See where each deal originated without manual UTM tracking \u2014 backed by mail/calendar evidence rather than self-reported source fields.",tags:["department:sales"]},lifecycle_stage_inferred_salesforce:{shape:"per_record",valid_scopes:["connection.api.salesforce.contact"],policy:"dependent",producer_kind:"housekeeping",value_schema:$_,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_then_byok",temporal_class:"time_bound",identity_aggregation:"scenario",lifecycle_policy:"historical",as_of_field:"computed_at",compression_class:"derived",prompt_bias_hints:["favors_conservative_classification_when_uncertain","caps_reasoning_at_one_sentence"],name:"Inferred lifecycle stage (Salesforce)",description:"AI-classified lifecycle stage for a Salesforce contact. Normalised vocabulary, derived from contact meta + Recued local mail/calendar activity. Parallel to the HubSpot-flavored `lifecycle_stage_inferred` topic \u2014 Salesforce vocabulary diverges (Lead / Prospect / Customer / Prior Customer / Partner / Other).",user_value:"Surface the gap when your Salesforce lifecycle setting drifts from observed engagement; flag contacts who are acting more advanced (or less) than Salesforce says.",tags:["department:sales","platform:salesforce"]},commitment_followthrough_score:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["contact","commitment"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:on,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",emits_confidence:!0,temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Commitment follow-through score",description:"Per-contact follow-through score derived from inbound commitment fulfilment patterns over the rolling window. PSI-eligible \u2014 D-133 drift detection catches when the score distribution silently regresses across producer-version bumps.",user_value:"Quantify how reliably each contact follows through on what they say they'll do.",tags:["department:work"]},commitment_imbalance:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["commitment"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:J_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Commitment imbalance",description:"Per-relationship signal of inbound-vs-outbound commitment skew. Surfaces relationships where one side is making far more commitments than the other.",user_value:"Spot one-sided relationships before they become resentful.",tags:["department:work"]},outbound_commitment_overdue_count:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["commitment"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:Z_,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Outbound commitment overdue count",description:'Per-contact snapshot of overdue outbound commitments to this counterparty. Recomputes daily; cascade-invalidates on commitment.state_changed via the standard work-entity due-status sweep. Spec \xA7 A.7.1 framed this as "per-pair (boss-level)"; the D-145 PA9 implementation slice ships per-contact rows so engine + alert recipes can surface per-counterparty growth.',user_value:"Spot counterparties whose overdue queue is growing \u2014 alert recipes fire on per-contact growth.",tags:["department:work"]},task_completion_velocity:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["task"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:on,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",emits_confidence:!0,temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Task completion velocity",description:"Per-contact tasks-completed-per-period over the rolling window. PSI-eligible.",user_value:"Spot contacts whose throughput is changing \u2014 leading indicator for projects ramping up or down.",tags:["department:work"]},task_signal_density_per_thread:{shape:"per_record",valid_scopes:["mail"],policy:"aggregate",aggregates_from:["task","mail"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:em,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:720*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Task signal density per thread",description:"Per-thread density of task signals (mentions, asks, follow-ups). Reactive on thread updates.",user_value:"Triage threads by how much real work they encode without re-reading messages.",tags:["department:work"]},project_stall_signal:{shape:"per_record",valid_scopes:["project"],policy:"aggregate",aggregates_from:["project","task","note","commitment"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:tm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Project stall signal",description:"Stalled-vs-active flag per project. Folds task / note / commitment activity into the flag with per-project signals.",user_value:"Spot stalled projects without manual review.",tags:["department:work"]},project_velocity:{shape:"per_record",valid_scopes:["project"],policy:"aggregate",aggregates_from:["project","task"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:on,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",emits_confidence:!0,temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Project velocity",description:"Per-project completed-task velocity over the rolling window. PSI-eligible.",user_value:"See whether each project is accelerating, steady, or decaying.",tags:["department:work"]},note_relevance_decay:{shape:"per_record",valid_scopes:["note"],policy:"aggregate",aggregates_from:["note"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:nm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"ingestion_time",aggregate_window_ms:4320*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Note relevance decay",description:"Per-note recency-weighted relevance score \u2014 decays without access. Drives the `note-relevance` recipe surface.",user_value:"Surface notes whose relevance is fading so they can be archived or refreshed.",tags:["department:work"]},open_loop_pressure:{shape:"per_record",valid_scopes:["contact","project"],policy:"aggregate",aggregates_from:["commitment","task","mail"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:rm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Open loop pressure",description:'Two derived-entity scopes (per-contact + per-project) sharing one producer. Folds unresolved commitments + tasks + unanswered threads into a count + age-weighted pressure score. Engine consumes for "what needs attention?" surfaces.',user_value:"See where attention is needed without scanning every entity manually.",tags:["department:work"]},commitment_reliability_band:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["data_enrichment"],recompute_cadence:"24h",producer_kind:"housekeeping",consumes_topics:["commitment_followthrough_score"],value_schema:sm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Commitment reliability band",description:"Commitment-reliability band per contact (insufficient_data / reliable / mixed / risky). Banded over the raw 0-1 `commitment_followthrough_score` with explicit per-band sample floors \u2014 more usable than raw scores in user-facing surfaces.",user_value:"Tag contacts as reliable / mixed / risky without exposing arbitrary 0-1 floats.",tags:["department:work"]},preferred_channel_by_contact:{shape:"per_record",valid_scopes:["contact"],policy:"aggregate",aggregates_from:["mail","calendar"],recompute_cadence:"7d",producer_kind:"housekeeping",value_schema:lm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"scenario",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,inputFingerprintComposition:"aggregate_window_fold",compression_class:"derived",name:"Preferred channel by contact",description:'Preferred outreach channel per contact (email / call / text / meeting / no clear preference). Closed-list values email_preferred / call_preferred / text_preferred / meeting_preferred / mixed_no_clear_preference; behavioral derivation from observed mail / calendar / engagement response patterns. Substrate explicitly avoids "sentiment" framing per A.1.5 narrow taxonomy.',user_value:"Reach contacts where they actually respond rather than guessing.",tags:["department:work"]},project_next_action_gap:{shape:"per_record",valid_scopes:["project"],policy:"aggregate",aggregates_from:["project","task","note","commitment"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:dm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Project next-action gap",description:`Flags active projects with no open task, pending commitment, or recent note. Directly feeds the engine's "what should I do next?" reasoning.`,user_value:"Surface projects that need a next-action defined before they stall.",tags:["department:work"]},task_duplicate_candidate:{shape:"per_record",valid_scopes:["task"],policy:"aggregate",aggregates_from:["task"],recompute_cadence:"24h",producer_kind:"housekeeping",value_schema:_m,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Task duplicate candidate",description:"Likely duplicates of a task across Sources (HubSpot + Salesforce + Recued tasks describing the same work). Emits `duplicate_candidate_set` + `dedupe_confidence: exact / probable / low`.",user_value:"Catch duplicate tasks across Sources before they pile up \u2014 engine consumes for All Sources merging.",tags:["department:work"]},source_freshness_degradation:{shape:"derived_entity",policy:"independent",producer_kind:"housekeeping",value_schema:mm,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Source freshness degradation",description:"Per-Source health signal \u2014 sync staleness / disabled connection / partial coverage / failed reconciliation. Engine uses for omission decisions: when source A has stale data, omit source A from the AI packet OR include with `coverage.sources_degraded` flag.",user_value:"See which Sources are degraded before recipes fail on them.",tags:["department:work"]},context_packet_quality:{shape:"derived_entity",policy:"aggregate",aggregates_from:["audit"],recompute_cadence:"24h",producer_kind:"reactive",value_schema:on,sidecar:"none",default_trust_state:"auto",default_pool_policy:"free_only",emits_confidence:!0,temporal_class:"stable_truth",identity_aggregation:"scenario",lifecycle_policy:"recompute_on_drift",compression_class:"derived",name:"Context packet quality",description:"Quality self-assessment of a RecuedPlan run (context included / omitted / user corrections). Did included context satisfy the request, did omitted context look right, did the user undo or correct \u2014 feeds the C.3 benchmark + future engine tuning. PSI-eligible \u2014 D-133 catches when engine quality regresses across model upgrades.",user_value:"Detect engine quality regressions before users notice them.",tags:["department:work"]},topic_cluster:{return_shape:"{ topic_name: string, summary: string, members: [REF<mail>], thread_ids: [REF<mail>], theme_tokens: [string], thread_count: number, ai_invoked: boolean, computed_at: number, window_ms: number }",shape:"derived_entity",policy:"members_list",members_field:"members",members_scope:"mail",producer_kind:"housekeeping",value_schema:Hp,sidecar:"none",default_trust_state:"manual",default_pool_policy:"free_only",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",aggregate_window_ms:2160*60*60*1e3,identity_extractor:Ta,inputFingerprintComposition:"perspective_fan_in",compression_class:"lossy",prompt_bias_hints:["favours_dominant_thread_signals_over_outliers","cluster_label_is_a_compressed_summary"],name:"Topic cluster",description:"Heuristically clustered mail messages sharing a topic, AI-labelled.",user_value:"Browse mail by topic instead of folder; AI invents the labels from your data."},working_group:{return_shape:"{ contacts: [REF<contacts>], contacts_resolved: [{ entity: REF<contacts>, name: string }], members: [REF<calendar>], event_count: number, last_event_at: number, first_event_at: number, computed_at: number }",shape:"derived_entity",policy:"members_list",members_field:"members",members_scope:"calendar",producer_kind:"housekeeping",value_schema:Vp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",identity_extractor:gm,inputFingerprintComposition:"perspective_fan_in",compression_class:"lossless",name:"Working group",description:"Group of contacts whose calendar attendance clusters together.",user_value:"Spot ad-hoc teams forming around recurring meetings."},organization:{return_shape:"{ domain: string, organization_name: string | null, contacts: [REF<contacts>], contacts_resolved: [{ entity: REF<contacts>, name: string }], contact_count: number, last_interaction_at: number, first_seen_at: number, computed_at: number }",shape:"derived_entity",policy:"independent",producer_kind:"housekeeping",value_schema:Gp,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",identity_extractor:fm,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Organization",description:"Inferred organisation from domain clustering of contacts.",user_value:"See which orgs you interact with most without manual tagging."},semantic_cluster:{shape:"derived_entity",policy:"members_list",members_field:"members",members_scope:"mail",producer_kind:"housekeeping",value_schema:jp,sidecar:"vector_index",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"forward_only",as_of_field:"computed_at",aggregate_window_axis:"event_time",identity_extractor:Ta,inputFingerprintComposition:"perspective_fan_in",compression_class:"derived",name:"Semantic cluster",description:"Mail clustered by embedding similarity.",user_value:"Discover semantically-related mail across folders / labels."},confidence_drift_signal:{return_shape:"{ source_topic: string, psi: number, severity: string, baseline_window: { start_at: number, end_at: number, sample_count: number }, recent_window: { start_at: number, end_at: number, sample_count: number }, baseline_distribution: [number], recent_distribution: [number], computed_at: number }",shape:"derived_entity",policy:"independent",aggregates_from:["data_enrichment"],producer_kind:"housekeeping",value_schema:$p,sidecar:"none",temporal_class:"aggregate_window",identity_aggregation:"perspective",lifecycle_policy:"historical",as_of_field:"computed_at",aggregate_window_axis:"ingestion_time",identity_extractor:hm,inputFingerprintComposition:"upstream_chain",compression_class:"derived",name:"Confidence drift signal",description:"Silent-regression detector for AI-derived facts. Population Stability Index on producer confidence distributions.",user_value:"See when an AI producer is getting worse before downstream symptoms appear.",default_trust_state:"auto",default_pool_policy:"free_only"}};var cE=["mail","contact","calendar","file",...qn,"connection.api","connection.mcp","connection.notification"];var ym=/^connection\.api\.([a-z][a-z0-9_]*)\.([a-z][a-z0-9_]*)$/;var ja=e=>ym.test(e);var Wa=(e,t)=>{if(!/^[a-z][a-z0-9_]*$/.test(e))throw new Error(`enrichment_scope_invalid: vendor must match /^[a-z][a-z0-9_]*$/: '${e}'`);if(!/^[a-z][a-z0-9_]*$/.test(t))throw new Error(`enrichment_scope_invalid: entity must match /^[a-z][a-z0-9_]*$/: '${t}'`);return`connection.api.${e}.${t}`};var Qa=["date","datetime"],Ja=e=>typeof e=="string"&&Qa.includes(e),Dr=new Set(["closed_state","concat"]);var ht=["deal","contact","account"],Lr=new Set(ht),yt=["invoice","bill","expense","payment","customer","vendor","ledger_account"],Em=new Set(yt),Mr=["always","probe_gated"],Za=new Set(Mr),Br=["poll","delta_cursor","stream"],ec=new Set(Br),an=/^[a-z][a-z0-9_]*$/,$a=/^[a-z][a-z0-9_]*(?:\.[a-z][a-z0-9_]*)*$/,qa=new Set(["string","number","string[]","date_ms","object"]);function tc(e){return nc(e).map(t=>t.message)}function nc(e){if(e===null||typeof e!="object"||Array.isArray(e))return[{message:"field 'engagement' must be an object when present"}];let t=[],n=(o,a)=>t.push({message:a,path:[o]}),r=e;return(typeof r.capability!="string"||!Za.has(r.capability))&&n("capability",`engagement.capability must be one of ${[...Mr].join(" / ")} (got ${JSON.stringify(r.capability)})`),(typeof r.sync_kind!="string"||!ec.has(r.sync_kind))&&n("sync_kind",`engagement.sync_kind must be one of ${[...Br].join(" / ")} (got ${JSON.stringify(r.sync_kind)})`),r.exclusive_group!==void 0&&(typeof r.exclusive_group!="string"||r.exclusive_group.length===0)&&n("exclusive_group","engagement.exclusive_group must be a non-empty string when present"),r.exclusive_group!==void 0&&r.capability==="always"&&n("exclusive_group","engagement.exclusive_group requires capability 'probe_gated' \u2014 an always-present entity is not a pick-one alternative"),r.daily_budget!==void 0&&(typeof r.daily_budget!="number"||!Number.isInteger(r.daily_budget)||r.daily_budget<=0)&&n("daily_budget","engagement.daily_budget must be a positive integer when present"),t}function Ur(e){let t=[];if(e===null||typeof e!="object"||Array.isArray(e))return["expected object"];let n=e;if((typeof n.vendor!="string"||!an.test(n.vendor))&&t.push(`field 'vendor' must match ${an.source}`),(typeof n.entity!="string"||!an.test(n.entity))&&t.push(`field 'entity' must match ${an.source}`),(typeof n.display_name!="string"||n.display_name.length===0)&&t.push("field 'display_name' must be a non-empty string"),typeof n.scope!="string")t.push("field 'scope' must be a string");else if(!ja(n.scope))t.push("field 'scope' must match 'connection.api.<vendor>.<entity>'");else if(typeof n.vendor=="string"&&typeof n.entity=="string"){let r=`connection.api.${n.vendor}.${n.entity}`;n.scope!==r&&t.push(`field 'scope' (${n.scope}) does not match composeVendorEntityScope(vendor, entity) = '${r}'`)}if(n.crm_alias!==void 0&&(typeof n.crm_alias!="string"||!Lr.has(n.crm_alias))&&t.push(`field 'crm_alias' must be one of ${[...ht].join(" / ")} when present (got ${JSON.stringify(n.crm_alias)})`),n.acct_alias!==void 0&&((typeof n.acct_alias!="string"||!Em.has(n.acct_alias))&&t.push(`field 'acct_alias' must be one of ${[...yt].join(" / ")} when present (got ${JSON.stringify(n.acct_alias)})`),n.crm_alias!==void 0&&t.push("fields 'crm_alias' and 'acct_alias' are mutually exclusive \u2014 an entity is CRM-canonical or accounting-canonical, not both")),n.engagement!==void 0){for(let r of tc(n.engagement))t.push(r);(n.crm_alias!==void 0||n.acct_alias!==void 0)&&t.push("field 'engagement' is mutually exclusive with 'crm_alias' / 'acct_alias' \u2014 an entity is exactly one category")}if(!Array.isArray(n.meta_fields))t.push("field 'meta_fields' must be an array");else{let r=new Set;n.meta_fields.forEach((o,a)=>{if(o===null||typeof o!="object"||Array.isArray(o)){t.push(`meta_fields[${a}] must be an object`);return}let i=o;if(typeof i.key!="string"||!$a.test(i.key)?t.push(`meta_fields[${a}].key must match ${$a.source}`):r.has(i.key)?t.push(`meta_fields[${a}].key '${i.key}' duplicates an earlier entry`):r.add(i.key),(typeof i.type!="string"||!qa.has(i.type))&&t.push(`meta_fields[${a}].type must be one of ${[...qa].join(" / ")}`),(typeof i.description!="string"||i.description.length===0)&&t.push(`meta_fields[${a}].description must be a non-empty string`),i.source_path!==void 0&&(typeof i.source_path!="string"||i.source_path.length===0)&&t.push(`meta_fields[${a}].source_path must be a non-empty string when present`),i.derivation!==void 0)if(i.source_path!==void 0&&t.push(`meta_fields[${a}] declares both source_path and derivation (mutually exclusive)`),i.derivation===null||typeof i.derivation!="object"||Array.isArray(i.derivation))t.push(`meta_fields[${a}].derivation must be an object`);else{let s=i.derivation;typeof s.kind!="string"||!Dr.has(s.kind)?t.push(`meta_fields[${a}].derivation.kind must be one of ${[...Dr].join(" / ")}`):s.kind==="closed_state"?((typeof s.closed_path!="string"||s.closed_path.length===0)&&t.push(`meta_fields[${a}].derivation.closed_path must be a non-empty string`),(typeof s.won_path!="string"||s.won_path.length===0)&&t.push(`meta_fields[${a}].derivation.won_path must be a non-empty string`)):s.kind==="concat"&&((!Array.isArray(s.parts)||s.parts.length===0||!s.parts.every(c=>typeof c=="string"&&c.length>0))&&t.push(`meta_fields[${a}].derivation.parts must be a non-empty array of non-empty strings`),s.separator!==void 0&&typeof s.separator!="string"&&t.push(`meta_fields[${a}].derivation.separator must be a string when present`),s.fallback_path!==void 0&&(typeof s.fallback_path!="string"||s.fallback_path.length===0)&&t.push(`meta_fields[${a}].derivation.fallback_path must be a non-empty string when present`),s.fallback_transform!==void 0&&s.fallback_transform!=="local_part"&&t.push(`meta_fields[${a}].derivation.fallback_transform must be 'local_part' when present`),s.fallback_transform!==void 0&&s.fallback_path===void 0&&t.push(`meta_fields[${a}].derivation.fallback_transform requires fallback_path`))}i.date_granularity!==void 0&&(Ja(i.date_granularity)?i.type!=="date_ms"&&t.push(`meta_fields[${a}].date_granularity is only valid on a 'date_ms' field (got type '${String(i.type)}')`):t.push(`meta_fields[${a}].date_granularity must be 'date' or 'datetime' when present`))})}return t}function rc(e){let t=Ur(e);if(t.length>0)throw new Error(`invalid ConnectionVendorEntity for '${e.vendor}.${e.entity}': ${t.join("; ")}`)}function oe(e){let t=Wa(e.vendor,e.entity),n={vendor:e.vendor,entity:e.entity,scope:t,display_name:e.display_name,meta_fields:e.meta_fields,...e.crm_alias===void 0?{}:{crm_alias:e.crm_alias},...e.engagement===void 0?{}:{engagement:e.engagement}};return rc(n),n}function oc(e){let t=[],n=new Map,r=new Map,o=new Map;return e.forEach((a,i)=>{let s=a.engagement;if(s===void 0||!ec.has(s.sync_kind))return;let c=n.get(a.vendor);if(c===void 0?n.set(a.vendor,{kind:s.sync_kind,idx:i}):c.kind!==s.sync_kind&&t.push(`[${i}] vendor '${a.vendor}' engagement entity declares sync_kind '${s.sync_kind}' but entry [${c.idx}] declared '${c.kind}' \u2014 a vendor's engagement entities must share ONE sync_kind`),s.exclusive_group!==void 0&&Za.has(s.capability)){let d=`${a.vendor} ${s.exclusive_group}`,f=r.get(d);f===void 0?r.set(d,{capability:s.capability,idx:i}):f.capability!==s.capability&&t.push(`[${i}] engagement exclusive_group '${s.exclusive_group}' (vendor '${a.vendor}') mixes capability '${s.capability}' with '${f.capability}' at entry [${f.idx}] \u2014 a group must be uniformly always OR probe_gated`)}if(s.daily_budget!==void 0&&typeof s.daily_budget=="number"){let d=o.get(a.vendor);d===void 0?o.set(a.vendor,{budget:s.daily_budget,idx:i}):d.budget!==s.daily_budget&&t.push(`[${i}] vendor '${a.vendor}' engagement daily_budget ${s.daily_budget} conflicts with ${d.budget} at entry [${d.idx}] \u2014 a vendor's engagement entities must share ONE daily_budget`)}}),t}function ic(e){let t=[],n=new Set,r=new Map;e.forEach((o,a)=>{let i=Ur(o);for(let s of i)t.push(`[${a}] ${s}`);if(n.has(o.scope)?t.push(`[${a}] duplicate scope '${o.scope}' \u2014 only one entry per (vendor, entity) allowed`):n.add(o.scope),o.crm_alias!==void 0&&Lr.has(o.crm_alias)){let s=r.get(o.vendor);s===void 0&&(s=new Map,r.set(o.vendor,s));let c=s.get(o.crm_alias);c!==void 0?t.push(`[${a}] vendor '${o.vendor}' already declares crm_alias '${o.crm_alias}' at entry [${c}] \u2014 within a single vendor, each crm_alias may appear at most once (cross-vendor collision is allowed and intended)`):s.set(o.crm_alias,a)}});for(let o of oc(e))t.push(o);return t}var We=[oe({vendor:"hubspot",entity:"deal",display_name:"HubSpot Deal",crm_alias:"deal",meta_fields:[{key:"id",type:"string",source_path:"properties.hs_object_id",description:"vendor record id via the hs_object_id property mirror (a pure property name keeps the search body.properties list valid; the canonical record selector for read/update/delete)"},{key:"name",type:"string",source_path:"properties.dealname",description:"dealname"},{key:"stage",type:"string",source_path:"properties.dealstage",description:"dealstage (canonical or pipeline-specific id)"},{key:"amount",type:"number",source_path:"properties.amount",description:"amount in deal currency"},{key:"owner",type:"string",source_path:"properties.hubspot_owner_id",description:"hubspot_owner_id (resolved to email when granted)"},{key:"pipeline",type:"string",source_path:"properties.pipeline",description:"pipeline id deal lives in"},{key:"key_dates.close_date",type:"date_ms",date_granularity:"date",source_path:"properties.closedate",description:"closedate"},{key:"key_dates.created_at",type:"date_ms",date_granularity:"datetime",source_path:"properties.createdate",description:"createdate"},{key:"key_dates.next_activity_at",type:"date_ms",date_granularity:"datetime",source_path:"properties.notes_next_activity_date",description:"notes_next_activity_date \u2014 the deal's scheduled next-activity timestamp (same key-date family as close_date/created_at)"},{key:"key_dates.last_activity_at",type:"date_ms",date_granularity:"datetime",source_path:"properties.notes_last_contacted",description:"notes_last_contacted \u2014 the deal's most-recent logged-activity timestamp"},{key:"forecast_amount",type:"number",source_path:"properties.hs_forecast_amount",description:"hs_forecast_amount when set"},{key:"description",type:"string",source_path:"properties.description",description:"free-text deal description"},{key:"next_step",type:"string",source_path:"properties.hs_next_step",description:"hs_next_step \u2014 the rep-authored next-step note"},{key:"priority",type:"string",source_path:"properties.hs_priority",description:"hs_priority (HubSpot-managed priority label)"},{key:"close_state",type:"string",description:'"open" | "won" | "lost" derived from hs_is_closed* flags',derivation:{kind:"closed_state",closed_path:"properties.hs_is_closed",won_path:"properties.hs_is_closed_won"}}]}),oe({vendor:"hubspot",entity:"contact",display_name:"HubSpot Contact",crm_alias:"contact",meta_fields:[{key:"email",type:"string",source_path:"properties.email",description:"canonical email \u2014 primary join key against data.contact.<email>"},{key:"id",type:"string",source_path:"properties.hs_object_id",description:"vendor record id via the hs_object_id property mirror (a pure property name keeps the search body.properties list valid; the canonical record selector for read/update/delete)"},{key:"name",type:"string",description:"firstname + lastname (space-joined); falls back to the email local-part when both absent",derivation:{kind:"concat",parts:["properties.firstname","properties.lastname"],separator:" ",fallback_path:"properties.email",fallback_transform:"local_part"}},{key:"first_name",type:"string",source_path:"properties.firstname",description:"firstname (given name)"},{key:"last_name",type:"string",source_path:"properties.lastname",description:"lastname (family name)"},{key:"lifecycle_stage",type:"string",source_path:"properties.lifecyclestage",description:"lifecyclestage (subscriber / lead / mql / sql / opportunity / customer / evangelist / other)"},{key:"owner",type:"string",source_path:"properties.hubspot_owner_id",description:"hubspot_owner_id (resolved to email when granted)"},{key:"account_id",type:"string",source_path:"properties.associatedcompanyid",description:"associatedcompanyid (links to hubspot.company target_id; canonical account link \u2014 cross-vendor with salesforce.contact.account_id)"},{key:"recent_activity_at",type:"date_ms",date_granularity:"datetime",source_path:"properties.notes_last_contacted",description:"notes_last_contacted (last touch timestamp)"},{key:"phone",type:"string",source_path:"properties.phone",description:"phone (canonicalized E.164 at projection time)"},{key:"mailing_address",type:"object",description:"structured mailing address (address1/address2/city/state/zip/country)"},{key:"company",type:"string",source_path:"properties.company",description:"company (HubSpot contact-level company-string property; distinct from associatedcompanyid)"},{key:"job_title",type:"string",source_path:"properties.jobtitle",description:"jobtitle \u2014 the role held at the associated company"},{key:"industry",type:"string",source_path:"properties.industry",description:"industry (HubSpot contact-level copy; the portable home is account.industry)"},{key:"mailing_street",type:"string",source_path:"properties.address",description:"address \u2014 the street line (vCard ADR street)"},{key:"mailing_city",type:"string",source_path:"properties.city",description:"city (vCard ADR locality)"},{key:"mailing_region",type:"string",source_path:"properties.state",description:"state \u2014 the state or region (vCard ADR region)"},{key:"mailing_postal_code",type:"string",source_path:"properties.zip",description:"zip \u2014 the postal code (vCard ADR postal code)"},{key:"mailing_country",type:"string",source_path:"properties.country",description:"country (vCard ADR country)"},{key:"birthday",type:"string",source_path:"properties.date_of_birth",description:`date_of_birth \u2014 HubSpot's default "Date of birth", a text property (YYYY-MM-DD as Recued writes it; vCard BDAY)`}]}),oe({vendor:"hubspot",entity:"company",display_name:"HubSpot Company",crm_alias:"account",meta_fields:[{key:"id",type:"string",source_path:"properties.hs_object_id",description:"vendor record id via the hs_object_id property mirror (a pure property name keeps the search body.properties list valid; the canonical record selector for read/update/delete)"},{key:"name",type:"string",source_path:"properties.name",description:"company name"},{key:"domain",type:"string",source_path:"properties.domain",description:"primary website domain"},{key:"industry",type:"string",source_path:"properties.industry",description:"industry tag (HubSpot-managed taxonomy)"},{key:"num_employees",type:"number",source_path:"properties.numberofemployees",description:"numberofemployees"},{key:"owner",type:"string",source_path:"properties.hubspot_owner_id",description:"hubspot_owner_id (resolved to email when granted)"},{key:"annual_revenue",type:"number",source_path:"properties.annualrevenue",description:"annualrevenue when set"}]}),oe({vendor:"hubspot",entity:"email",display_name:"HubSpot Email Engagement",engagement:{capability:"always",sync_kind:"poll",daily_budget:25e4},meta_fields:[{key:"subject",type:"string",description:"hs_email_subject"},{key:"direction",type:"string",description:'"INCOMING_EMAIL" | "FORWARDED_EMAIL" | "EMAIL"'},{key:"from_email",type:"string",description:"hs_email_from_email (canonical lowercase + trimmed)"},{key:"to_emails",type:"string[]",description:"hs_email_to_email split + canonicalized"},{key:"cc_emails",type:"string[]",description:"hs_email_cc_email split + canonicalized"},{key:"timestamp",type:"date_ms",description:'hs_timestamp \u2014 engagement timeline time; promotes to row.event_at only when hs_email_status = "SENT" per \xA7 A.3.1'},{key:"status",type:"string",description:'hs_email_status \u2014 closed list per HubSpot ("SCHEDULED" / "SENDING" / "SENT" / "FAILED" / "BOUNCED"); drives lifecycle_state per \xA7 A.3.6'},{key:"message_id",type:"string",description:"RFC822 Message-ID for mail-twin matching when present"},{key:"thread_id",type:"string",description:"hs_email_thread_id"},{key:"body_preview",type:"string",description:"first 256 chars of body (display)"},{key:"owner",type:"string",description:"hubspot_owner_id (resolved to email when granted)"}]}),oe({vendor:"hubspot",entity:"meeting",display_name:"HubSpot Meeting Engagement",engagement:{capability:"always",sync_kind:"poll",daily_budget:25e4},meta_fields:[{key:"title",type:"string",description:"hs_meeting_title"},{key:"start_time",type:"date_ms",description:"hs_meeting_start_time \u2014 always populated; promotes to row.scheduled_start_at; promotes to row.event_at only when start_time \u2264 now per \xA7 A.3.1"},{key:"end_time",type:"date_ms",description:"hs_meeting_end_time"},{key:"outcome",type:"string",description:'hs_meeting_outcome \u2014 "SCHEDULED" / "COMPLETED" / "CANCELED" / "RESCHEDULED" / "NO_SHOW"; drives lifecycle_state per \xA7 A.3.6'},{key:"location",type:"string",description:"hs_meeting_location"},{key:"external_url",type:"string",description:"hs_meeting_external_url \u2014 calendar-event URL when available; drives calendar-twin matcher per \xA7 A.3 body-state machine"},{key:"attendee_emails",type:"string[]",description:"attendee email list (canonical) \u2014 drives direction internal-domain analysis per \xA7 A.3.3"},{key:"owner",type:"string",description:"hubspot_owner_id (resolved to email when granted)"}]}),oe({vendor:"hubspot",entity:"note",display_name:"HubSpot Note Engagement",engagement:{capability:"always",sync_kind:"poll",daily_budget:25e4},meta_fields:[{key:"body_preview",type:"string",description:"first 256 chars of hs_note_body (display)"},{key:"created_at",type:"date_ms",description:"hs_createdate \u2014 promotes to row.event_at per \xA7 A.3.1 (notes are point-in-time; created = happened)"},{key:"owner",type:"string",description:"hubspot_owner_id (resolved to email when granted)"}]}),oe({vendor:"hubspot",entity:"call",display_name:"HubSpot Call Engagement",engagement:{capability:"always",sync_kind:"poll",daily_budget:25e4},meta_fields:[{key:"title",type:"string",description:"hs_call_title"},{key:"direction",type:"string",description:'hs_call_direction \u2014 "INBOUND" / "OUTBOUND"'},{key:"status",type:"string",description:'hs_call_status \u2014 "QUEUED" / "IN_PROGRESS" / "COMPLETED" / "NO_ANSWER" / "FAILED" / "CANCELED"; drives lifecycle_state per \xA7 A.3.6 Pass-5 R5.4'},{key:"duration_ms",type:"number",description:"hs_call_duration (milliseconds)"},{key:"disposition",type:"string",description:"hs_call_disposition"},{key:"recording_url",type:"string",description:"hs_call_recording_url when present"},{key:"timestamp",type:"date_ms",description:"hs_timestamp \u2014 promotes to row.event_at when status indicates the attempt occurred (COMPLETED / NO_ANSWER) per \xA7 A.3.1"},{key:"body_preview",type:"string",description:"first 256 chars of hs_call_body (call notes)"},{key:"owner",type:"string",description:"hubspot_owner_id (resolved to email when granted)"}]}),oe({vendor:"hubspot",entity:"task",display_name:"HubSpot Task Engagement",engagement:{capability:"always",sync_kind:"poll",daily_budget:25e4},meta_fields:[{key:"subject",type:"string",description:"hs_task_subject \u2014 drives direction subject-verb heuristic per \xA7 A.3.3"},{key:"status",type:"string",description:'hs_task_status \u2014 "NOT_STARTED" / "IN_PROGRESS" / "WAITING" / "COMPLETED" / "DEFERRED" / "CANCELED"; drives lifecycle_state per \xA7 A.3.6'},{key:"priority",type:"string",description:'hs_task_priority \u2014 "LOW" / "MEDIUM" / "HIGH"'},{key:"type",type:"string",description:'hs_task_type \u2014 "TODO" / "CALL" / "EMAIL"'},{key:"due_at",type:"date_ms",description:"hs_task_completion_date interpreted as due-date (HubSpot legacy field naming); promotes to row.due_at + due_at_is_date_only when arriving as date-only string per \xA7 A.3.7"},{key:"completed_at",type:"date_ms",description:"hs_task_completion_date when status=COMPLETED; promotes to row.completed_at + row.event_at per \xA7 A.3.1"},{key:"body_preview",type:"string",description:"first 256 chars of hs_task_body (task notes)"},{key:"owner",type:"string",description:"hubspot_owner_id (resolved to email when granted)"}]}),oe({vendor:"salesforce",entity:"opportunity",display_name:"Salesforce Opportunity",crm_alias:"deal",meta_fields:[{key:"id",type:"string",source_path:"Id",description:"vendor record Id (the canonical record selector for read/update/delete; rides the SOQL SELECT)"},{key:"name",type:"string",source_path:"Name",description:"Name field on Opportunity"},{key:"stage",type:"string",source_path:"StageName",description:"StageName (canonical Salesforce stage label)"},{key:"amount",type:"number",source_path:"Amount",description:"Amount in opportunity currency"},{key:"owner",type:"string",source_path:"OwnerId",description:"OwnerId (resolved to email when User read permission granted)"},{key:"key_dates.close_date",type:"date_ms",date_granularity:"date",source_path:"CloseDate",description:"CloseDate (parsed ISO \u2192 ms)"},{key:"key_dates.created_at",type:"date_ms",date_granularity:"datetime",source_path:"CreatedDate",description:"CreatedDate (parsed ISO \u2192 ms)"},{key:"forecast_amount",type:"number",source_path:"ForecastAmount",description:"ForecastAmount when surfaced (omitted otherwise)",select_if_present:!0},{key:"close_state",type:"string",description:'"open" | "won" | "lost" derived from IsClosed + IsWon',derivation:{kind:"closed_state",closed_path:"IsClosed",won_path:"IsWon"}},{key:"probability",type:"number",source_path:"Probability",description:"Probability percentage 0-100"},{key:"next_step",type:"string",source_path:"NextStep",description:"NextStep \u2014 the rep-authored next-step note"}]}),oe({vendor:"salesforce",entity:"contact",display_name:"Salesforce Contact",crm_alias:"contact",meta_fields:[{key:"email",type:"string",source_path:"Email",description:"canonical email (lowercase + trimmed) \u2014 primary join key against data.contact.<email>"},{key:"id",type:"string",source_path:"Id",description:"vendor record Id (the canonical record selector for read/update/delete; rides the SOQL SELECT)"},{key:"name",type:"string",description:"FirstName + LastName (space-joined); falls back to the email local-part when both absent",derivation:{kind:"concat",parts:["FirstName","LastName"],separator:" ",fallback_path:"Email",fallback_transform:"local_part"}},{key:"first_name",type:"string",source_path:"FirstName",description:"FirstName (given name)"},{key:"last_name",type:"string",source_path:"LastName",description:"LastName (family name)"},{key:"lifecycle_stage",type:"string",source_path:"LeadSource",description:"LeadSource (Salesforce native model \u2014 Web / Phone Inquiry / Partner Referral / etc.)"},{key:"owner",type:"string",source_path:"OwnerId",description:"OwnerId (resolved to email when User read permission granted)"},{key:"account_id",type:"string",source_path:"AccountId",description:"AccountId \u2014 links to salesforce.account target_id"},{key:"recent_activity_at",type:"date_ms",date_granularity:"date",source_path:"LastActivityDate",description:"LastActivityDate (parsed ISO \u2192 ms)"},{key:"phone",type:"string",source_path:"Phone",description:"Phone (canonicalized E.164 at projection time)"},{key:"mailing_address",type:"object",description:"structured mailing address from MailingStreet/City/State/PostalCode/Country"},{key:"job_title",type:"string",source_path:"Title",description:"Title \u2014 the role held at the associated account",select_if_present:!0},{key:"mailing_street",type:"string",source_path:"MailingStreet",description:"MailingStreet \u2014 the street line (vCard ADR street)"},{key:"mailing_city",type:"string",source_path:"MailingCity",description:"MailingCity (vCard ADR locality)"},{key:"mailing_region",type:"string",source_path:"MailingState",description:"MailingState \u2014 the state or region (vCard ADR region)"},{key:"mailing_postal_code",type:"string",source_path:"MailingPostalCode",description:"MailingPostalCode (vCard ADR postal code)"},{key:"mailing_country",type:"string",source_path:"MailingCountry",description:"MailingCountry (vCard ADR country)"},{key:"birthday",type:"string",source_path:"Birthdate",description:"Birthdate \u2014 YYYY-MM-DD (vCard BDAY)",select_if_present:!0}]}),oe({vendor:"salesforce",entity:"account",display_name:"Salesforce Account",crm_alias:"account",meta_fields:[{key:"id",type:"string",source_path:"Id",description:"vendor record Id (the canonical record selector for read/update/delete; rides the SOQL SELECT)"},{key:"name",type:"string",source_path:"Name",description:"Name field on Account"},{key:"domain",type:"string",source_path:"Website",description:"Website (primary domain \u2014 freeform; not canonicalized at projection; canonical account web-domain \u2014 cross-vendor with hubspot.company.domain)"},{key:"industry",type:"string",source_path:"Industry",description:"Industry tag (Salesforce standard taxonomy)"},{key:"num_employees",type:"number",source_path:"NumberOfEmployees",description:"NumberOfEmployees"},{key:"owner",type:"string",source_path:"OwnerId",description:"OwnerId (resolved to email when User read permission granted)"},{key:"annual_revenue",type:"number",source_path:"AnnualRevenue",description:"AnnualRevenue when set"}]}),oe({vendor:"pipedrive",entity:"deal",display_name:"Pipedrive Deal",crm_alias:"deal",meta_fields:[{key:"id",type:"number",source_path:"id",description:"Pipedrive deal id (the canonical record selector for read/update/delete)"},{key:"name",type:"string",source_path:"title",description:"Deal title"},{key:"stage",type:"string",source_path:"stage_id",description:"Pipedrive stage id"},{key:"amount",type:"number",source_path:"value",description:"Deal value"},{key:"owner",type:"string",source_path:"owner_id",description:"Pipedrive owner id"},{key:"pipeline",type:"string",source_path:"pipeline_id",description:"Pipedrive pipeline id"},{key:"account_id",type:"string",source_path:"org_id",description:"Linked Pipedrive organization id"},{key:"contact_id",type:"string",source_path:"person_id",description:"Linked Pipedrive person id"},{key:"key_dates.close_date",type:"date_ms",date_granularity:"date",source_path:"expected_close_date",description:"Expected close date"},{key:"key_dates.created_at",type:"date_ms",date_granularity:"datetime",source_path:"add_time",description:"Deal creation time"},{key:"updated_at",type:"date_ms",date_granularity:"datetime",source_path:"update_time",description:"Deal update time; request filters lower to updated_since / updated_until"},{key:"close_state",type:"string",source_path:"status",description:'Pipedrive status ("open" | "won" | "lost")'},{key:"probability",type:"number",source_path:"probability",description:"Deal probability percentage when set"}]}),oe({vendor:"pipedrive",entity:"person",display_name:"Pipedrive Person",crm_alias:"contact",meta_fields:[{key:"id",type:"number",source_path:"id",description:"Pipedrive person id (the canonical record selector for read/update/delete)"},{key:"name",type:"string",source_path:"name",description:"Person display name"},{key:"first_name",type:"string",source_path:"first_name",description:"First name"},{key:"last_name",type:"string",source_path:"last_name",description:"Last name"},{key:"owner",type:"string",source_path:"owner_id",description:"Pipedrive owner id"},{key:"account_id",type:"string",source_path:"org_id",description:"Linked Pipedrive organization id"},{key:"email",type:"string",source_path:"emails.0.value",description:"First email value returned by Pipedrive"},{key:"phone",type:"string",source_path:"phones.0.value",description:"First phone value returned by Pipedrive"},{key:"recent_activity_at",type:"date_ms",date_granularity:"datetime",source_path:"update_time",description:"Person update time used as the best available activity freshness marker"},{key:"updated_at",type:"date_ms",date_granularity:"datetime",source_path:"update_time",description:"Person update time; request filters lower to updated_since / updated_until"}]}),oe({vendor:"pipedrive",entity:"organization",display_name:"Pipedrive Organization",crm_alias:"account",meta_fields:[{key:"id",type:"number",source_path:"id",description:"Pipedrive organization id (the canonical record selector for read/update/delete)"},{key:"name",type:"string",source_path:"name",description:"Organization name"},{key:"domain",type:"string",source_path:"website",description:"Organization website"},{key:"industry",type:"string",source_path:"industry",description:"Industry tag when set"},{key:"num_employees",type:"number",source_path:"employee_count",description:"Employee count when set"},{key:"owner",type:"string",source_path:"owner_id",description:"Pipedrive owner id"},{key:"annual_revenue",type:"number",source_path:"annual_revenue",description:"Annual revenue when set"},{key:"updated_at",type:"date_ms",date_granularity:"datetime",source_path:"update_time",description:"Organization update time; request filters lower to updated_since / updated_until"}]}),oe({vendor:"salesforce",entity:"task",display_name:"Salesforce Task",engagement:{capability:"always",sync_kind:"stream",daily_budget:5e4},meta_fields:[{key:"subject",type:"string",description:"Subject \u2014 drives direction subject-verb heuristic per \xA7 A.3.3"},{key:"status",type:"string",description:"Status \u2014 Salesforce closed-list (NotStarted / InProgress / Completed / Waiting / Cancelled / Deferred); drives lifecycle_state per \xA7 A.3.6"},{key:"priority",type:"string",description:"Priority \u2014 closed-list (High / Normal / Low)"},{key:"task_type",type:"string",description:"TaskSubtype \u2014 Salesforce standard taxonomy"},{key:"due_at",type:"date_ms",description:"ActivityDate parsed as local-day-interval start with due_at_is_date_only per \xA7 A.3.7"},{key:"completed_at",type:"date_ms",description:"CompletedDateTime when Status=Completed; promotes to row.completed_at + row.event_at per \xA7 A.3.1"},{key:"owner",type:"string",description:"OwnerId (resolved to email when User read permission granted)"},{key:"who_id",type:"string",description:"WhoId \u2014 single-pointer fallback when TaskRelation unavailable (Contact / Lead id)"},{key:"what_id",type:"string",description:"WhatId \u2014 single-pointer fallback when TaskRelation unavailable (Account / Opportunity / etc. id)"}]}),oe({vendor:"salesforce",entity:"event",display_name:"Salesforce Event",engagement:{capability:"always",sync_kind:"stream",daily_budget:5e4},meta_fields:[{key:"subject",type:"string",description:"Subject \u2014 display name"},{key:"description",type:"string",description:"Description (truncated to 256 chars)"},{key:"start_at",type:"date_ms",description:"StartDateTime \u2014 promotes to row.scheduled_start_at; promotes to row.event_at when in the past per \xA7 A.3.1"},{key:"end_at",type:"date_ms",description:"EndDateTime"},{key:"duration_minutes",type:"number",description:"DurationInMinutes"},{key:"location",type:"string",description:"Location"},{key:"is_all_day",type:"string",description:"IsAllDayEvent (true/false as string)"},{key:"owner",type:"string",description:"OwnerId (resolved to email when User read permission granted)"},{key:"who_id",type:"string",description:"WhoId \u2014 single-pointer fallback when EventRelation unavailable"},{key:"what_id",type:"string",description:"WhatId \u2014 single-pointer fallback when EventRelation unavailable"}]}),oe({vendor:"salesforce",entity:"email_message",display_name:"Salesforce Email Message",engagement:{capability:"always",sync_kind:"stream",daily_budget:5e4},meta_fields:[{key:"subject",type:"string",description:"Subject"},{key:"from_email",type:"string",description:"FromAddress (canonical lowercase + trimmed)"},{key:"from_name",type:"string",description:"FromName (display name when present)"},{key:"to_emails",type:"string[]",description:"ToAddress split + canonicalized"},{key:"cc_emails",type:"string[]",description:"CcAddress split + canonicalized"},{key:"message_date",type:"date_ms",description:"MessageDate (parsed ISO \u2192 ms) \u2014 promotes to row.event_at per \xA7 A.3.1"},{key:"incoming",type:"string",description:'Incoming \u2014 "true" / "false" \u2014 drives direction per \xA7 A.3.3'},{key:"has_attachment",type:"string",description:'HasAttachment \u2014 "true" / "false"'},{key:"message_id",type:"string",description:"MessageIdentifier (RFC822 Message-ID for mail-twin matching when present)"},{key:"thread_id",type:"string",description:"ThreadIdentifier"},{key:"related_to_id",type:"string",description:"RelatedToId \u2014 single-pointer fallback when EmailMessageRelation unavailable"},{key:"body_preview",type:"string",description:"first 256 chars of TextBody (display)"}]}),oe({vendor:"salesforce",entity:"voice_call",display_name:"Salesforce Voice Call",engagement:{capability:"probe_gated",exclusive_group:"call",sync_kind:"stream",daily_budget:5e4},meta_fields:[{key:"call_subject",type:"string",description:"CallSubject"},{key:"call_type",type:"string",description:"CallType \u2014 INBOUND / OUTBOUND / INTERNAL \u2014 drives direction per \xA7 A.3.3"},{key:"call_disposition",type:"string",description:"CallDisposition"},{key:"call_object",type:"string",description:"CallObject \u2014 vendor-specific call subtype"},{key:"caller_number",type:"string",description:"CallerNumber"},{key:"duration_seconds",type:"number",description:"CallDurationInSeconds"},{key:"start_at",type:"date_ms",description:"CallStartDateTime \u2014 promotes to row.event_at per \xA7 A.3.1"},{key:"end_at",type:"date_ms",description:"CallEndDateTime"},{key:"owner",type:"string",description:"OwnerId (resolved to email when User read permission granted)"},{key:"contact_id",type:"string",description:"ContactId \u2014 direct contact pointer when populated"},{key:"account_id",type:"string",description:"AccountId \u2014 direct account pointer when populated"},{key:"opportunity_id",type:"string",description:"OpportunityId \u2014 direct opportunity pointer when populated"}]}),oe({vendor:"salesforce",entity:"call_history",display_name:"Salesforce Call History",engagement:{capability:"probe_gated",exclusive_group:"call",sync_kind:"stream",daily_budget:5e4},meta_fields:[{key:"call_type",type:"string",description:"CallType \u2014 INBOUND / OUTBOUND"},{key:"duration_seconds",type:"number",description:"CallDurationInSeconds"},{key:"start_at",type:"date_ms",description:"CallStartDateTime \u2014 promotes to row.event_at per \xA7 A.3.1"},{key:"owner",type:"string",description:"OwnerId (resolved to email when User read permission granted)"}]})];var Fr={deal:[{name:"id",type:["string","number"],required:!0,description:"Vendor record id \u2014 the canonical record selector. String on HubSpot/Salesforce, number on Pipedrive (D-190 C2)."},{name:"name",type:"string",required:!0,description:"Deal/opportunity title."},{name:"stage",type:"string",required:!0,description:"Pipeline stage id (raw vendor stage)."},{name:"amount",type:"number",required:!0,description:"Deal value/amount."},{name:"owner",type:"string",required:!0,description:"Owning user id."},{name:"close_state",type:"string",required:!0,enum_values:["open","won","lost"],description:"Won/lost tri-state \u2014 'open' | 'won' | 'lost' (D-190 Slice 2 rename of is_closed; enum-enforced on literal filters)."},{name:"key_dates.close_date",type:"date_ms",required:!0,description:"Expected/actual close date."},{name:"key_dates.created_at",type:"date_ms",required:!0,description:"Record creation time."},{name:"pipeline",type:"string",required:!1,description:"Pipeline id (HubSpot/Pipedrive; Salesforce has no pipeline entity)."},{name:"probability",type:"number",required:!1,description:"Win probability percentage (Salesforce/Pipedrive)."},{name:"forecast_amount",type:"number",required:!1,description:"Forecast amount (HubSpot/Salesforce)."},{name:"key_dates.next_activity_at",type:"date_ms",required:!1,description:"Next scheduled activity time (HubSpot)."},{name:"key_dates.last_activity_at",type:"date_ms",required:!1,description:"Last activity time (HubSpot)."},{name:"description",type:"string",required:!1,description:"Free-text description (HubSpot)."},{name:"next_step",type:"string",required:!1,description:"Next-step note (HubSpot)."},{name:"priority",type:"string",required:!1,description:"Priority (HubSpot)."},{name:"account_id",type:"string",required:!1,ref:{entity:"account"},description:"Linked account/organization id (Pipedrive). D-206: a REFERENCE \u2014 holds the vendor\u2019s own id of an `account`."},{name:"contact_id",type:"string",required:!1,ref:{entity:"contact"},description:"Linked contact/person id (Pipedrive). D-206: a REFERENCE \u2014 holds the vendor\u2019s own id of a `contact`, which is ALSO the key space of `ContactRecord.platform_ids[].platform_id`, so it resolves to the CORE contact in one hop."},{name:"updated_at",type:"date_ms",required:!1,description:"Record update time (Pipedrive)."}],contact:[{name:"id",type:["string","number"],required:!0,description:"Vendor record id \u2014 the canonical record selector. String on HubSpot/Salesforce, number on Pipedrive (D-190 C2)."},{name:"name",type:"string",required:!0,description:"Display name (first+last concat on HubSpot/Salesforce; native on Pipedrive)."},{name:"email",type:"string",required:!0,description:"Primary email. \u26D4 NOT a D-206 ref \u2014 identity, not a relationship (see the comment above)."},{name:"owner",type:"string",required:!0,description:"Owning user id."},{name:"first_name",type:"string",required:!1,description:"First name."},{name:"last_name",type:"string",required:!1,description:"Last name."},{name:"phone",type:"string",required:!1,description:"Primary phone."},{name:"account_id",type:"string",required:!1,ref:{entity:"account"},description:"Linked account/organization id. D-206: a REFERENCE \u2014 holds the vendor\u2019s own id of an `account`."},{name:"recent_activity_at",type:"date_ms",required:!1,description:"Most-recent activity time (Pipedrive uses update_time as a proxy)."},{name:"lifecycle_stage",type:"string",required:!1,description:"Lifecycle/lead stage (HubSpot/Salesforce; Salesforce approximates with LeadSource)."},{name:"mailing_address",type:"object",required:!1,description:"Structured mailing address (HubSpot/Salesforce; unprojected pending a compose derivation)."},{name:"company",type:"string",required:!1,description:"Company name string (HubSpot)."},{name:"job_title",type:"string",required:!1,description:"Role held at the associated company (HubSpot jobtitle / Salesforce Title). Pipedrive models a person\u2019s title as a custom field, so it maps nothing here."},{name:"industry",type:"string",required:!1,description:"Industry, as HubSpot denormalises it onto the contact. Salesforce and Pipedrive hold it only on the linked account \u2014 `account.industry` is the portable home."},{name:"updated_at",type:"date_ms",required:!1,description:"Record update time (Pipedrive)."},{name:"mailing_street",type:"string",required:!1,description:"Street line of the mailing address (vCard ADR; HubSpot address / Salesforce MailingStreet)."},{name:"mailing_city",type:"string",required:!1,description:"City of the mailing address (vCard ADR; HubSpot city / Salesforce MailingCity)."},{name:"mailing_region",type:"string",required:!1,description:"State or region of the mailing address (vCard ADR; HubSpot state / Salesforce MailingState)."},{name:"mailing_postal_code",type:"string",required:!1,description:"Postal code of the mailing address (vCard ADR; HubSpot zip / Salesforce MailingPostalCode)."},{name:"mailing_country",type:"string",required:!1,description:"Country of the mailing address (vCard ADR; HubSpot country / Salesforce MailingCountry)."},{name:"birthday",type:"string",required:!1,description:"Date of birth, YYYY-MM-DD (vCard BDAY; HubSpot date_of_birth / Salesforce Birthdate)."}],account:[{name:"id",type:["string","number"],required:!0,description:"Vendor record id \u2014 the canonical record selector. String on HubSpot/Salesforce, number on Pipedrive (D-190 C2)."},{name:"name",type:"string",required:!0,description:"Account/company/organization name."},{name:"owner",type:"string",required:!0,description:"Owning user id."},{name:"domain",type:"string",required:!1,description:"Primary web domain/website."},{name:"industry",type:"string",required:!1,description:"Industry tag."},{name:"num_employees",type:"number",required:!1,description:"Employee count."},{name:"annual_revenue",type:"number",required:!1,description:"Annual revenue."},{name:"updated_at",type:"date_ms",required:!1,description:"Record update time (Pipedrive)."}]},Ya=e=>new Set(Array.isArray(e)?e:[e]),sc=(e,t)=>Fr[e].find(n=>n.name===t);var ac=e=>new Set(Fr[e].filter(t=>t.required).map(t=>t.name)),cc=e=>{let t=[],n=[];if(e.crm_alias===void 0||!Lr.has(e.crm_alias))return{errors:t,warnings:n};let r=e.crm_alias,o=new Set;for(let a of e.meta_fields){o.add(a.key);let i=sc(r,a.key);if(i===void 0){t.push(`${e.vendor}.${e.entity}: canonical field '${a.key}' is absent from CANONICAL_CRM_FIELD_SCHEMA['${r}'] \u2014 add it to the schema (D-190 Slice 3)`);continue}if(!Ya(i.type).has(a.type)){let s=[...Ya(i.type)].join(" | ");t.push(`${e.vendor}.${e.entity}: canonical field '${a.key}' has type '${a.type}', schema accepts: ${s}`)}}for(let a of ac(r))o.has(a)||n.push(`${e.vendor}.${e.entity}: required canonical field '${a}' is not declared`);return{errors:t,warnings:n}},Xa=ic(We);if(Xa.length>0)throw new Error(`CONNECTION_VENDOR_ENTITIES boot validation failed: ${Xa.join("; ")}`);var za=We.flatMap(e=>cc(e).errors);if(za.length>0)throw new Error(`CANONICAL_CRM_FIELD_SCHEMA conformance failed: ${za.join("; ")}`);var dc=new Set(["memory","audit","enrichment","mail","calendar","contact","file","shared","service","crm","task","note","commitment","project"]);function uc(e,t=dc){let n=[];return e.forEach((r,o)=>{t.has(r.vendor)&&n.push(`[${o}] vendor '${r.vendor}' shadows a reserved data.* sub-namespace (reserved: ${[...t].sort().join(", ")}) \u2014 alias 'data.${r.vendor}.<entity>.<id>.enrichments.<topic>' would clash`)}),n}var lc=uc(We);if(lc.length>0)throw new Error(`CONNECTION_VENDOR_ENTITIES alias-prefix clash: ${lc.join("; ")}`);var bm=Object.freeze({default:"The server creates an opaque endpoint. After saving, add that URL and the selected credentials in the vendor dashboard, then confirm registration here."}),Sm=Object.freeze({default:"Register or update the endpoint above in the vendor dashboard for {{events}}. Configure the profile-declared authentication fields, then confirm below."}),Rm=Object.freeze({default:"After creation, use Set up the address at the service. Trusted core uses only the paired connection, canonical endpoint, profile-approved events, and locked registration-driver settings; packs and recipes cannot read credentials or change provider request authority."}),Am=Object.freeze({default:"Trusted core registers and reads back this exact endpoint through the paired connection. The provider request, connection credential, idempotency material, and any returned signing secret are never exposed to packs or recipes."}),Tm=Object.freeze({default:"Trusted core attaches the opaque callback URL only during the declared provider operation. The recipe cannot receive or override it; the exact paired connection must own both the resource operation and this ingress."}),Cm=Object.freeze({default:"Use a separate test-environment ingress.",test:"Use the provider or an external sender."}),Im="The Recued test uses the current credential and canonical public endpoint. It is admitted like any other delivery and may run recipes bound to this test ingress. It does not prove the vendor dashboard is configured or that a third party can reach the endpoint.",km="Retirement is permanent: intake stays closed and all active credentials are retired. Remote vendor endpoint cleanup may still be required.",vm="Core validates the replacement connection and provider ownership before changing local authority. If safe continuity cannot be proved, intake stays closed and no replacement endpoint is created implicitly.",wm=e=>Object.fromEntries(dt[e].registration_modes.map(t=>[t,t==="manual"?bm:t==="managed_endpoint"?Rm:Tm])),Ee=(e,t,n={})=>({profile_id:e,label:t,connection_placeholder:"provider-connection",registration_target:null,create_instructions:wm(e),manual_confirmation_instructions:Sm,managed_reconciliation_instructions:Am,generated_credential_instructions:null,credential_rotation_instructions:null,external_test_guidance:Cm,test_delivery_boundary:Im,manual_retirement_instructions:km,connection_rebind_instructions:vm,...n}),Om=[Ee("stripe.event.v1","Stripe events",{connection_placeholder:"stripe-live",create_instructions:{manual:{default:"Create the local ingress first. Register its displayed URL and selected events in Stripe, store the returned endpoint signing secret with Add keys, confirm registration, and let messages in yourself."},managed_endpoint:{default:"After creation, use Set up the address at the service. Trusted core creates the Stripe endpoint through the paired connection and captures its one-time signing secret; packs and recipes cannot read it."}},manual_confirmation_instructions:{default:"Register or update the endpoint above in Stripe for {{events}}. After the vendor returns the Endpoint signing secret, use Add keys here, then confirm below."},managed_reconciliation_instructions:{default:"Trusted core registers and reads back this exact Stripe endpoint through the paired connection. The API credential, provider request, idempotency key, and returned signing secret are never exposed to packs or recipes."},connection_rebind_instructions:"Core first proves compatible Stripe access. Same-account credentials keep the endpoint live; a different account closes intake, removes and confirms the old endpoint, then leaves the replacement disabled for explicit registration."}),Ee("paddle.notification.v1","Paddle notifications",{connection_placeholder:"paddle-sandbox",create_instructions:{manual:{default:"Create the local ingress first. Then use the matching Paddle Sandbox account for test or Paddle Live account for live to create an active URL notification destination for the displayed endpoint and selected events. Store that destination's Endpoint secret key with Add keys, confirm the saved destination, and let messages in yourself."},managed_endpoint:{default:"Pair a Paddle API connection containing a modern Sandbox key for test or Live key for live. After creation, use Set up the address at the service. Trusted core searches that account, refuses ambiguous destinations, fixes every notification-setting field, captures the provider-generated endpoint secret, and reads the destination back before registration completes."}},manual_confirmation_instructions:{default:"This Paddle ingress has an unsupported environment. Keep intake closed and replace it; do not register this endpoint in Paddle.",test:"In the matching Paddle Sandbox account, open Developer tools > Notifications > New destination. Choose URL, set the URL to the endpoint above, API version to 1, and Usage type to Platform and simulation. Leave sensitive fields excluded unless the consuming pack explicitly requires them, subscribe to exactly these event types: {{events}}, keep the destination active, and save it. Open that destination's overflow menu > Edit destination, then copy its Endpoint secret key into Add keys here. Confirm below only after the saved destination matches, then let messages in. After enablement, use Developer tools > Simulations > New simulation and choose this simulation-enabled destination; Recued does not synthesize Paddle deliveries.",live:"In the matching Paddle Live account, open Developer tools > Notifications > New destination. Choose URL, set the URL to the endpoint above, API version to 1, and Usage type to Platform. Leave sensitive fields excluded unless the consuming pack explicitly requires them, subscribe to exactly these event types: {{events}}, keep the destination active, and save it. Open that destination's overflow menu > Edit destination, then copy its Endpoint secret key into Add keys here. Confirm below only after the saved destination matches, then let messages in. Test separately with a Paddle Sandbox account and a test ingress; do not route simulation traffic to this live ingress."},managed_reconciliation_instructions:{default:"Trusted core refuses unsupported Paddle environments and leaves intake closed.",test:"Trusted core exhaustively searches the matching Paddle Sandbox account, refuses description or URL collisions, creates an active URL destination with API version 1, sensitive fields excluded, platform and simulation traffic, and exactly the selected events, then encrypts the provider-generated endpoint secret and reads every field back. The API key and endpoint secret are never exposed to packs or recipes.",live:"Trusted core exhaustively searches the matching Paddle Live account, refuses description or URL collisions, creates an active URL destination with API version 1, sensitive fields excluded, platform-only traffic, and exactly the selected events, then encrypts the provider-generated endpoint secret and reads every field back. The API key and endpoint secret are never exposed to packs or recipes."},credential_rotation_instructions:"Paddle endpoint secret keys do not rotate in place. For overlap-safe rotation, create a second active URL destination in the same Paddle account with the same endpoint, API version, Usage type, sensitive-field choice, and selected events. Paddle allows at most 10 active destinations; if that limit is full, deactivate a different unused destination first, never the old destination still protecting this ingress. Add the new destination's Endpoint secret key as the second credential version here, then obtain an accepted delivery signed by that version. Only after it is shown as verified should you deactivate the old Paddle destination and retire the older local credential; deactivation preserves Paddle delivery logs.",external_test_guidance:{default:"Use a separate test-environment ingress.",test:"Use Paddle simulator after enablement.",live:"Use a separate test-environment ingress."},manual_retirement_instructions:"Before confirming, deactivate this notification destination in Paddle so delivery stops while its logs remain available. Local retirement is permanent: intake stays closed and all active credentials are retired; Recued cannot verify or perform the remote deactivation.",connection_rebind_instructions:"Core verifies that the replacement is a modern Paddle key for the same environment and searches that account before changing authority. An alias for the same destination keeps it live; otherwise intake closes, the old destination is removed and confirmed absent, and registration on the replacement remains explicit."}),Ee("lemonsqueezy.webhook.v1","Lemon Squeezy webhooks",{create_instructions:{manual:{default:"Create the local ingress first. In the matching Lemon Squeezy test or live store, open Settings > Webhooks, create a webhook for the displayed callback URL and selected events, choose a strong signing secret, then enter that exact secret with Add keys before you confirm it and let messages in."}},manual_confirmation_instructions:{default:"In the matching Lemon Squeezy environment, save one webhook whose callback URL is the exact endpoint above, whose subscribed events are exactly {{events}}, and whose signing secret exactly matches the active signing_secret entered with Add keys. Confirm below only after saving that remote webhook, then let messages in yourself.",test:"In Lemon Squeezy test mode, save one webhook whose callback URL is the exact endpoint above, whose subscribed events are exactly {{events}}, and whose signing secret exactly matches the active signing_secret entered with Add keys. Confirm below only after saving that remote webhook, then let messages in and use a test-mode simulation or dashboard resend.",live:"In Lemon Squeezy live mode, save one webhook whose callback URL is the exact endpoint above, whose subscribed events are exactly {{events}}, and whose signing secret exactly matches the active signing_secret entered with Add keys. Confirm below only after saving that remote webhook, then let messages in. Validate separately with a test ingress rather than routing test traffic here."},credential_rotation_instructions:"Add the replacement signing_secret as a second local credential version, update this same Lemon Squeezy webhook to the replacement secret, and obtain an accepted delivery verified by the new version. Only then retire the older local credential.",external_test_guidance:{default:"Use Lemon Squeezy test mode or resend a recent webhook from its dashboard after intake is enabled.",test:"Use a Lemon Squeezy test-mode simulation or resend a recent test webhook after intake is enabled.",live:"Use a separate Lemon Squeezy test-mode ingress; do not send test traffic to this live ingress."},test_delivery_boundary:"No Recued-originated test delivery is available for this profile. Use Lemon Squeezy test mode or its dashboard resend after letting messages in; that proves vendor delivery while recipe effects remain asynchronous.",manual_retirement_instructions:"Delete or disable the matching webhook in Lemon Squeezy before confirming local retirement. Local retirement is permanent: intake stays closed and all active credentials are retired; Recued cannot verify or perform the remote cleanup."}),Ee("slack.request.v0","Slack requests",{connection_placeholder:"slack-api",manual_confirmation_instructions:{default:"Register or update the endpoint above in the Slack app configuration for {{events}}, store the app signing secret with Add keys, and confirm below."}}),Ee("slack.slash-command.v1","Slack slash commands",{connection_placeholder:"slack-app",create_instructions:{manual:{default:"Create a separate ingress for Slack slash commands. This v1 profile covers Slack apps with public distribution disabled. After saving, open Features > Slash Commands in the Slack app, create or edit every intended command, set each Request URL to the displayed endpoint, and copy the app Signing Secret from Basic Information into Add keys."}},manual_confirmation_instructions:{default:"Under Features > Slash Commands in the Slack app, set every intended command's Request URL to the exact endpoint above and copy that app's Signing Secret from Basic Information into Add keys. Confirm only after every intended command uses this endpoint. Slash commands do not use the Events API url_verification challenge, so this profile becomes registration-ready from this manual confirmation. Do not use this v1 profile while public distribution is active because its ssl_check request is not supported. After letting messages in, invoke one configured command to test it. Recued returns an empty 200 acknowledgement and triggers the bound recipe; it withholds response_url and the deprecated token field and does not send a command response."},external_test_guidance:{default:"After letting messages in, invoke a configured slash command in Slack. This profile has no Recued-originated delivery simulator.",test:"After letting messages in, invoke a configured slash command in a test workspace or test app."},test_delivery_boundary:"No Recued-originated test delivery is available for this profile. Invoke the configured command in Slack after letting messages in; the empty acknowledgement proves receipt only, while recipe effects remain asynchronous."}),Ee("telegram.bot-webhook.v1","Telegram bot updates",{connection_placeholder:"telegram-bot-backup",create_instructions:{manual:{default:"Create the local ingress to mint a one-time Webhook secret token. Then call Telegram Bot API setWebhook with the displayed URL, secret_token, and selected allowed_updates before confirming registration here."},managed_endpoint:{default:"After creation, use Set up the address at the service. Trusted core verifies the bot has no conflicting webhook, sets its singleton URL and allowed updates, and stores a generated secret token that packs and recipes cannot read."}},manual_confirmation_instructions:{default:"Call Telegram Bot API setWebhook with the endpoint above as url, the one-time Webhook secret token generated here as secret_token, and {{events}} as allowed_updates. If the token is no longer available, swap the keys to make a new one, then confirm below."},managed_reconciliation_instructions:{default:"Trusted core reads the bot webhook before every mutation, refuses a conflicting URL, preserves the encrypted generated token across updates, and confirms the exact URL and allowed updates afterward. The bot token and webhook secret are never exposed to packs or recipes."},generated_credential_instructions:"Call Telegram Bot API setWebhook with the endpoint above as url, this generated value as secret_token, and {{events}} as allowed_updates. Telegram accepts only one webhook per bot, so update the bot before retiring an older local credential.",connection_rebind_instructions:"Core first reads the replacement bot without changing it. Another connection for the same bot keeps the singleton live; a different empty bot closes intake, removes and confirms the old webhook, then leaves the replacement disabled for explicit registration. A bot with any conflicting webhook is refused."}),Ee("github.webhook.v1","GitHub webhooks",{connection_placeholder:"github-api-backup",registration_target:{modes:["managed_endpoint"],kind_label:"GitHub target type",key_label:"GitHub target (required)",key_normalization:"lowercase",required_message:"Choose a GitHub repository or organization target before creating this webhook.",kinds:[{value:"repository",label:"Repository",key_placeholder:"owner/repository"},{value:"organization",label:"Organization",key_placeholder:"organization"}]},create_instructions:{manual:{default:"Create the local ingress to mint a one-time Webhook secret. Then open the repository or organization Settings > Webhooks in GitHub: use the displayed Payload URL, set Content type to application/json, paste the secret, keep SSL verification enabled, choose Let me select individual events, subscribe to exactly the selected events, leave Active selected, and confirm registration here. GitHub sends an immediate ping while Recued intake is still closed; after confirming and enabling, redeliver that ping or trigger a selected event."},managed_endpoint:{default:"Choose one repository or organization and pair a GitHub API connection containing a personal access token. Trusted core fixes every REST path and field, verifies access to that exact target, generates the webhook secret, and reads the hook back before registration completes."}},manual_confirmation_instructions:{default:"In GitHub repository or organization Settings > Webhooks, set Payload URL to the endpoint above, Content type to application/json, Secret to the one-time Webhook secret generated here, keep SSL verification enabled, choose Let me select individual events, subscribe to exactly these event types: {{events}}, and leave Active selected. If the secret is no longer available, swap the keys to make a new one. Confirm below only after that exact hook configuration is saved in GitHub, then let them in here and use GitHub Recent deliveries to Redeliver the initial ping or trigger a selected event. GitHub does not automatically redeliver failed deliveries."},managed_reconciliation_instructions:{default:"Trusted core searches only the selected {{target_kind}} {{target_key}}, refuses ambiguous or foreign hooks, generates and encrypts the signing secret, and reads the exact URL, events, active state, JSON content type, and SSL verification back. The personal access token and webhook secret are never exposed to packs or recipes. GitHub sends its immediate setup ping before you let messages in and will not retry that failure automatically; after that, let messages in and use Recent deliveries to redeliver that ping or trigger a selected event."},generated_credential_instructions:"In GitHub repository or organization Settings > Webhooks, set Payload URL to the endpoint above, Content type to application/json, Secret to this generated webhook_secret, keep SSL verification enabled, choose Let me select individual events, subscribe to exactly these event types: {{events}}, and leave Active selected. GitHub sends an immediate ping while Recued intake is still closed and does not automatically redeliver a failure; after confirming and enabling here, open Recent deliveries and Redeliver that ping or trigger a selected event. For rotation, update this same GitHub hook to the new secret, obtain an accepted delivery verified by the new credential, and only then retire the older local version.",credential_rotation_instructions:"Saving mints a new Webhook secret credential version and shows its plaintext once. GitHub accepts one secret for a hook: update that same hook first, obtain an accepted delivery verified by the new credential, and only then retire the older local version.",test_delivery_boundary:"The Recued test uses the canonical public endpoint and may run recipes bound to this test ingress. During a two-secret rotation it deliberately signs with the older active credential, so it cannot verify the replacement or unlock retirement of the older version. It does not prove the GitHub dashboard is configured or that GitHub can reach the endpoint.",connection_rebind_instructions:"Core verifies the replacement personal access token against the same repository or organization before changing authority. If target continuity cannot be proved, intake stays closed and no foreign hook is mutated."}),Ee("cal.webhook.v1","Cal.com booking and meeting webhooks",{connection_placeholder:"calcom",create_instructions:{manual:{default:"Enter a strong signing secret to create the Recued webhook address. Then add that address in Cal.com, use the same secret, and select exactly the event types requested by the installed recipe before confirming setup here."}},manual_confirmation_instructions:{default:"In Cal.com Settings > Developer > Webhooks, paste the Recued address above, enter the same signing secret, and select only {{events}}. Confirm below after saving."},external_test_guidance:{default:"Trigger one of the selected Cal.com events with a test booking. For transcript events, complete a Cal Video meeting with transcription enabled."},test_delivery_boundary:"The Recued test confirms that this address accepts a correctly signed Cal.com-style event of the selected type. It cannot confirm that Cal.com saved the webhook; trigger the selected event with a test booking to prove the external connection.",credential_rotation_instructions:"Add the replacement secret in Recued, update the same Cal.com webhook to that secret, obtain one accepted delivery, and only then retire the older local credential."}),Ee("generic.static-header-token.v1","Static header token"),Ee("generic.raw-body-hmac-sha256.v1","Raw-body HMAC SHA-256"),Ee("generic.timestamped-raw-body-hmac-sha256.v1","Timestamped raw-body HMAC SHA-256"),Ee("generic.http-basic.v1","HTTP Basic"),Ee("recued-peer.exchange.v1","Recued peer exchange",{connection_placeholder:"peer-server",generated_credential_instructions:"Recued generates this signing secret. Give it to the peer owner over a channel you both already trust; they store it on their outbound connection to you, and it is what their deliveries are signed with. The secret authenticates the PEER, not the person who sent it to you \u2014 treat a leaked value as a peer impersonation and rotate. Rotation overlaps: add the new secret, have the peer switch, confirm one accepted delivery verified by the new version, then retire the old one.",credential_rotation_instructions:"Add the replacement before the peer switches. Two versions verify at once, so an in-flight delivery signed with either is accepted; retire the older only after an accepted delivery proves the new one is live."})],cn=e=>Object.freeze({...e}),xm=e=>Object.freeze({...e,registration_target:e.registration_target===null?null:Object.freeze({...e.registration_target,modes:Object.freeze([...e.registration_target.modes]),kinds:Object.freeze(e.registration_target.kinds.map(t=>Object.freeze({...t})))}),create_instructions:Object.freeze(Object.fromEntries(Object.entries(e.create_instructions).map(([t,n])=>[t,cn(n)]))),manual_confirmation_instructions:cn(e.manual_confirmation_instructions),managed_reconciliation_instructions:cn(e.managed_reconciliation_instructions),external_test_guidance:cn(e.external_test_guidance)}),Pm=/{{([a-z_]+)}}/g,Nm=new Set(["events","environment","target_kind","target_key"]),Kr=(e,t)=>{if(typeof t=="string"){if(t.length===0||t.length>16384)throw new Error(`Invalid webhook owner settings text '${e}'`);let n=t.replace(Pm,(r,o)=>{if(!Nm.has(o))throw new Error(`Unknown webhook owner template token '${o}'`);return""});if(n.includes("{{")||n.includes("}}"))throw new Error(`Malformed webhook owner template token '${e}'`);return}if(t!==null){if(Array.isArray(t)){for(let n of t)Kr(e,n);return}if(typeof t!="object")throw new Error(`Webhook owner settings '${e}' are not serializable`);for(let n of Object.values(t))Kr(e,n)}},Dm=e=>{let t=dt[e.profile_id];Kr(e.profile_id,e);let n=Object.keys(e.create_instructions);for(let o of n)if(!t.registration_modes.includes(o))throw new Error(`Webhook owner settings '${e.profile_id}' describe undeclared mode '${o}'`);if(n.length!==t.registration_modes.length||t.registration_modes.some(o=>!Object.prototype.hasOwnProperty.call(e.create_instructions,o)))throw new Error(`Webhook owner settings '${e.profile_id}' do not cover every declared mode`);let r=e.registration_target;if(r!==null&&(r.kinds.length===0||new Set(r.kinds.map(o=>o.value)).size!==r.kinds.length||r.kinds.some(o=>!/^[a-z][a-z0-9_-]{0,63}$/.test(o.value))||r.modes.length===0||new Set(r.modes).size!==r.modes.length||r.modes.some(o=>!t.registration_modes.includes(o))))throw new Error(`Invalid webhook owner registration-target settings '${e.profile_id}'`)},ln=Object.create(null);for(let e of Om){if(Dm(e),Object.prototype.hasOwnProperty.call(ln,e.profile_id))throw new Error(`Duplicate webhook owner settings '${e.profile_id}'`);ln[e.profile_id]=xm(e)}for(let e of lt)if(!Object.prototype.hasOwnProperty.call(ln,e))throw new Error(`Missing webhook owner settings '${e}'`);var Lm=Object.freeze(ln);var Mm=["crm","acct"],yE=new Set(Mm);var Bm=[{domain:"ai",class:"closed_kind"},{domain:"storage",class:"closed_kind"},{domain:"work-entity",class:"closed_kind"},{domain:"notification",class:"closed_kind"},{domain:"preapproval",class:"closed_kind"},{domain:"mail",class:"closed_kind"},{domain:"contact",class:"closed_kind"},{domain:"memory",class:"closed_kind"},{domain:"recall",class:"closed_kind"},{domain:"audit",class:"closed_kind"},{domain:"peer",class:"closed_kind"},{domain:"data",class:"closed_kind"},{domain:"webhook",class:"closed_kind"},{domain:"schedule",class:"closed_kind"},{domain:"kitchen",class:"closed_kind"},{domain:"reminder",class:"closed_kind"},{domain:"situation",class:"closed_kind"},{domain:"seller",class:"closed_kind"},{domain:"customer",class:"closed_kind"},{domain:"watch",class:"closed_kind"},{domain:"dom",class:"closed_kind"},{domain:"http",class:"closed_kind"},{domain:"crm",class:"canonical_convention",required_connection_kind:"crm"},{domain:"acct",class:"canonical_convention",required_connection_kind:"acct"}],Um=new Map(Bm.map(e=>[e.domain,e])),pc=e=>Um.get(e);var Fm=["read","search"],Km=["create","update","delete"],EE=new Set(Fm),bE=new Set(Km),SE={crm:new Set(ht),acct:new Set(yt)};var Hm=["mail","calendar","contact","file","shared","memory","audit","enrichment","work","form_response","webhook","peer","seller","notification","recall","reminder","situation","ai","browser","schedule","watch","web","crm","recipe"];var IE=new Set(Hm),A=(e,t,n,r,o)=>({op:e,domain:t,backing_slug:n,risk:r,entity:o}),ce=(e,t,n,r,o)=>({op:e,domain:t,risk:n,entity:r,native:!0,...o!==void 0?{mcp_tool:o}:{}}),Je=[A("core.ai.classify","ai","core-ai-classify","read","ai"),A("core.ai.compare","ai","core-ai-compare","read","ai"),A("core.ai.embed","ai","core-ai-embed","read","ai"),A("core.ai.extract","ai","core-ai-extract","read","ai"),A("core.ai.generate","ai","core-ai-generate","read","ai"),A("core.ai.prompt","ai","core-ai-prompt","read","ai"),A("core.ai.rewrite","ai","core-ai-rewrite","read","ai"),A("core.ai.score","ai","core-ai-score","read","ai"),A("core.ai.sentiment","ai","core-ai-sentiment","read","ai"),A("core.ai.summarize","ai","core-ai-summarize","read","ai"),A("core.ai.translate","ai","core-ai-translate","read","ai"),A("core.mail.get","mail","mail-get","read","mail"),A("core.mail.body-read","mail","mail-body-read","read","mail"),A("core.mail.thread-read","mail","mail-thread-reader","read","mail"),A("core.mail.fact.get","mail","mail-fact-get","read","mail"),A("core.mail.fact.list","mail","mail-fact-list","read","mail"),A("core.mail.send","mail","mail-send","write","mail"),A("core.mail.notify-booking-visitor","mail","notify-booking-visitor","write","mail"),A("core.mail.sent.reconcile","mail","mail-sent-reconcile","write","mail"),A("core.mail.mark","mail","mail-mark","write","mail"),A("core.mail.flag","mail","mail-flag","write","mail"),A("core.mail.move","mail","mail-move","write","mail"),A("core.mail.delete","mail","mail-delete","destructive","mail"),A("core.mail.email.get","mail","email-get","read","mail"),A("core.mail.email.list","mail","email-list","read","mail"),A("core.mail.email.search","mail","email-search","read","mail"),A("core.contact.resolve","contact","contact-resolve","read","contact"),A("core.contact.business-context","contact","contact-business-context","read","contact"),A("core.contact.upsert","contact","contact-upsert","write","contact"),ce("core.contact.engagements.read","contact","read","contact"),ce("core.contact.write","contact","write","contact"),A("core.notification.send","notification","core-notification-send","read","notification"),A("core.preapproval.request","preapproval","preapproval-request","read","notification"),A("core.reminder.create","reminder","reminder-create","read","notification"),A("core.reminder.list","reminder","reminder-list","read","reminder"),A("core.reminder.update","reminder","reminder-update","write","reminder"),A("core.reminder.cancel","reminder","reminder-cancel","write","reminder"),A("core.mail.draft.create","mail","mail-draft-create","write","mail"),A("core.mail.draft.read","mail","mail-draft-read","read","mail"),A("core.mail.draft.update","mail","mail-draft-update","write","mail"),A("core.mail.draft.delete","mail","mail-draft-delete","destructive","mail"),A("core.mail.draft.save-to-mailbox","mail","mail-draft-save-to-mailbox","write","mail"),A("core.notification.recipe-callback","notification","core-notification-recipe-callback","write","notification"),A("core.work-entity.note.create","work-entity","note-create","write","work"),A("core.work-entity.note.update","work-entity","note-update","write","work"),A("core.work-entity.note.delete","work-entity","note-delete","destructive","work"),A("core.work-entity.task.create","work-entity","task-create","write","work"),A("core.work-entity.approval-workflow.continue","work-entity","approval-workflow-continue","write","recipe"),A("core.work-entity.customer-invoice.credit","work-entity","customer-invoice-credit","destructive","work"),A("core.work-entity.customer-refund.apply","work-entity","customer-refund-apply","destructive","work"),A("core.work-entity.customer-refund.correct","work-entity","customer-refund-correct","destructive","work"),A("core.work-entity.customer-invoice.credit.correct","work-entity","customer-invoice-credit-correct","destructive","work"),A("core.work-entity.customer-account-payment.correct","work-entity","customer-account-payment-correct","destructive","work"),A("core.work-entity.customer-account-payment.apply","work-entity","customer-account-payment-apply","destructive","work"),A("core.work-entity.customer-payment.correct","work-entity","customer-payment-correct","destructive","work"),A("core.work-entity.quote-completion.review","work-entity","quote-completion-review","write","work"),A("core.work-entity.quote-signoff.release","work-entity","quote-signoff-release","write","work"),A("core.work-entity.task.update","work-entity","task-update","write","work"),A("core.work-entity.task.delete","work-entity","task-delete","destructive","work"),A("core.work-entity.task.mark-done","work-entity","task-mark-done","write","work"),A("core.work-entity.task.mark-reminder-fired","work-entity","task-mark-reminder-fired","read","work"),A("core.work-entity.commitment.create","work-entity","commitment-create","write","work"),A("core.work-entity.commitment.propose","work-entity","commitment-propose","write","work"),A("core.work-entity.commitment.update","work-entity","commitment-update","write","work"),A("core.work-entity.commitment.cancel","work-entity","commitment-cancel","write","work"),A("core.work-entity.commitment.fulfill","work-entity","commitment-fulfill","write","work"),A("core.work-entity.project.create","work-entity","project-create","write","work"),A("core.work-entity.project.update","work-entity","project-update","write","work"),A("core.work-entity.project.archive","work-entity","project-archive","write","work"),A("core.work-entity.booking.create","work-entity","booking-create","write","work"),A("core.work-entity.booking.update","work-entity","booking-update","write","work"),A("core.work-entity.booking.delete","work-entity","booking-delete","destructive","work"),A("core.work-entity.asset.create","work-entity","asset-create","write","work"),A("core.work-entity.asset.update","work-entity","asset-update","write","work"),A("core.work-entity.asset.delete","work-entity","asset-delete","destructive","work"),A("core.work-entity.asset.observe","work-entity","asset-observe","read","work"),A("core.work-entity.list","work-entity","work-entity-list","read","work"),A("core.work-entity.get","work-entity","work-entity-get","read","work"),ce("core.work-entity.read","work-entity","read","work"),A("core.situation.read","situation","situation-query","read","situation"),ce("core.situation.prefetch","situation","read","situation"),ce("core.situation.record","situation","write","situation"),A("core.memory.annotation.create","memory","annotation-create","write","memory"),A("core.memory.annotation.delete","memory","annotation-delete","write","memory"),A("core.memory.annotation.list","memory","annotation-list","read","memory"),A("core.memory.annotation.search","memory","annotation-search","read","memory"),A("core.memory.link.create","memory","link-create","write","memory"),A("core.memory.link.delete","memory","link-delete","write","memory"),A("core.memory.link.list","memory","link-list","read","memory"),A("core.memory.timeline.read","memory","timeline-read","read","memory"),ce("core.audit.read","audit","read","audit"),ce("core.memory.write","memory","write","memory"),ce("core.memory.read","memory","read","memory"),ce("core.recall.search","recall","read","recall"),A("core.data.enrichment.upsert","data","enrichment-upsert","write","enrichment"),A("core.data.enrichment.list","data","enrichment-list","read","enrichment"),ce("core.data.enrichment.read","data","read","enrichment"),ce("core.data.enrichment.vector-search","data","read","enrichment"),ce("core.data.enrichment.describe","data","read","enrichment"),A("core.data.calendar.get","data","calendar-get","read","calendar"),A("core.data.calendar.list","data","calendar-list","read","calendar"),A("core.data.calendar.search","data","calendar-search","read","calendar"),A("core.data.calendar.stat","data","calendar-stat","read","calendar"),A("core.data.calendar.create","data","calendar-create","write","calendar"),A("core.data.calendar.update","data","calendar-update","write","calendar"),A("core.data.calendar.delete","data","calendar-delete","destructive","calendar"),A("core.data.calendar.rsvp","data","calendar-rsvp","write","calendar"),A("core.data.form-response.list","data","form-response-list","read","form_response"),A("core.data.form-response.get","data","form-response-get","read","form_response"),A("core.data.form-response.set-state","data","form-response-set-state","write","form_response"),A("core.webhook.event.get","webhook","webhook-event-get","read","webhook"),A("core.peer.ask","peer","peer-ask","write","peer"),ce("core.peer.receive-ask","peer","write","peer","recued_peerAsk"),ce("core.peer.receive-answer","peer","write","peer","recued_peerAnswer"),A("core.storage.shared.write","storage","shared-write","write","shared"),A("core.storage.shared.compare-and-set","storage","shared-compare-and-set","write","shared"),A("core.storage.shared.patch","storage","shared-patch","write","shared"),A("core.storage.shared.read","storage","shared-read","read","shared"),A("core.storage.exchange.status","storage","exchange-status","read","peer"),A("core.storage.shared.delete","storage","shared-delete","write","shared"),A("core.storage.shared.delete-prefix","storage","shared-delete-prefix","destructive","shared"),A("core.storage.shared.list","storage","shared-list","read","shared"),A("core.storage.shared.search","storage","shared-search","read","shared"),A("core.storage.file.read","storage","file-read","read","file"),A("core.storage.file.write","storage","file-write","write","file"),A("core.storage.file.delete","storage","file-delete","destructive","file"),A("core.storage.file.get","storage","file-get","read","file"),A("core.storage.file.list","storage","file-list","read","file"),A("core.storage.file.move","storage","file-move","destructive","file"),A("core.storage.file.stat","storage","file-stat","read","file"),A("core.storage.file.persist","storage","file-persist","write","file"),A("core.storage.file.read-temp","storage","file-read-temp","read","file"),A("core.storage.file.put-ref","storage","file-put-ref","write","file"),A("core.storage.file.folders","storage","file-folders","read","file"),A("core.storage.file.save-to-folder","storage","file-save-to-folder","write","file"),A("core.storage.file.render-markdown-template","storage","file-render-markdown-template","write","file"),A("core.storage.file.set-scan-status","storage","file-set-scan-status","write","file"),ce("core.storage.file.fetch-remote","storage","read","file"),A("core.storage.csv.filter","storage","csv-filter","write","file"),A("core.storage.csv.rows","storage","csv-rows","read","file"),A("core.storage.csv.stats","storage","csv-stats","read","file"),A("core.storage.csv.columns","storage","csv-columns","read","file"),A("core.storage.csv.inspect","storage","csv-inspect","read","file"),A("core.storage.csv.transform","storage","csv-transform","write","file"),A("core.storage.ics.read","storage","ics-read","read","file"),A("core.storage.data-file-read","storage","data-file-read","read","file"),ce("core.schedule.recipe","schedule","write","schedule"),ce("core.schedule.prompt","schedule","write","schedule"),A("core.kitchen.draft.import","kitchen","kitchen-draft-import","write","recipe"),A("core.kitchen.draft.list","kitchen","kitchen-draft-list","read","recipe"),A("core.kitchen.draft.get","kitchen","kitchen-draft-get","read","recipe"),A("core.kitchen.draft.update","kitchen","kitchen-draft-update","write","recipe"),A("core.seller.offer.ensure","seller","seller-offer-ensure","write","seller"),A("core.seller.offer.attach-fulfillment","seller","seller-offer-attach-fulfillment","write","seller"),A("core.seller.offer.get","seller","seller-offer-get","read","seller"),A("core.seller.offer.list","seller","seller-offer-list","read","seller"),A("core.seller.order.open","seller","seller-order-open","write","seller"),A("core.seller.order.get","seller","seller-order-get","read","seller"),A("core.seller.order.list","seller","seller-order-list","read","seller"),A("core.seller.order.quote","seller","seller-order-quote","write","seller"),A("core.seller.order.attach-payment","seller","seller-order-attach-payment","write","seller"),A("core.seller.order.confirm-payment","seller","seller-order-confirm-payment","write","seller"),A("core.seller.order.confirm-renewal-payment","seller","seller-order-confirm-renewal-payment","write","seller"),A("core.seller.order.confirm-refund","seller","seller-order-confirm-refund","write","seller"),A("core.seller.order.attach-artifact","seller","seller-order-attach-artifact","write","seller"),A("core.seller.order.transition","seller","seller-order-transition","write","seller"),A("core.seller.order.link-work-entity","seller","seller-order-link-work-entity","write","seller"),A("core.seller.order.link-customer","seller","seller-order-link-customer","write","seller"),A("core.seller.tier.get","seller","seller-tier-get","read","seller"),A("core.seller.tier.list","seller","seller-tier-list","read","seller"),A("core.seller.customer-access.issue","seller","customer-access-issue","write","seller"),A("core.seller.customer-access.extend","seller","customer-access-extend","write","seller"),A("core.seller.customer-access.swap-tier","seller","customer-access-swap-tier","write","seller"),A("core.seller.customer-access.close","seller","customer-access-close","write","seller"),ce("core.customer.status","customer","read","seller"),A("core.watch.time","watch","time-watcher","read","watch"),A("core.watch.time-relative","watch","time-relative-watcher","read","watch"),A("core.watch.http","watch","http-watcher","read","watch"),A("core.dom.read","dom","dom-read","read","browser"),A("core.dom.write","dom","dom-write","write","browser"),A("core.dom.inspect","dom","dom-inspect","read","browser"),A("core.dom.click","dom","dom-click","write","browser"),A("core.dom.tabs","dom","dom-tabs","read","browser"),A("core.dom.open","dom","dom-open","write","browser"),A("core.dom.wait","dom","dom-wait","read","browser"),A("core.dom.table","dom","dom-table","read","browser"),A("core.dom.screenshot","dom","dom-screenshot","read","browser"),A("core.dom.scroll","dom","dom-scroll","read","browser"),A("core.dom.download","dom","dom-download","read","browser"),A("core.dom.act","dom","dom-act","write","browser"),A("core.http.get","http","http-get","read","web"),A("core.http.read","http","http-read","read","web"),A("core.http.download","http","http-download","read","web")],Vm=(e=Je)=>{let t=new Set,n=new Map;for(let r of e){let o=sa(r.op);if(o===null||o.tier!=="kernel")throw new Error("kernel-op-registry: malformed kernel op id "+JSON.stringify(r.op));if(o.domain!==r.domain)throw new Error("kernel-op-registry: op "+JSON.stringify(r.op)+" domain segment "+JSON.stringify(o.domain)+" != declared domain "+JSON.stringify(r.domain));let a=pc(r.domain);if(a===void 0||a.class!=="closed_kind")throw new Error("kernel-op-registry: op "+JSON.stringify(r.op)+" domain is not a registered closed-kind kernel domain: "+JSON.stringify(r.domain));if(r.native===!0){if(r.backing_slug!==void 0)throw new Error("kernel-op-registry: native op "+JSON.stringify(r.op)+" must not declare a backing_slug (no backing ingredient)")}else if(typeof r.backing_slug!="string"||r.backing_slug.length===0)throw new Error("kernel-op-registry: op "+JSON.stringify(r.op)+" has an empty backing_slug");if(t.has(r.op))throw new Error("kernel-op-registry: duplicate op id "+JSON.stringify(r.op));if(t.add(r.op),r.native!==!0&&r.backing_slug!==void 0){let i=n.get(r.backing_slug);if(i!==void 0)throw new Error("kernel-op-registry: backing_slug "+JSON.stringify(r.backing_slug)+" is shared by ops "+JSON.stringify(i)+" and "+JSON.stringify(r.op)+" \u2014 backing slugs must be unique (the reverse map would collide)");n.set(r.backing_slug,r.op)}}};Vm();var kE=new Map(Je.map(e=>[e.op,e])),vE=new Map(Je.flatMap(e=>e.native!==!0&&e.backing_slug!==void 0?[[e.backing_slug,e.op]]:[]));var wE=new Set(Je.filter(e=>e.domain==="ai"||e.domain==="watch").map(e=>e.op).concat(["core.notification.recipe-callback"]));var OE=new Map(Je.filter(e=>e.mcp_tool!==void 0).map(e=>[e.mcp_tool,e.op]));var xE=new Map(Je.filter(e=>e.mcp_tool!==void 0).map(e=>[e.op,e.mcp_tool]));var gc=["ui","bridge",...Oe,"email"],Gm=[...Oe,"email","in_app"],jm=[...Oe,"email"],Hr={ui:{notification:!0,approval:!0,messenger:!0},bridge:{notification:!0,approval:!1,messenger:!1},email:{notification:!0,approval:!0,messenger:!1},...Object.fromEntries(Ne.map(e=>[e.vendor,e.roles]))},_c=gc.filter(e=>{let t=Hr[e];return!t.notification&&!t.approval&&!t.messenger});if(_c.length>0)throw new Error(`CHANNEL_ROLES boot validation failed \u2014 channel(s) declaring no role at all: ${_c.join(", ")}. A channel that can neither notify, approve, nor converse cannot do anything.`);var Wm=e=>Object.keys(e).filter(t=>e[t].approval&&!e[t].notification),mc=Wm(Hr);if(mc.length>0)throw new Error(`CHANNEL_ROLES boot validation failed \u2014 channel(s) declaring approval without notification: ${mc.join(", ")}. An ask is an unprompted send plus a way to answer it; a channel Recued cannot reach unprompted cannot carry one.`);var bt=6e4,$m=10*bt,qm=30*bt,Ym=15*bt,Xm=30*bt,zm=5*bt,Et={user:{channel:"user",base_authority:"debounce",cognition_eligible:!1,debounce_threshold_ms:$m},chat:{channel:"chat",base_authority:"debounce",cognition_eligible:!0,debounce_threshold_ms:qm},mcp:{channel:"mcp",base_authority:"debounce",cognition_eligible:!1,debounce_threshold_ms:Ym},messenger:{channel:"messenger",base_authority:"debounce",cognition_eligible:!0,debounce_threshold_ms:Xm},reception:{channel:"reception",base_authority:"debounce",cognition_eligible:!1,debounce_threshold_ms:zm},webhook:{channel:"webhook",base_authority:"plan_completion",cognition_eligible:!1,debounce_threshold_ms:null},schedule:{channel:"schedule",base_authority:"plan_completion",cognition_eligible:!1,debounce_threshold_ms:null},reactive:{channel:"reactive",base_authority:"plan_completion",cognition_eligible:!1,debounce_threshold_ms:null},housekeeping:{channel:"housekeeping",base_authority:"plan_completion",cognition_eligible:!1,debounce_threshold_ms:null}};for(let e of Object.values(Et))Object.freeze(e);Object.freeze(Et);var fc=()=>{for(let t of Yt){let n=Et[t];if(n.channel!==t)throw new Error(`D-153 P6 cut-model for '${t}' has a mismatched channel field '${n.channel}'.`);if(n.base_authority==="cognition_driven")throw new Error(`D-153 P6 cut-model for '${t}': base_authority must be cognition-independent, got 'cognition_driven'.`);let r=n.base_authority==="debounce",o=n.debounce_threshold_ms,a=typeof o=="number"&&Number.isFinite(o)&&o>0;if(r!==a)throw new Error(`D-153 P6 cut-model for '${t}' breaks the threshold invariant: base_authority='${n.base_authority}', debounce_threshold_ms=${String(o)}.`);if(n.cognition_eligible&&!r)throw new Error(`D-153 P6 cut-model for '${t}' is cognition_eligible but base_authority is not 'debounce'.`)}let e=Object.keys(Et).length;if(e!==Yt.length)throw new Error(`D-153 P6 cut-model registry size mismatch: CHANNEL_CUT_MODELS has ${e} entries; CHANNELS lists ${Yt.length}.`)};fc();var Qm=Object.freeze({quiescent_since:null});var De=["intent_forming","intent_committed","executing","intent_satisfied","closed"],hc=e=>typeof e=="string"&&De.includes(e),yc=e=>e==="closed",St={intent_forming:["intent_committed","closed"],intent_committed:["executing","intent_satisfied","closed"],executing:["intent_satisfied","closed"],intent_satisfied:["closed"],closed:[]};for(let e of Object.values(St))Object.freeze(e);Object.freeze(St);var dn=5,un=3e4;var Ec=["append_to_pool","classify","new_session"],bc=e=>typeof e=="string"&&Ec.includes(e),_n={intent_forming:"append_to_pool",intent_committed:"classify",executing:"classify",intent_satisfied:"new_session",closed:"new_session"};Object.freeze(_n);var pn=["refinement","switch","parallel","meta"];var Rt={refinement:{opens_new_session:!1,closes_active_session:!1},switch:{opens_new_session:!0,closes_active_session:!0},parallel:{opens_new_session:!0,closes_active_session:!1},meta:{opens_new_session:!1,closes_active_session:!1}};for(let e of Object.values(Rt))Object.freeze(e);Object.freeze(Rt);var Sc=()=>{for(let r of De){let o=De.indexOf(r),a=St[r];for(let s of a){if(!hc(s))throw new Error(`D-153 P7 LIFECYCLE_TRANSITIONS['${r}'] has unknown target '${String(s)}'.`);if(s===r)throw new Error(`D-153 P7 LIFECYCLE_TRANSITIONS['${r}'] contains a self-edge.`);if(De.indexOf(s)<=o)throw new Error(`D-153 P7 LIFECYCLE_TRANSITIONS['${r}'] \u2192 '${s}' is not a forward transition \u2014 the lifecycle is monotone-forward.`)}let i=yc(r);if(i!==(a.length===0))throw new Error(`D-153 P7 LIFECYCLE_TRANSITIONS['${r}'] breaks the terminal invariant: isTerminalLifecycleState=${i}, transition count=${a.length}.`);if(!bc(_n[r]))throw new Error(`D-153 P7 MESSAGE_ROUTING_BY_STATE['${r}'] is not a known MessageRouting.`)}for(let r of pn){let o=Rt[r];if(o.closes_active_session&&!o.opens_new_session)throw new Error(`D-153 P7 ROUTING_EFFECTS['${r}'] closes the active session without opening a new one \u2014 a bare cancel is not a routing disposition.`)}let e=Object.keys(St).length,t=Object.keys(_n).length;if(e!==De.length||t!==De.length)throw new Error(`D-153 P7 registry size mismatch: SESSION_LIFECYCLE_STATES lists ${De.length}; LIFECYCLE_TRANSITIONS has ${e}, MESSAGE_ROUTING_BY_STATE has ${t}.`);let n=Object.keys(Rt).length;if(n!==pn.length)throw new Error(`D-153 P7 registry size mismatch: ROUTING_DISPOSITIONS lists ${pn.length}; ROUTING_EFFECTS has ${n}.`);if(!Number.isInteger(dn)||dn<=0)throw new Error(`D-153 P7 INPUT_POOL_MAX_MESSAGES must be a positive integer, got ${String(dn)}.`);if(!Number.isFinite(un)||un<=0)throw new Error(`D-153 P7 INPUT_POOL_WINDOW_MS must be a positive finite number, got ${String(un)}.`)};Sc();var At=["manual","user_confirmed","vendor_meta","contact_book","derived","ai_inferred","domain_inferred"],Rc=new Set(At);var Ac=Object.freeze(Object.fromEntries(At.map((e,t)=>[e,t]))),UE=Number.MAX_SAFE_INTEGER;var Tc=["name","org","title","address","photo","birthday","anniversary"],Vr=new Set(Tc);var FE=Object.freeze({manual:"manual",contact_book:"contact_book",crm_import:"vendor_meta",email_from:"derived",email_to:"derived",calendar_attendee:"derived"});var Jm=Object.freeze({name:"name",company:"org",phone:"phone",mailing_address:"address"});if(Object.keys(Ac).length!==At.length)throw new Error("CONTACT_CONTRIBUTION_SOURCE_PRIORITY is out of sync with CONTACT_CONTRIBUTION_SOURCES");var tg=["mention_only","partial","verified"],VE=new Set(tg);var Cc="[\\p{L}\\p{N}!#$%&'*+/=?^_`{|}~-]",Ic="[\\p{L}\\p{N}](?:[\\p{L}\\p{N}-]{0,61}[\\p{L}\\p{N}])?",GE=new RegExp(`^${Cc}+(?:\\.${Cc}+)*@${Ic}(?:\\.${Ic})+$`,"u");var ng=["family","work","social","other"],jE=new Set(ng);var rg=["chat_alias","platform_id","email_alias","phone_alias"],kc=new Set(rg);var og=["facebook","x","instagram","linkedin","github","substack"],WE=new Set(og);var vc=["approval","automation_rule_changed","cert.rotation_notice","cert.rotation_reverted","chat.connection_mcp_annotation_changed","chat.data_diagnosis_resolved","chat.default_model_pref_changed","chat.disambiguation_proposed","chat.inbound_token_changed","chat.message_complete","chat.plan_proposed","chat.plan_resolved","chat.session_changed","chat.token_streamed","chat.tool_call_completed","chat.tool_call_started","chat.tool_catalog_scope_changed","chat.transparency","connection.vendor_oauth_completed","contract.contract_definition_changed","contract.delegation_rule_suggested","contract.delegation_rule_suggestion_resolved","contract.scoped_grant_suggested","contract.scoped_grant_suggestion_resolved","enrichment_drift_detected","enrichment_promotion_suggested","entitlement","execution","exposure_changed","housekeeping_cycle","mail_fact","memory","merge_candidate","merge_scan_progress","notification","notification.ask","notification.ask_closed","notification.bridge_mode_changed","notification.notify","pack_installed","pack_uninstalled","pair.list_changed","reactive_fire","reception.emergency_disabled","reception.endpoint_changed","reception_inbox","recipe_runnability_changed","records","remerge_prompt","schedule","session_lifecycle","supervision","token.rotated","update.progress","upstream_merge_failed","warehouse"];var Gr=new Set(vc);var ig=/^events\.subscribe: unknown kind '([^']*)' \(not in BROADCAST_EVENT_KIND_SET\)$/,wc=e=>{if(e===null||typeof e!="object")return null;let{code:t,message:n}=e;return t!=="bad_request"||typeof n!="string"?null:ig.exec(n)?.[1]??null},jr=async(e,t)=>{let n=[...t.kinds],r=[];for(;;)try{let o=await e({...t,kinds:n});return{ack:o,left_out:[...r,...o.unknown_kinds??[]]}}catch(o){let a=wc(o);if(a===null||n.length<=1||!n.some(i=>i===a))throw o;n=n.filter(i=>i!==a),r.push(a)}};var mn=()=>{let e=new Map;return{set:(t,n)=>{e.set(t,n)},get:t=>e.get(t),delete:t=>{let n=e.get(t);return n?(clearTimeout(n.timeout),e.delete(t)):!1},clear:t=>{for(let n of e.values())clearTimeout(n.timeout),n.reject(new Error(t));e.clear()},values:()=>e.values(),size:()=>e.size}};var Wr=["full","full_then_delta"],Pc=new Set(Wr),$r=["none","cursor","delta_link","page_token","stream_position"],Nc=new Set($r),qr=["oauth","connection","access_key"],Dc=new Set(qr),Oc=/^[a-z][a-z0-9_]*$/,sg=["path","mime_type","size","mtime","owner","revision"];function Yr(e){let t=[];if(e===null||typeof e!="object"||Array.isArray(e))return["expected object"];let n=e;if((typeof n.vendor!="string"||!Oc.test(n.vendor))&&t.push(`field 'vendor' must match ${Oc.source}`),(typeof n.display_name!="string"||n.display_name.length===0)&&t.push("field 'display_name' must be a non-empty string"),n.list===null||typeof n.list!="object"||Array.isArray(n.list))t.push("field 'list' must be an object");else{let r=n.list,o=typeof r.mode=="string"&&Pc.has(r.mode),a=typeof r.cursor_kind=="string"&&Nc.has(r.cursor_kind);o||t.push(`list.mode must be one of ${Wr.join(" / ")}`),a||t.push(`list.cursor_kind must be one of ${$r.join(" / ")}`),o&&a&&(r.mode==="full"&&r.cursor_kind!=="none"&&t.push("list.cursor_kind must be 'none' when list.mode is 'full'"),r.mode==="full_then_delta"&&r.cursor_kind==="none"&&t.push("list.cursor_kind must be a real cursor (not 'none') when list.mode is 'full_then_delta'"))}if(n.projection===null||typeof n.projection!="object"||Array.isArray(n.projection))t.push("field 'projection' must be an object");else{let r=n.projection;(typeof r.filename!="string"||r.filename.length===0)&&t.push("projection.filename is required (non-empty vendor field name)"),(typeof r.remote_id!="string"||r.remote_id.length===0)&&t.push("projection.remote_id is required (non-empty vendor field name)");for(let o of sg){let a=r[o];a!==void 0&&(typeof a!="string"||a.length===0)&&t.push(`projection.${o} must be a non-empty vendor field name when present`)}}return n.scope===null||typeof n.scope!="object"||Array.isArray(n.scope)?t.push("field 'scope' must be an object"):typeof n.scope.supports_prefix!="boolean"&&t.push("scope.supports_prefix must be a boolean"),(typeof n.auth!="string"||!Dc.has(n.auth))&&t.push(`field 'auth' must be one of ${qr.join(" / ")}`),t}function Lc(e){let t=Yr(e);if(t.length>0)throw new Error(`invalid FileVendorDeclaration '${String(e.vendor)}': ${t.join("; ")}`)}function Le(e){return Lc(e),e}function Mc(e){let t=[],n=new Set;return e.forEach((r,o)=>{for(let a of Yr(r))t.push(`[${o}] ${a}`);n.has(r.vendor)?t.push(`[${o}] duplicate vendor '${r.vendor}' \u2014 only one entry per vendor allowed`):n.add(r.vendor)}),t}var Bc=[Le({vendor:"dropbox",display_name:"Dropbox",list:{mode:"full_then_delta",cursor_kind:"cursor"},projection:{filename:"name",path:"path_display",size:"size",mtime:"server_modified",revision:"rev",remote_id:"id"},scope:{supports_prefix:!0},auth:"oauth"}),Le({vendor:"s3",display_name:"Amazon S3",list:{mode:"full",cursor_kind:"none"},projection:{filename:"name",path:"Key",size:"Size",mtime:"LastModified",revision:"ETag",owner:"Owner.DisplayName",remote_id:"Key"},scope:{supports_prefix:!0},auth:"access_key"}),Le({vendor:"onedrive",display_name:"OneDrive",list:{mode:"full_then_delta",cursor_kind:"delta_link"},projection:{filename:"name",path:"path",mime_type:"file.mimeType",size:"size",mtime:"lastModifiedDateTime",revision:"eTag",remote_id:"id"},scope:{supports_prefix:!1},auth:"oauth"}),Le({vendor:"google",display_name:"Google Drive",list:{mode:"full_then_delta",cursor_kind:"page_token"},projection:{filename:"name",mime_type:"mimeType",size:"size",mtime:"modifiedTime",revision:"version",owner:"owners.0.displayName",remote_id:"id"},scope:{supports_prefix:!1},auth:"oauth"}),Le({vendor:"box",display_name:"Box",list:{mode:"full_then_delta",cursor_kind:"stream_position"},projection:{filename:"name",path:"path",size:"size",mtime:"modified_at",revision:"etag",owner:"owned_by.name",remote_id:"id"},scope:{supports_prefix:!1},auth:"oauth"}),Le({vendor:"sharepoint",display_name:"SharePoint",list:{mode:"full_then_delta",cursor_kind:"delta_link"},projection:{filename:"name",path:"path",mime_type:"file.mimeType",size:"size",mtime:"lastModifiedDateTime",revision:"eTag",remote_id:"id"},scope:{supports_prefix:!1},auth:"oauth"}),Le({vendor:"notion",display_name:"Notion",list:{mode:"full",cursor_kind:"none"},projection:{filename:"filename",path:"path",mtime:"mtime",remote_id:"remote_id"},scope:{supports_prefix:!1},auth:"connection"})];var xc=Mc(Bc);if(xc.length>0)throw new Error(`FILE_VENDOR_DECLARATIONS boot validation failed: ${xc.join("; ")}`);var Xr=["full_import","hydrate_on_match"],Kc=new Set(Xr),zr=["vendor_meta","contact_book"],Hc=new Set(zr),Qr=["email_alias","phone_alias"],Vc=new Set(Qr),gn=/^[a-z][a-z0-9_]*$/,Uc=(e,t,n,r)=>{let o=[];if(!Array.isArray(e))return o.push(`supplies.${t} must be an array`),o;!r&&e.length===0&&o.push(`supplies.${t} must be non-empty \u2014 a source that supplies no identifier cannot attach its records to any person`);let a=new Set;for(let i of e){if(typeof i!="string"||!n.has(i)){o.push(`supplies.${t} contains an unknown kind '${String(i)}'`);continue}a.has(i)&&o.push(`supplies.${t} lists '${i}' twice`),a.add(i)}return o};function Jr(e){let t=[];if(e===null||typeof e!="object"||Array.isArray(e))return["expected object"];let n=e;(typeof n.vendor!="string"||!gn.test(n.vendor))&&t.push(`field 'vendor' must match ${gn.source}`),(typeof n.display_name!="string"||n.display_name.length===0)&&t.push("field 'display_name' must be a non-empty string"),(typeof n.rung!="string"||!Hc.has(n.rung))&&t.push(`field 'rung' must be one of ${zr.join(" / ")} \u2014 an importer may never write a user rung (manual / user_confirmed) or one of Recued's own (derived / ai_inferred / domain_inferred)`),(typeof n.import_scope!="string"||!Kc.has(n.import_scope))&&t.push(`field 'import_scope' must be one of ${Xr.join(" / ")}`),n.vendor_entity!==null&&(typeof n.vendor_entity!="string"||!gn.test(n.vendor_entity))&&t.push(`field 'vendor_entity' must be null or match ${gn.source}`);let r=null;if(n.supplies===null||typeof n.supplies!="object"||Array.isArray(n.supplies))t.push("field 'supplies' must be an object");else{let o=n.supplies;t.push(...Uc(o.aliases,"aliases",kc,!1)),t.push(...Uc(o.attributes,"attributes",Vr,!0)),Array.isArray(o.aliases)&&(r=o.aliases.filter(a=>typeof a=="string"))}if(!Array.isArray(n.match_on))t.push("field 'match_on' must be an array");else{n.match_on.length===0&&t.push("field 'match_on' must be non-empty \u2014 a source with no join key matches nothing and would import silently into the void");let o=new Set;for(let a of n.match_on){if(typeof a!="string"||!Vc.has(a)){t.push(`match_on '${String(a)}' cannot key a match \u2014 only ${Qr.join(" / ")} have a contact-store resolver; any other kind would silently match zero contacts`);continue}o.has(a)&&t.push(`match_on lists '${a}' twice`),o.add(a),r!==null&&!r.includes(a)&&t.push(`match_on '${a}' is not in supplies.aliases \u2014 matching on an identifier the source never imports would silently import nothing`)}}return t}function Gc(e){let t=Jr(e);if(t.length>0)throw new Error(`invalid ContactSourceDeclaration '${String(e.vendor)}': ${t.join("; ")}`)}function Ze(e){return Gc(e),e}function jc(e){let t=[],n=new Set;return e.forEach((r,o)=>{for(let a of Jr(r))t.push(`[${o}] ${a}`);n.has(r.vendor)?t.push(`[${o}] duplicate vendor '${r.vendor}' \u2014 only one entry per vendor allowed`):n.add(r.vendor)}),t}var Wc=[Ze({vendor:"hubspot",display_name:"HubSpot Contacts",rung:"vendor_meta",import_scope:"hydrate_on_match",vendor_entity:"contact",supplies:{aliases:["email_alias","phone_alias"],attributes:["name","org","address","birthday"]},match_on:["email_alias"]}),Ze({vendor:"salesforce",display_name:"Salesforce Contacts",rung:"vendor_meta",import_scope:"hydrate_on_match",vendor_entity:"contact",supplies:{aliases:["email_alias","phone_alias"],attributes:["name","address","birthday"]},match_on:["email_alias"]}),Ze({vendor:"google",display_name:"Google Contacts",rung:"contact_book",import_scope:"full_import",vendor_entity:null,supplies:{aliases:["email_alias","phone_alias"],attributes:["name","org","address","photo","birthday","anniversary"]},match_on:["email_alias"]}),Ze({vendor:"pipedrive",display_name:"Pipedrive People",rung:"vendor_meta",import_scope:"hydrate_on_match",vendor_entity:"person",supplies:{aliases:["email_alias","phone_alias"],attributes:["name"]},match_on:["email_alias"]}),Ze({vendor:"microsoft",display_name:"Outlook Contacts",rung:"contact_book",import_scope:"full_import",vendor_entity:null,supplies:{aliases:["email_alias","phone_alias"],attributes:["name","org","address","birthday"]},match_on:["email_alias"]})];var Fc=jc(Wc);if(Fc.length>0)throw new Error(`CONTACT_SOURCE_DECLARATIONS boot validation failed: ${Fc.join("; ")}`);var ag="bearer.",$c="recued.v1",cg=e=>{let t="";for(let n of e)t+=String.fromCharCode(n);return btoa(t).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"")};var qc=e=>`${ag}${cg(new TextEncoder().encode(e))}`;var Qc="<all_urls>",lg="recued",Jc=e=>({async get(t,n,r){if(t!==lg)return e.fallback.get(t,n,r);let o;try{o=await e.grantedOrigins()}catch{return null}return o.length===0?null:{publisher_id:t,slug:n,version:r,granted_origins:[...o],granted_at:0}},put:t=>e.fallback.put(t),remove:(t,n,r)=>e.fallback.remove(t,n,r),list:()=>e.fallback.list(),clear:()=>e.fallback.clear()}),zc="blocked_sites";var yn="The owner listed this site as one Recued must never use, so nothing was read or done there.",Zc="The Browser Bridge could not read the owner's list of sites Recued must never use, so it did nothing.",Zr=e=>{let t=e.trim();if(t===""||/\s/.test(t))return null;let n;try{n=new URL(/^[a-z][a-z\d+.-]*:\/\//i.test(t)?t:`https://${t}`)}catch{return null}if(n.protocol!=="http:"&&n.protocol!=="https:")return null;let r=n.hostname.toLowerCase().replace(/\.$/,"");return r===""?null:r},Ae=(e,t)=>{let n;try{n=new URL(e).hostname.toLowerCase().replace(/\.$/,"")}catch{return!1}return n!==""&&t.some(r=>n===r||n.endsWith(`.${r}`))},En=async e=>{let t=(await e.get([zc]))[zc];if(t===void 0)return[];if(!Array.isArray(t))throw new Error("bridge: the list of blocked sites is not a list");return t.map(n=>{let r=typeof n=="string"?Zr(n):null;if(r===null)throw new Error("bridge: the list of blocked sites holds something that is not a site");return r})};var el={max_chars:4e4,max_value_chars:2e3},bn=(e,t,n,r=0)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||n!=null&&location.href!==n)return{blocked:!0};let o=globalThis,a=o.recuedPageRefs??={next:1,byRef:new Map,byElement:new WeakMap},i=[...a.byRef].filter(([,h])=>!h.isConnected);for(let[h,S]of i.slice(0,Math.max(0,i.length-r)))a.byRef.delete(h),a.byElement.delete(S);let s;if(e.ref!==void 0){if(s=a.byRef.get(e.ref)??null,!s)return{stale:!0}}else if(e.selector!==void 0){try{s=document.querySelector(e.selector)}catch{return{invalid:!0}}if(!s)return{missing:!0}}else s=document.body??document.documentElement;let c=new Set(["script","style","noscript","template","object","embed","link","meta","base","head"]),d=new Set(["area","br","col","embed","hr","img","input","source","track","wbr"]),f=["id","name","type","role","href","alt","title","placeholder","for","aria-label","data-testid","contenteditable","aria-expanded","aria-checked","aria-selected","aria-modal"],u=new Set(["button","link","checkbox","radio","switch","tab","menuitem","menuitemcheckbox","menuitemradio","option","textbox","searchbox","combobox","slider","spinbutton","treeitem"]),m=/(^|\s)(current-password|new-password|one-time-code|cc-\S+)(\s|$)/i,p=h=>h.length>t.max_value_chars?`${h.slice(0,t.max_value_chars)}\u2026`:h,l=h=>h.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;"),_=(h,S)=>` ${h}="${l(p(S)).replace(/"/g,"&quot;")}"`,y=h=>h.getAttribute("aria-hidden")!=="true"&&(h.checkVisibility({checkVisibilityCSS:!0})||(h.ownerDocument.defaultView??window).getComputedStyle(h).display==="contents"),g=h=>{try{return globalThis.chrome?.dom?.openOrClosedShadowRoot?.(h)??h.shadowRoot}catch{return h.shadowRoot}},E=h=>{if(h.localName==="slot"){let S=h.assignedNodes({flatten:!0});return S.length>0?S:[...h.childNodes]}return[...(g(h)??h).childNodes]},T=0,I=h=>{let S=h.localName==="input"?h.type:"";return S==="password"||S==="hidden"||m.test(h.getAttribute("autocomplete")??"")},k=h=>{let S=h.localName;if(S==="a")return h.hasAttribute("href");if(["button","input","select","textarea","summary"].includes(S))return!0;if(h.isContentEditable)return!h.parentElement?.isContentEditable;if(u.has((h.getAttribute("role")??"").trim().split(/\s+/)[0]))return!0;let w=h.getAttribute("tabindex");return w!==null&&w.trim()!==""&&Number(w)>=0},C='li, tr, [role="row"], [role="listitem"], [role="option"], [role="article"], article',x=h=>(h??"").replace(/\s+/g," ").trim(),F=h=>{let S=h.form??h.closest("form"),w=h.parentElement?.closest(C)??null,N=h.matches("input, textarea, select")?"":x(h.textContent).slice(0,200),H=x(h.getAttribute("aria-label")),V=x(h.getAttribute("title")),q=x(h.getAttribute("placeholder")),Y=w===null?"":x(w.textContent).slice(0,300);return{tag:h.localName,type:x(h.getAttribute("type")).toLowerCase(),name:h.getAttribute("name")??"",role:x(h.getAttribute("role")).toLowerCase(),label:H.toLowerCase(),placeholder:q.toLowerCase(),title:V.toLowerCase(),text:N.toLowerCase(),value:h.matches('input[type="submit" i], input[type="button" i], input[type="reset" i]')?x(h.value).toLowerCase():"",href:h.getAttribute("href")??"",form:S===null?"":`${S.id}|${S.getAttribute("action")??""}|${x(S.getAttribute("method")).toLowerCase()}`,row:Y.toLowerCase(),links:w===null?"":[...w.querySelectorAll("a[href]")].filter(W=>W!==h).map(W=>W.getAttribute("href")??"").sort().join(" ").slice(0,300),shows:(H||N||V||q||h.localName).slice(0,60),in:Y.slice(0,80)}};a.seen??=new WeakMap,a.print=F;let M=h=>{let S=a.byElement.get(h);return S===void 0&&(S=`e${a.next++}`,a.byElement.set(h,S),a.byRef.set(S,h)),S},G=h=>{let S=h.localName,w=`<${S}`;k(h)&&(w+=` ref="${M(h)}"`,a.seen.set(h,F(h)));for(let H of f){let V=h.getAttribute(H);V!==null&&(w+=_(H,V))}let N=[...h.classList].filter(H=>H.length>=3&&!/[\d:[]/.test(H)).slice(0,3);if(N.length>0&&(w+=_("class",N.join(" "))),h.hasAttribute("disabled")&&(w+=" disabled"),S==="dialog"&&h.matches(":modal")&&(w+=" modal"),S==="input"){let H=h;H.type==="checkbox"||H.type==="radio"?H.checked&&(w+=" checked"):H.type!=="file"&&!I(h)&&H.value!==""&&(w+=_("value",H.value))}return`${w}>`},U=[],j=0,P=0,D=!1,K=0,O=h=>j+h.length+P<=t.max_chars,B=h=>{U.push(h),j+=h.length},v=h=>{let S=null;try{S=h.contentDocument}catch{S=null}let w="<iframe",N=typeof h.src=="string"?h.src:"";/^https?:/i.test(N)&&(w+=_("src",N));let H=h.getAttribute("title")??h.getAttribute("name");if(H&&(w+=_("title",H)),S!==null){if(S.documentElement?.hasAttribute("data-recued-owner-surface"))return;let q=S.body??S.documentElement,Y="</iframe>";if(!O(`${w}>${Y}`)){D=!0;return}let W=U.length;if(B(`${w}>`),P+=Y.length,q&&b(q),P-=Y.length,D&&U.length===W+1){U.length=W,j-=w.length+1;return}B(Y);return}T+=1;let V=`${w}${_("data-recued-frame",String(T))}></iframe>`;O(V)?B(V):D=!0},b=h=>{if(D)return;if(h.nodeType===Node.TEXT_NODE){let q=h.nodeValue??"";if(q.trim()==="")return;let Y=l(p(K>0?q:q.replace(/\s+/g," ")));O(Y)?B(Y):D=!0;return}if(h.nodeType!==Node.ELEMENT_NODE)return;let S=h,w=S.localName;if(w==="slot"){if(y(S))for(let q of E(S))b(q);return}if(c.has(w)||!y(S))return;if(w==="iframe"||w==="frame"){v(S);return}let N=G(S),H=d.has(w)?"":`</${w}>`;if(!O(N+H)){D=!0;return}let V=U.length;if(B(N),P+=H.length,w==="textarea"){let q=I(S)?"":l(p(S.value));O(q)?B(q):D=!0}else if(w==="select")for(let q of[...S.options]){let Y=q.text.trim(),W="<option";if(q.value!==Y&&(W+=_("value",q.value)),q.selected&&!I(S)&&(W+=" selected"),W+=`>${l(p(Y))}</option>`,!O(W)){D=!0;break}B(W)}else if(w!=="svg"&&!d.has(w)){w==="pre"&&K++;for(let q of E(S))b(q);w==="pre"&&K--}if(P-=H.length,D&&U.length===V+1){U.length=V,j-=N.length;return}B(H)};return b(s),{outputs:{url:location.href,title:p(document.title),html:U.join(""),truncated:D}}},Me=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};let r=globalThis.recuedPageRefs,o;if(e.ref!==void 0){if(o=r?.byRef.get(e.ref)??null,!o?.isConnected)return{stale:!0}}else{try{o=document.querySelector(e.selector??"")}catch{return{invalid:!0}}if(!o)return{missing:!0}}let a=o.localName,i=o,s=o.isContentEditable===!0,c={textbox:"text field",searchbox:"search box",combobox:"list",listbox:"list",menuitem:"menu item",menuitemcheckbox:"menu item",menuitemradio:"menu item",spinbutton:"number field",treeitem:"tree item"},d={checkbox:"checkbox",radio:"radio button",button:"button",submit:"button",reset:"button",image:"button",range:"slider",number:"number field",search:"search box",file:"file picker",password:"password field"},f=(o.getAttribute("role")??"").trim().split(/\s+/)[0],u=f==="combobox"&&(a==="input"||a==="textarea")?"text field":f?c[f]??f:a==="a"&&o.hasAttribute("href")?"link":a==="button"||a==="summary"?"button":a==="select"?"list":a==="textarea"?"text field":a==="input"?d[i.type]??"text field":s?"text editor":a,m=k=>(k??"").replace(/\s+/g," ").trim(),p=o.getAttribute("aria-labelledby"),l="labels"in o&&i.labels?[...i.labels].map(k=>m(k.textContent)).join(" "):"",_=a==="input"||a==="select"||a==="textarea"||s?"":o.innerText,y=m(o.getAttribute("aria-label"))||(p?p.split(/\s+/).map(k=>m((o.getRootNode().getElementById?.(k)??o.ownerDocument.getElementById(k))?.textContent)).join(" ").trim():"")||m(l)||(a==="input"&&["button","submit","reset"].includes(i.type)?m(i.value):"")||m(o.getAttribute("alt"))||m(_)||m(o.getAttribute("placeholder"))||m(o.getAttribute("aria-placeholder"))||m(o.getAttribute("title"))||m(o.getAttribute("name")),g=a==="input"?i.type:"",E=g==="password"||g==="hidden"||/(^|\s)(current-password|new-password|one-time-code|cc-\S+)(\s|$)/i.test(o.getAttribute("autocomplete")??""),T=k=>k.length>200?`${k.slice(0,200)}\u2026`:k,I;if(n!=null&&o.getRootNode()===document){let k=n.generated.map(([P,D])=>new RegExp(P,D)),C=P=>k.some(D=>D.test(P)),x=P=>P.length>0&&P.length<=n.max_value_chars&&!/[\n\r\t]/.test(P)&&!P.includes("{{"),F=P=>P.replace(/\\/g,"\\\\").replace(/"/g,'\\"'),M=P=>{let D=P.id;if(D!==""&&!C(D)&&!D.includes("{{")){if(/^-?[A-Za-z_][\w-]*$/.test(D))return`#${D}`;if(x(D))return`${P.localName}[id="${F(D)}"]`}for(let K of n.precedence){let O=P.getAttribute(K);if(!(O===null||!x(O))&&!(n.identifier_like.includes(K)&&C(O)))return`${P.localName}[${K}="${F(O)}"]`}return null},G=P=>{let D=1;for(let K=P.previousElementSibling;K!==null;K=K.previousElementSibling)K.localName===P.localName&&(D+=1);return`${P.localName}:nth-of-type(${String(D)})`},U=P=>{try{let D=document.querySelectorAll(P);return D.length===1&&D[0]===o}catch{return!1}},j=M(o);if(j!==null&&U(j))I=j;else{let P=[j??G(o)],D=o.parentElement;for(let K=0;;K+=1){let O=P.join(" > ");if(U(O)){I=O;break}if(D===null||K>=n.max_depth)break;P.unshift(M(D)??G(D)),D=D.parentElement}}}return{outputs:{url:location.href,title:T(document.title),role:u,label:T(y),protected:E,...I!==void 0?{stable_selector:I}:{}}}},fe=yr,de=Er,_e=e=>`${e.tab_id}:${e.document_id}`,Be=e=>{if(typeof e!="string")return null;let t=/^(\d{1,10}):([\w-]{1,128})$/.exec(e);if(!t)return null;let n=Number(t[1]);return Number.isSafeInteger(n)?{tab_id:n,document_id:t[2]}:null},tl=200,et=e=>{let{page:t,ref:n,selector:r,max_chars:o,max_value_chars:a}=e,i=t===void 0?void 0:Be(t);if(i===null)return{error:"The page handle is not one an inspect answered."};if(n!==void 0&&(typeof n!="string"||!/^e[1-9]\d{0,8}$/.test(n)))return{error:"A ref looks like e12."};if(r!==void 0&&(typeof r!="string"||r.trim()===""))return{error:"The selector is empty."};if(n!==void 0&&r!==void 0)return{error:"Give a ref or a selector, not both."};if(n!==void 0&&i===void 0)return{error:"A ref needs the page it came from."};let s=(d,f)=>d===void 0?f:Number.isSafeInteger(d)&&d>=1?Math.min(d,6e5):void 0,c={max_chars:s(o,el.max_chars),max_value_chars:s(a,el.max_value_chars)};return c.max_chars===void 0||c.max_value_chars===void 0?{error:"max_chars and max_value_chars are whole numbers of characters."}:{scope:{...n!==void 0?{ref:n}:{},...r!==void 0?{selector:r}:{}},...i!==void 0?{page:i}:{},limits:{max_chars:c.max_chars,max_value_chars:c.max_value_chars}}},xe=e=>{let t=et(e);return"error"in t?t:t.scope.ref===void 0&&t.scope.selector===void 0?{error:"Name the element: a ref or a selector."}:t},nl=(e,t,n,r,o={})=>{let a=(d,f)=>({status:"error",error:{code:d,message:f}}),i=a("unknown","bridge: no readable answer from the page");if(!e||typeof e!="object"||Array.isArray(e)||Object.keys(e).length!==1)return i;let s=e;if(s.blocked===!0)return a("tab_navigation_blocked",n.blockedMessage);if(s.missing===!0)return a("selector_not_found","No element on the page matches the selector.");if(s.invalid===!0)return a("selector_not_found","The selector is not valid CSS.");if(s.stale===!0)return a("selector_not_found",fe);let c=s.outputs;return!c||typeof c!="object"||Array.isArray(c)||Object.keys(c).filter(d=>!(d in o)).sort().join()!==Object.keys(r).sort().join()||Object.entries(r).some(([d,f])=>typeof c[d]!==f)||Object.entries(o).some(([d,f])=>d in c&&typeof c[d]!==f)?i:n.pattern!==void 0&&!te(c.url,[n.pattern])?a("tab_navigation_blocked","The page is no longer on a site this step may read."):{status:"ok",outputs:{page:_e(t),...c}}},Sn=(e,t,n)=>nl(e,t,n,{url:"string",title:"string",html:"string",truncated:"boolean"}),Ue=(e,t,n)=>nl(e,t,n,{url:"string",title:"string",role:"string",label:"string",protected:"boolean"},{stable_selector:"string"}),Tt=e=>async(t,n,r)=>{let a=(await e.executeScript({target:{tabId:t.tab_id,...t.document_id!==void 0?{documentIds:[t.document_id]}:{}},func:n,args:r}))[0];return a&&typeof a.documentId=="string"?{document_id:a.documentId,result:a.result,...typeof a.frameId=="number"?{frame_id:a.frameId}:{}}:null},dg=2e3,ug=()=>({url:location.href,in_top:window.parent===window.top,owner:document.documentElement?.hasAttribute("data-recued-owner-surface")===!0}),rl=e=>async t=>{let n;return(await Promise.race([e.executeScript({target:{tabId:t,allFrames:!0},func:ug,args:[],injectImmediately:!0}),new Promise((o,a)=>{n=setTimeout(()=>a(new Error("the frames did not answer in time")),dg)})]).finally(()=>clearTimeout(n))).flatMap(o=>{let a=o.result;return typeof o.frameId=="number"&&o.frameId!==0&&typeof o.documentId=="string"&&a&&typeof a.url=="string"&&a.owner!==!0?[{frame_id:o.frameId,document_id:o.documentId,url:a.url,in_top:a.in_top===!0}]:[]})},Rn=(e,t,n,r)=>{let o=/<iframe((?: [\w-]+="[^"]*")*) data-recued-frame="\d+"><\/iframe>/g;if(!e.includes('data-recued-frame="'))return e;let a=p=>p.replace(/&quot;/g,'"').replace(/&lt;/g,"<").replace(/&gt;/g,">").replace(/&amp;/g,"&"),i=p=>{try{return new URL(p).origin}catch{return""}},s=(n??[]).filter(p=>p.in_top&&!r(p.url)),c=new Set,d=(p,l)=>{let _=s.find(y=>!c.has(y)&&l(y));return _!==void 0&&c.add(_),_},f=[...e.matchAll(o)].map(p=>{let l=a(/ src="([^"]*)"/.exec(p[1])?.[1]??"");return{attributes:p[1],src:l}}),u=f.map(({src:p})=>p===""?void 0:d(p,l=>l.url===p));f.forEach(({src:p},l)=>{u[l]===void 0&&p!==""&&(u[l]=d(p,_=>i(_.url)===i(p)))});let m=0;return e.replace(o,(p,l)=>{let _=u[m];return m+=1,_===void 0?`<iframe${l} unread=""></iframe>`:`<iframe${l} page="${String(t)}:${_.document_id}"></iframe>`})};var pg=1e3,_g="This page is a frame inside another page and cannot be pictured on its own: take the screenshot of the page that shows it, which pictures the frame as shown.",eo=.875,to=(e,t,n,r,o=.875,a=!0)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};if(a&&window!==window.top)return{framed:!0};let i={width:window.innerWidth,height:window.innerHeight},s=document.title.length>200?`${document.title.slice(0,200)}\u2026`:document.title,c=null;if(e.ref!=null){if(c=globalThis.recuedPageRefs?.byRef.get(e.ref)??null,!c?.isConnected)return{stale:!0}}else if(e.selector!=null){try{c=document.querySelector(e.selector)}catch{return{invalid:!0}}if(!c)return{missing:!0}}let d=globalThis;r!=null&&d.recuedScreenshotScroll?.token!==r&&(d.recuedScreenshotScroll={token:r,kept:[]});let f=!1,u=b=>{let h=d.recuedScreenshotScroll;if(r==null||h===void 0||h.token!==r||h.kept.some(w=>w.at===b))return;let S=b;h.kept.push(typeof S.scrollY=="number"?{at:b,x:S.scrollX,y:S.scrollY}:{at:b,x:b.scrollLeft,y:b.scrollTop})},m=b=>{for(let h=b;h!==null;){if(h.nodeType===Node.ELEMENT_NODE){let w=h;(w.scrollHeight>w.clientHeight||w.scrollWidth>w.clientWidth)&&u(w)}let S=h.parentNode;if(S!==null&&S.nodeType===Node.DOCUMENT_FRAGMENT_NODE)h=S.host??null;else if(S===null||S.nodeType===Node.DOCUMENT_NODE){let w=h.ownerDocument?.defaultView??null;w&&u(w),h=w?.frameElement??null}else h=S}},p=b=>(b.ownerDocument.defaultView??window).getComputedStyle(b),l=b=>b.scrollHeight>b.clientHeight+1&&/^(auto|scroll|overlay)$/.test(p(b).overflowY),_=b=>Math.max(1,Math.floor(b*o)),y=(b,h)=>b<=h+1?1:1+Math.ceil((b-h)/_(h)),g=(b,h,S)=>b>=h-S-1?y(h,S):Math.min(y(h,S),Math.floor(b/_(S))+1),E=(b,h,S)=>Math.max(0,Math.min((b-1)*_(S),h-S)),T=(b,h)=>{let S=typeof b.scrollY=="number"?b.scrollY:b.scrollTop;Math.abs(S-h)<1||(b.scrollTo({top:h,behavior:"instant"}),f=!0)},I=(b,h)=>({outputs:{url:location.href,title:s,area:b,viewport:i,screen:h.screen,screens:h.screens,...f?{scrolled:!0}:{}}});if(c===null){let b=document.scrollingElement??document.documentElement,h=W=>W!==null&&/^(hidden|clip)$/.test(p(W).overflowY),S=b.scrollHeight>b.clientHeight+1&&!h(document.documentElement)&&!h(document.body)?b:null;if(S===null){let W=ie=>{try{return globalThis.chrome?.dom?.openOrClosedShadowRoot?.(ie)??ie.shadowRoot}catch{return ie.shadowRoot}},Z=i.width*i.height/3,Q=[document];for(let ie=0;ie<Q.length&&ie<1e3;ie+=1)for(let z of Q[ie].querySelectorAll("*")){let ve=W(z);if(ve!==null&&Q.push(ve),z.scrollHeight<=z.clientHeight+1||!l(z))continue;let $=z.getBoundingClientRect(),pe=Math.max(0,Math.min($.right,i.width)-Math.max($.left,0))*Math.max(0,Math.min($.bottom,i.height)-Math.max($.top,0));pe>Z&&(Z=pe,S=z)}}let w={x:0,y:0,...i};if(S===null)return I(w,{screen:1,screens:1});let N=S===b,H=N?b.clientHeight:Math.min(S.clientHeight,i.height),V=S.scrollHeight,q=y(V,H);if(n==null)return I(w,{screen:g(N?window.scrollY:S.scrollTop,V,H),screens:q});let Y=Math.min(n,q);return N?u(window):m(S),T(N?window:S,E(Y,V,H)),I(w,{screen:Y,screens:q})}let k=c.ownerDocument.defaultView??window,C=c.getBoundingClientRect();if(C.width<=0||C.height<=0)return{unseen:!0};m(c);let x={screen:1,screens:1},M=(b=>{for(let h=b.parentNode;h!==null;){if(h.nodeType===Node.DOCUMENT_FRAGMENT_NODE){h=h.host??null;continue}if(h.nodeType!==Node.ELEMENT_NODE)return null;let S=h;if(S===S.ownerDocument.scrollingElement)return null;if(l(S))return S;h=S.parentNode}return null})(c),G=M===null?k.innerHeight:Math.min(M.clientHeight,k.innerHeight);if(l(c)){let b=c.clientHeight;x={screen:g(c.scrollTop,c.scrollHeight,b),screens:y(c.scrollHeight,b)},n!=null&&(x={screen:Math.min(n,x.screens),screens:x.screens},T(c,E(x.screen,c.scrollHeight,b))),(C.top<0||C.left<0||C.bottom>k.innerHeight||C.right>k.innerWidth)&&(c.scrollIntoView({block:C.height>k.innerHeight?"start":"center",inline:"nearest",behavior:"instant"}),f=!0)}else if(C.height>G+1){let b=y(C.height,G);x={screen:Math.min(n??1,b),screens:b},c.scrollIntoView({block:"start",inline:"nearest",behavior:"instant"}),f=!0;let h=E(x.screen,C.height,G);h>0&&(M===null?k.scrollBy({top:h,behavior:"instant"}):M.scrollBy({top:h,behavior:"instant"}))}else(C.top<0||C.left<0||C.bottom>k.innerHeight||C.right>k.innerWidth)&&(c.scrollIntoView({block:"center",inline:"nearest",behavior:"instant"}),f=!0);for(let b=k;b!==window&&b.frameElement;b=b.frameElement.ownerDocument.defaultView??window){let h=b.frameElement,S=h.getBoundingClientRect(),w=h.ownerDocument.defaultView??window;(S.top<0||S.left<0||S.bottom>w.innerHeight||S.right>w.innerWidth)&&(h.scrollIntoView({block:"center",inline:"nearest",behavior:"instant"}),f=!0)}C=c.getBoundingClientRect();let U=C.left,j=C.top,P=C.right,D=C.bottom;for(let b=c.parentNode;b!==null;){if(b.nodeType===Node.DOCUMENT_FRAGMENT_NODE){b=b.host??null;continue}if(b.nodeType!==Node.ELEMENT_NODE)break;let h=b;if(h!==h.ownerDocument.scrollingElement&&h!==h.ownerDocument.body&&!/^visible$/.test(p(h).overflowY)){let S=h.getBoundingClientRect();U=Math.max(U,S.left+h.clientLeft),j=Math.max(j,S.top+h.clientTop),P=Math.min(P,S.left+h.clientLeft+h.clientWidth),D=Math.min(D,S.top+h.clientTop+h.clientHeight)}b=h.parentNode}for(let b=k;b!==window&&b.frameElement;b=b.frameElement.ownerDocument.defaultView??window){let h=b.frameElement,S=h.getBoundingClientRect(),w=S.left+h.clientLeft,N=S.top+h.clientTop;U=Math.max(U+w,w),j=Math.max(j+N,N),P=Math.min(P+w,w+h.clientWidth),D=Math.min(D+N,N+h.clientHeight)}let K=Math.max(0,U),O=Math.max(0,j),B=Math.min(i.width,P)-K,v=Math.min(i.height,D)-O;return B<=0||v<=0?{unseen:!0}:I({x:K,y:O,width:B,height:v},x)},mg=e=>{let t=globalThis,n=t.recuedScreenshotScroll;if(n===void 0||n.token!==e)return!1;delete t.recuedScreenshotScroll;for(let{at:r,x:o,y:a}of[...n.kept].reverse())try{r.scrollTo({left:o,top:a,behavior:"instant"})}catch{}return!0},gg=()=>new Promise(e=>{let t=Date.now()+1e3,n=!1,r=()=>{if(![...document.images].some(a=>{if(a.complete)return!1;let i=a.getBoundingClientRect();return i.bottom>0&&i.top<window.innerHeight&&i.right>0&&i.left<window.innerWidth})||Date.now()>=t){e(n);return}n=!0,setTimeout(r,50)};r()}),ol=()=>new Promise(e=>{let t=()=>e(!0);setTimeout(t,500),requestAnimationFrame(()=>requestAnimationFrame(t))}),fg="Screenshots are off: turn on \u201CAllow screenshots\u201D in the Browser Bridge's side panel in Chrome.",ue=(e,t)=>({status:"error",error:{code:e,message:t}}),no=e=>{let t={error:ue("unknown","bridge: no readable answer from the page")};if(!e||typeof e!="object"||Array.isArray(e)||Object.keys(e).length!==1)return t;let n=e;if(n.blocked===!0)return{error:ue("tab_navigation_blocked","The owner client cannot be pictured.")};if(n.framed===!0)return{error:ue("tab_navigation_blocked",_g)};if(n.missing===!0)return{error:ue("selector_not_found","No element on the page matches the selector.")};if(n.invalid===!0)return{error:ue("selector_not_found","The selector is not valid CSS.")};if(n.stale===!0)return{error:ue("selector_not_found",fe)};if(n.unseen===!0)return{error:ue("selector_not_found","The element is not shown on the page, so it cannot be pictured.")};let r=n.outputs,o=r?.area,a=r?.viewport,i=(d,f)=>d!==void 0&&f.every(u=>typeof d[u]=="number"&&Number.isFinite(d[u]));if(!r||typeof r.url!="string"||typeof r.title!="string"||!i(o,["x","y","width","height"])||!i(a,["width","height"]))return t;let s=d=>Number.isSafeInteger(d)&&d>=1,c=s(r.screen)&&s(r.screens)&&r.screen<=r.screens?{screen:r.screen,screens:r.screens}:{};return{url:r.url,title:r.title,area:o,viewport:a,...c,scrolled:r.scrolled===!0}},il=async(e,t)=>{if(!await e.screenshotsAllowed().catch(()=>!1))return ue("capacity_gap_permission_missing",fg);let n=`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,10)}`,r={scrolled:!1};try{return await hg(e,t,n,r)}finally{r.scrolled&&await e.executeInDocument(t.page,mg,[n]).catch(()=>null)}},hg=async(e,t,n,r)=>{let{page:o,scope:a,pattern:i}=t,s=async()=>{let l;try{l=await e.executeInDocument(o,to,[a,null,t.screen??null,n,eo])}catch{l=null}if(!l||l.document_id!==o.document_id)return{error:ue("selector_not_found",de)};let _=no(l.result);return"error"in _?_:(_.scrolled&&(r.scrolled=!0),te(_.url,[i])?t.blocked(_.url)?{error:ue("tab_navigation_blocked",yn)}:_:{error:ue("tab_navigation_blocked","The page is no longer on a site this step may read.")})},c=await s();if("error"in c)return c.error;let d=await e.getTab(o.tab_id);if(!d)return ue("selector_not_found",de);if(await e.windowMinimized(d.window_id))return ue("capacity_gap_tab_unavailable","Chrome's window with this page is minimized, so it cannot be pictured: restore the window and try again.");let f=d.active?null:await e.activeTab(d.window_id),u,m;try{d.active||await e.activate(o.tab_id),await e.executeInDocument(o,ol,[]).catch(()=>null);let l=await s();if("error"in l)return l.error;if(m=l,(a.ref!==void 0||a.selector!==void 0||t.screen!==void 0)&&await e.executeInDocument(o,ol,[]).catch(()=>null),r.scrolled&&(await e.executeInDocument(o,gg,[]).catch(()=>null))?.result===!0){let E=await s();if("error"in E)return E.error;m=E}let _=await e.activeTab(d.window_id);if(_?.tab_id!==o.tab_id||!te(_.url,[i])||t.blocked(_.url))return ue("tab_navigation_blocked","The page could not be brought to the front, so it was not pictured.");let y=g=>/MAX_CAPTURE_VISIBLE_TAB_CALLS_PER_SECOND/.test(g instanceof Error?g.message:String(g));try{try{u=await e.captureVisible(d.window_id)}catch(g){if(!y(g))throw g;await new Promise(E=>setTimeout(E,pg)),u=await e.captureVisible(d.window_id)}}catch(g){return ue("unknown",y(g)?"Chrome takes at most two screenshots a second: try again.":`Chrome could not picture the page: ${g instanceof Error?g.message:String(g)}`)}}finally{f&&f.tab_id!==o.tab_id&&await e.activate(f.tab_id).catch(()=>{})}let p=await e.encode(u,m.area,m.viewport).catch(()=>null);return p?{status:"ok",outputs:{page:_e(o),url:m.url,title:m.title,...p,...t.screens===!0&&m.screen!==void 0?{screen:m.screen,screens:m.screens}:{}}}:ue("unknown","bridge: the picture could not be encoded")},yg=async(e,t,n,r={maxEdge:Tr,maxBase64:Cr})=>{let o=atob(e.slice(e.indexOf(",")+1)),a=new Uint8Array(o.length);for(let s=0;s<o.length;s++)a[s]=o.charCodeAt(s);let i=await createImageBitmap(new Blob([a],{type:"image/png"}));try{let s=n.width>0?i.width/n.width:1,c=Math.max(0,Math.floor(t.x*s)),d=Math.max(0,Math.floor(t.y*s)),f=Math.max(1,Math.min(i.width-c,Math.ceil(t.width*s))),u=Math.max(1,Math.min(i.height-d,Math.ceil(t.height*s))),m=Math.min(1,r.maxEdge/Math.max(f,u));for(let p=0;p<8;p++){let l=Math.max(1,Math.round(f*m)),_=Math.max(1,Math.round(u*m)),y=new OffscreenCanvas(l,_),g=y.getContext("2d");if(!g)throw new Error("no 2d context");g.drawImage(i,c,d,f,u,0,0,l,_);for(let E of[.85,.7,.55]){let T=new Uint8Array(await(await y.convertToBlob({type:"image/jpeg",quality:E})).arrayBuffer()),I="";for(let C=0;C<T.length;C+=32768)I+=String.fromCharCode(...T.subarray(C,C+32768));let k=btoa(I);if(k.length<=r.maxBase64)return{image:k,mime_type:"image/jpeg",width:l,height:_}}m*=.75}throw new Error("the picture does not fit")}finally{i.close()}},sl=(e,t)=>({screenshotsAllowed:async()=>e.permissions?.contains({origins:[Qc]})??!1,getTab:async n=>{try{let r=await e.tabs.get(n);return{window_id:r.windowId,active:r.active}}catch{return null}},windowMinimized:async n=>{try{return(await e.windows.get(n)).state==="minimized"}catch{return!1}},activeTab:async n=>{let r=(await e.tabs.query({active:!0,windowId:n}))[0];return r?.id===void 0?null:{tab_id:r.id,url:r.url??""}},activate:async n=>{await e.tabs.update(n,{active:!0})},captureVisible:n=>e.tabs.captureVisibleTab(n,{format:"png"}),executeInDocument:t,encode:(n,r,o)=>yg(n,r,o)});var al=(e,t,n)=>n!==void 0?n:t==="top"?1:t==="bottom"?e.screens:t==="previous"?Math.max(1,e.screen-1):Math.min(e.screens,e.screen+1),cl=(e,t,n=e)=>new Promise(r=>{let o=!1,a,i=new MutationObserver(()=>{o=!0,clearTimeout(a),a=setTimeout(c,e)}),s=setTimeout(c,t);function c(){i.disconnect(),clearTimeout(a),clearTimeout(s),r(o)}i.observe(document,{childList:!0,subtree:!0,characterData:!0}),a=setTimeout(c,n)});var An=(e,t,n=document)=>{if(n.documentElement.hasAttribute("data-recued-owner-surface")||t!==void 0&&location.href!==t)return{blocked:!0};let r=n.querySelector(e);if(!r)return{missing:!0};let o=r.localName;if(o!=="input"&&o!=="textarea"&&o!=="select")return{outputs:{text:r.innerText}};let a=r;return a.type==="password"||a.type==="hidden"||/(^|\s)(current-password|new-password|one-time-code|cc-\S+)(\s|$)/i.test(a.getAttribute("autocomplete")??"")?{protected:!0}:o==="select"?{outputs:{text:[...r.selectedOptions].map(i=>i.text).join(`
`)}}:a.type==="checkbox"||a.type==="radio"?{outputs:{text:String(a.checked)}}:{outputs:{text:a.value}}},tt=async(e,t="",n,r,o)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||n!=null&&location.href!==n)return{blocked:!0};let a=globalThis.recuedPageRefs,i=r==null?document.querySelector(e):a?.byRef.get(r)??null;if(r!=null&&!i?.isConnected)return{stale:!0};let s=i;if(!s)return{missing:!0};let c=p=>{let l='button:not([type]), button[type="submit"], input[type="submit"], input[type="image"]',_=p instanceof HTMLFormElement?p:p.form??p.closest("form");if(!_)return{not_applied:"It is in no form, so there is nothing to send."};if(!_.noValidate&&!_.checkValidity()){let g=_.querySelector(":invalid");return{not_applied:`The form was not sent: ${g?.getAttribute("aria-label")||g?.getAttribute("name")||g?.id||"a field"}: ${g?.validationMessage||"is not valid"}`}}let y=p.matches(l)?p:[..._.elements].find(g=>g.matches(l));return y?.matches(":disabled")?{not_applied:"Its send button is disabled, so it was not sent."}:(y?y.click():typeof _.requestSubmit=="function"?_.requestSubmit():_.submit(),{outputs:{submitted:!0}})},d={outputs:{filled:!0}},f=(p=s)=>o===!0?c(p):d,u=s.localName,m=s;if(u==="select"){let p=s,l=[...p.options],y=(p.multiple?t.split(`
`).filter(g=>g.trim()!==""):[t]).map(g=>l.find(E=>E.value===g)??l.find(E=>E.text===g.trim()));if(y.some(g=>g===void 0))return{not_applied:"No option in the list matches the value."};for(let g of l)g.selected=y.includes(g);for(let g of["input","change"])p.dispatchEvent(new Event(g,{bubbles:!0}));return f()}if(u==="input"&&(m.type==="checkbox"||m.type==="radio")){let p=t.trim().toLowerCase();return p!=="true"&&p!=="false"?{not_applied:"A checkbox or radio button takes true or false."}:(m.checked!==(p==="true")&&m.click(),m.checked===(p==="true")?f():{not_applied:"The page did not change the checkbox or radio button."})}if(u==="input"||u==="textarea"){if(m.type==="file")return{not_applied:"A file field cannot be typed into."};let p=m.value,l=s.ownerDocument.defaultView,_=Object.getOwnPropertyDescriptor(u==="textarea"?(l?.HTMLTextAreaElement??HTMLTextAreaElement).prototype:(l?.HTMLInputElement??HTMLInputElement).prototype,"value")?.set;return m.focus(),_?_.call(m,t):m.value=t,m.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0,inputType:"insertText",data:t})),m.dispatchEvent(new Event("change",{bubbles:!0})),await new Promise(y=>setTimeout(y,0)),t.trim()!==""&&m.value===""?{not_applied:"The field emptied the value. Check its format."}:p!==t&&m.value===p?{not_applied:"The page put back what the field held, so the value did not go in."}:f()}if(s.isContentEditable){s.focus();let p=s.ownerDocument,l=p.createRange();l.selectNodeContents(s);let _=(p.defaultView??window).getSelection();_?.removeAllRanges(),_?.addRange(l),!s.dispatchEvent(new InputEvent("beforeinput",{inputType:t===""?"deleteContentBackward":"insertText",data:t===""?null:t,targetRanges:[new StaticRange(l)],bubbles:!0,cancelable:!0,composed:!0}))||p.execCommand(t===""?"delete":"insertText",!1,t);let g=E=>E.replace(/[​-‍﻿]/g,"").replace(/\s+/g," ").trim();for(let E of[0,50,250]){await new Promise(I=>setTimeout(I,E));let T=r==null?document.querySelector(e):s.isConnected?s:null;if(T&&g(T.innerText)===g(t))return f(T)}return{not_applied:"The editor did not take the text."}}return{not_applied:"The element is not a field or an editor."}},ll=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};let r=globalThis.recuedPageRefs,o=n==null?document.querySelector(e):r?.byRef.get(n)??null;if(n!=null&&!o?.isConnected)return{stale:!0};if(!o)return{missing:!0};let a='button:not([type]), button[type="submit"], input[type="submit"], input[type="image"]',i=o instanceof HTMLFormElement?o:o.form??o.closest("form");if(!i)return{not_applied:"It is in no form, so there is nothing to send."};if(!i.noValidate&&!i.checkValidity()){let c=i.querySelector(":invalid");return{not_applied:`The form was not sent: ${c?.getAttribute("aria-label")||c?.getAttribute("name")||c?.id||"a field"}: ${c?.validationMessage||"is not valid"}`}}let s=o.matches(a)?o:[...i.elements].find(c=>c.matches(a));return s?.matches(":disabled")?{not_applied:"Its send button is disabled, so it was not sent."}:(s?s.click():typeof i.requestSubmit=="function"?i.requestSubmit():i.submit(),{outputs:{submitted:!0}})},nt=async(e,t,n,r)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};let o=globalThis.recuedPageRefs,a=n==null?document.querySelector(e):o?.byRef.get(n)??null;if(n!=null&&!a?.isConnected)return{stale:!0};if(!a)return{missing:!0};let i=a;if(i.matches(":disabled"))return{not_applied:"It is disabled, so it was not clicked."};let s=i.ownerDocument,c=s.defaultView??window,d=P=>{try{return globalThis.chrome?.dom?.openOrClosedShadowRoot?.(P)??P.shadowRoot}catch{return P.shadowRoot}},f=(P,D)=>{for(let K=D;K!==null;K=K.parentNode??K.host??null)if(K===P)return!0;return!1},u=(P,D,K)=>{let O=P.elementFromPoint(D,K);for(let B=0;O!==null&&B<32;B+=1){let v=d(O)?.elementFromPoint(D,K)??null;if(v===null||v===O)break;O=v}return O},m='dialog, [role="dialog"], [role="alertdialog"], [aria-modal="true"]',p=(P,D=0)=>{let K=P.closest(m)??P,O=v=>(v??"").replace(/\s+/g," ").trim(),B=(O(K.getAttribute("aria-label"))||O(K.getAttribute("title"))||O(K.innerText)).slice(0,80);return{not_applied:`Something else on the page covers it${B?` (\u201C${B}\u201D)`:""}${D>0?`, and still did after ${String(Math.round(D/1e3))} s`:""}, so it was not clicked. Close or answer that first.`}},l=i.getBoundingClientRect();if(l.width<=0||l.height<=0)return typeof i.click=="function"?i.click():i.dispatchEvent(new MouseEvent("click",{bubbles:!0,cancelable:!0,composed:!0})),{outputs:{clicked:!0}};let _=P=>P!==null&&!f(i,P)&&!f(P,i),y=()=>{l=i.getBoundingClientRect(),(l.top<0||l.left<0||l.bottom>c.innerHeight||l.right>c.innerWidth)&&(i.scrollIntoView({block:"center",inline:"center"}),l=i.getBoundingClientRect());for(let v=c;v!==window&&v.frameElement;v=v.frameElement.ownerDocument.defaultView??window){let b=v.frameElement,h=b.getBoundingClientRect(),S=b.ownerDocument.defaultView??window;(h.top<0||h.left<0||h.bottom>S.innerHeight||h.right>S.innerWidth)&&b.scrollIntoView({block:"center",inline:"center"})}l=i.getBoundingClientRect();let P=Math.min(Math.max(l.left+l.width/2,0),c.innerWidth-1),D=Math.min(Math.max(l.top+l.height/2,0),c.innerHeight-1),K=u(s,P,D);if(_(K)&&(i.scrollIntoView({block:"center",inline:"center",behavior:"instant"}),l=i.getBoundingClientRect(),P=Math.min(Math.max(l.left+l.width/2,0),c.innerWidth-1),D=Math.min(Math.max(l.top+l.height/2,0),c.innerHeight-1),K=u(s,P,D),_(K)))return{cover:K};let O=P,B=D;for(let v=c;v!==window&&v.frameElement;v=v.frameElement.ownerDocument.defaultView??window){let b=v.frameElement,h=b.getBoundingClientRect();O+=h.left+b.clientLeft,B+=h.top+b.clientTop;let S=u(b.ownerDocument,O,B);if(S&&S!==b&&!f(b,S))return{cover:S}}return{x:P,y:D,hit:K}},g=Date.now(),E=g+Math.max(0,Number(r??0)||0),T=y();for(;"cover"in T&&Date.now()<E;){let P=T.cover.closest(m);if(P!==null&&!f(P,i))break;if(await new Promise(D=>setTimeout(D,100)),!i.isConnected)return{stale:!0};if(i.matches(":disabled"))return{not_applied:"It is disabled, so it was not clicked."};T=y()}if("cover"in T)return p(T.cover,Date.now()-g>=1e3?Date.now()-g:0);let{x:I,y:k,hit:C}=T,x=C&&f(i,C)?C:i,F={composed:!0,view:c,clientX:I,clientY:k,screenX:c.screenX+I,screenY:c.screenY+k,button:0},M=(P,D,K=!0)=>x.dispatchEvent(new PointerEvent(P,{...F,bubbles:K,cancelable:K,buttons:D,pointerId:1,pointerType:"mouse",isPrimary:!0})),G=(P,D,K,O=!0)=>x.dispatchEvent(new MouseEvent(P,{...F,bubbles:O,cancelable:O,buttons:D,detail:K}));M("pointerover",0),M("pointerenter",0,!1),G("mouseover",0,0),G("mouseenter",0,0,!1),M("pointermove",0),G("mousemove",0,0);let U=M("pointerdown",1);if(U?G("mousedown",1,1):!1){let P=x.closest('a[href], area[href], button, input, select, textarea, summary, iframe, [tabindex], [contenteditable]:not([contenteditable="false"])');P!==null&&typeof P.focus=="function"&&!P.matches(":disabled")?P.focus({preventScroll:!0}):s.activeElement!==null&&typeof s.activeElement.blur=="function"&&s.activeElement.blur()}return M("pointerup",0),U&&G("mouseup",0,1),x.dispatchEvent(new MouseEvent("click",{...F,bubbles:!0,cancelable:!0,buttons:0,detail:1})),{outputs:{clicked:!0}}};var Tn=()=>{let e=a=>{let i=a.getBoundingClientRect(),s=getComputedStyle(a);return i.width>1&&i.height>1&&s.visibility!=="hidden"&&s.display!=="none"&&s.opacity!=="0"},t=a=>[...document.querySelectorAll(`[name="${a}"]`)].some(i=>(i.value??"").trim()!==""),n=[{name:"reCAPTCHA",frame:/\/recaptcha\/(?:api2|enterprise)\/(?:anchor|bframe)/,invisible:/[?&]size=invisible/,answer:"g-recaptcha-response"},{name:"hCaptcha",frame:/hcaptcha\.com\/captcha|\/hcaptcha\.html/,answer:"h-captcha-response"},{name:"Cloudflare Turnstile",frame:/challenges\.cloudflare\.com/,answer:"cf-turnstile-response"},{name:"Arkose",frame:/arkoselabs\.com|funcaptcha\.com/},{name:"DataDome",frame:/captcha-delivery\.com/}],r=[...document.querySelectorAll("iframe")];for(let a of n)if(r.some(s=>a.frame.test(s.src)&&!(a.invisible?.test(s.src)??!1)&&e(s))&&!(a.answer!==void 0&&t(a.answer)))return a.name;if(document.querySelector("#challenge-running, #challenge-form, #cf-challenge-running, .cf-browser-verification"))return"Cloudflare";let o=document.querySelector("#px-captcha");return o&&e(o)?"PerimeterX":null};var dl=(e,t,n,r)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};if(r==null)return{not_applied:"No key was named, so none was pressed."};let o=globalThis.recuedPageRefs,a=n==null?document.querySelector(e):o?.byRef.get(n)??null;if(n!=null&&!a?.isConnected)return{stale:!0};if(!a)return{missing:!0};let i=a;if(i.matches(":disabled"))return{not_applied:"It is disabled, so no key was pressed in it."};let s=i.ownerDocument,c=s.defaultView??window;s.activeElement!==i&&typeof i.focus=="function"&&i.focus();let d={key:r.key,code:r.code,keyCode:r.keyCode,which:r.keyCode,ctrlKey:r.ctrlKey,metaKey:r.metaKey,altKey:r.altKey,shiftKey:r.shiftKey,bubbles:!0,cancelable:!0,composed:!0,view:c},f=i.dispatchEvent(new c.KeyboardEvent("keydown",d));f&&(r.key.length===1||r.key==="Enter")&&!r.ctrlKey&&!r.metaKey&&i.dispatchEvent(new c.KeyboardEvent("keypress",{...d,charCode:r.key==="Enter"?13:r.key.charCodeAt(0)}));let u=i.localName,m=u==="input"?i.type:"",p=(i.getAttribute("role")??"").toLowerCase(),l=["checkbox","radio","switch"],_=u==="input"&&!["button","submit","reset","image","checkbox","radio","file","color","range"].includes(m),y=_||u==="textarea"||i.isContentEditable,g=u==="button"||u==="summary"||u==="a"&&i.hasAttribute("href")||u==="input"&&["button","submit","reset","image","checkbox","radio"].includes(m)||["button","link","menuitem","menuitemcheckbox","menuitemradio","tab","option",...l].includes(p),E=l.includes(m)||l.includes(p),T=x=>{if(!s.execCommand("insertText",!1,x)&&_){let F=i;F.setRangeText(x,F.selectionStart??F.value.length,F.selectionEnd??F.value.length,"end"),F.dispatchEvent(new c.InputEvent("input",{bubbles:!0,composed:!0,inputType:"insertText",data:x}))}},I=!1,k=null,C=!r.ctrlKey&&!r.metaKey&&!r.altKey;if(f&&C)if(r.key==="Enter"){let x=_?i.form:null;if(x!==null){let F=[...x.elements].find(M=>M.matches('button:not([type]), button[type="submit" i], input[type="submit" i], input[type="image" i]'));F!==void 0?F.matches(":disabled")||(F.click(),I=!0):(x.requestSubmit(),I=!0)}else u==="textarea"||i.isContentEditable?s.execCommand(u==="textarea"?"insertText":"insertParagraph",!1,`
`)||T(`
`):g&&!E&&i.click()}else if(r.key===" ")g?i.click():y&&T(" ");else if(r.key==="Escape"){let x=s.querySelector("dialog:modal")??i.closest("dialog[open]");x!==null&&x.dispatchEvent(new c.Event("cancel",{cancelable:!0}))&&x.close()}else if(r.key==="Tab"){let F=[...(s.querySelector("dialog:modal")??s).querySelectorAll('a[href], area[href], button, input, select, textarea, summary, iframe, [tabindex], [contenteditable]:not([contenteditable="false"])')].filter(U=>U.tabIndex>=0&&!U.matches(":disabled")&&U.getAttribute("type")!=="hidden"&&U.checkVisibility({checkVisibilityCSS:!0})),M=F.indexOf(i),G=F[(M+(r.shiftKey?-1:1)+F.length)%F.length];G!==void 0&&G!==i&&(G.focus(),k=G)}else(r.key==="Backspace"||r.key==="Delete")&&y&&s.execCommand(r.key==="Backspace"?"delete":"forwardDelete");return(k??i).dispatchEvent(new c.KeyboardEvent("keyup",d)),{outputs:{pressed:r.name,...I?{sent:!0}:{}}}};var ul=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};let r=globalThis.recuedPageRefs,o=n==null?document.querySelector(e):r?.byRef.get(n)??null;if(n!=null&&!o?.isConnected)return{stale:!0};if(!o)return{missing:!0};let a=o;a.scrollIntoView?.({block:"center",inline:"center"});let i=a.getBoundingClientRect(),s=a.ownerDocument.defaultView??window,c={clientX:i.left+i.width/2,clientY:i.top+i.height/2,view:s,composed:!0},d={...c,pointerType:"mouse",isPrimary:!0},f=[];for(let u=a;u!==null&&u!==a.ownerDocument.documentElement;u=u.parentElement)f.unshift(u);a.dispatchEvent(new s.PointerEvent("pointerover",{...d,bubbles:!0,cancelable:!0}));for(let u of f)u.dispatchEvent(new s.PointerEvent("pointerenter",{...d,bubbles:!1}));a.dispatchEvent(new s.MouseEvent("mouseover",{...c,bubbles:!0,cancelable:!0}));for(let u of f)u.dispatchEvent(new s.MouseEvent("mouseenter",{...c,bubbles:!1}));return a.dispatchEvent(new s.PointerEvent("pointermove",{...d,bubbles:!0,cancelable:!0})),a.dispatchEvent(new s.MouseEvent("mousemove",{...c,bubbles:!0,cancelable:!0})),{hovered:!0}};var pl=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return{blocked:!0};let r=n;if(r===null){let a=globalThis.recuedPageRefs,i=t===null?e===null?null:document.querySelector(e):a?.byRef.get(t)??null;if(t!==null&&!i?.isConnected)return{stale:!0};if(!i)return{missing:!0};if(r=(i.closest("a[href], area[href]")??i.querySelector("a[href], area[href]"))?.href??(i.src!==void 0?String(i.src):null),r===null||r==="")return{no_address:!0}}let o;try{o=new URL(r,location.href)}catch{return{no_address:!0}}return o.protocol!=="http:"&&o.protocol!=="https:"?{no_address:!0}:{address:o.href,cross_origin:o.origin!==location.origin,url:location.href,title:document.title}},ro=async(e,t)=>{let n;try{n=await fetch(e,{credentials:"include",redirect:"follow"})}catch(g){return{failed:g instanceof Error?g.message:String(g)}}if(!n.ok)return{failed:`the site answered ${String(n.status)}${n.statusText?` ${n.statusText}`:""}`};let r=Number(n.headers.get("content-length")??Number.NaN);if(Number.isFinite(r)&&r>t)return n.body?.cancel().catch(()=>{}),{too_large:r};let o=[],a=0,i=n.body?.getReader();if(i!==void 0)for(;;){let{done:g,value:E}=await i.read();if(g)break;if(a+=E.length,a>t)return i.cancel().catch(()=>{}),{too_large:a,at_least:!0};o.push(E)}let s=new Uint8Array(a),c=0;for(let g of o)s.set(g,c),c+=g.length;let d="";for(let g=0;g<s.length;g+=32768)d+=String.fromCharCode(...s.subarray(g,g+32768));let f=g=>{try{return decodeURIComponent(g)}catch{return g}},u=n.headers.get("content-disposition")??"",m=/filename\*\s*=\s*[\w-]+''([^;]+)/i.exec(u)?.[1],p=/filename\s*=\s*"([^"]*)"/i.exec(u)?.[1]??/filename\s*=\s*([^;"]+)/i.exec(u)?.[1],l="";try{l=new URL(n.url||e).pathname.split("/").filter(g=>g!=="").pop()??""}catch{l=""}let _=(m!==void 0?f(m.trim()):p!==void 0?p.trim():f(l)).replace(/[\\/\u0000-\u001f\u007f]/g,"_").trim(),y=(n.headers.get("content-type")??"").split(";")[0].trim().toLowerCase();return{address:n.url||e,filename:_===""?"download":_,mime_type:y===""?"application/octet-stream":y,size:a,data:btoa(d)}},_l=(e,t,n)=>{let r=o=>`${(o/1e6).toFixed(1)} MB`;return`The file is ${t?`more than ${r(n)}`:r(e)}, and the Browser Bridge hands over files of at most ${r(n)}.`},ml="That element links to no file: name the link to the file, or give the file's address.",gl=(e,t,n,r,o)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return{blocked:!0};let a=globalThis.recuedPageRefs,i=t===null?e===null?null:document.querySelector(e):a?.byRef.get(t)??null;if(t!==null&&!i?.isConnected)return{stale:!0};if(!i)return{missing:!0};let s=i instanceof HTMLInputElement?i:i instanceof HTMLLabelElement?i.control:i.querySelector('input[type="file"]');if(!(s instanceof HTMLInputElement)||s.type!=="file"||s.disabled)return{not_file_field:i.tagName.toLowerCase()};let c=atob(o),d=new Uint8Array(c.length);for(let u=0;u<c.length;u+=1)d[u]=c.charCodeAt(u);let f=new DataTransfer;return f.items.add(new File([d],n,{type:r})),s.files=f.files,s.dispatchEvent(new Event("input",{bubbles:!0,composed:!0})),s.dispatchEvent(new Event("change",{bubbles:!0})),{attached:s.files?.[0]?.name??n,url:location.href,title:document.title}},fl='That element is not a file field: name the field that chooses a file (an "input" of type file, its label, or the button around it).';var hl=["data-test-id","data-testid","data-test","data-qa","data-cy","data-automation-id","data-automationid","data-component","data-tracking-id","data-name","data-id","data-key"],Eg=["name","role","type","for"],bg=[...hl,"name","aria-label","role","type","placeholder","title","alt","for"],Sg=new Set([...hl,...Eg]),Rg=[/:r[0-9a-z]+:/i,/«r[0-9a-z]+»/i,/^css-[a-z0-9]{4,}$/i,/^sc-[a-zA-Z0-9]{4,}/,/^ember\d+$/i,/^mui-\d+$/i,/^radix-/i,/headlessui-/i,/_{2,}(?=[a-z0-9]{4,}$)[a-z0-9]*\d[a-z0-9]*$/i,/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}/i,/^[0-9a-f]{8,}$/i,/\d{6,}/];var oo={precedence:bg,identifier_like:[...Sg],generated:Rg.map(e=>[e.source,e.flags]),max_value_chars:80,max_depth:8};var Cn={candidates:'[role="alert"], [aria-live="assertive"], [aria-invalid="true"], [class*="error" i], [class*="danger" i], [class*="invalid" i], [id*="error" i]',never:"a, button, input, select, textarea, option, script, style, template, noscript, svg",errorName:"error|danger|invalid",successName:"success",errorWords:"\\b(invalid|incorrect|wrong|error|failed|failure|not (found|valid|recogni[sz]ed|match(ed)?|allowed)|couldn['\u2019]?t|could not|can['\u2019]?t|cannot|unable|denied|expired|required|try again|too many|problem)\\b",answerPlace:'[role="alert"], [aria-live="assertive"], form, [class*="flash" i], [class*="alert" i], [class*="notice" i], [class*="message" i]',maxText:300,quote:200},yl=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return{sends:!1};let r=u=>u.getAttribute("aria-hidden")!=="true"&&(u.checkVisibility({checkVisibilityCSS:!0})||getComputedStyle(u).display==="contents"),o=u=>`${r(u)?(u.innerText??u.textContent??"").replace(/\s+/g," ").trim():"\u2205"}|${u.getAttribute("aria-invalid")??""}`,a=new Map;for(let u of document.querySelectorAll(n.candidates))a.set(u,o(u));globalThis.recuedMessageNotes=a;let i=globalThis.recuedPageRefs,s=null;try{s=t==null?document.querySelector(e):i?.byRef.get(t)??null}catch{s=null}let c='button:not([type]), button[type="submit"], input[type="submit"], input[type="image"]',d=s===null?null:s.form??s.closest("form"),f=s!==null&&s.isConnected&&d!==null&&s.matches(c)&&!s.matches(":disabled");if(f&&s!==null&&d!==null&&!d.noValidate&&!s.hasAttribute("formnovalidate")){let u=[...d.elements].find(m=>m.matches(":invalid"));if(u!==void 0)return{sends:!1,unsent:`The form was not sent: ${u.getAttribute("aria-label")||u.getAttribute("name")||u.id||"a field"}: ${u.validationMessage||"is not valid"}`}}return{sends:f}},In=e=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return null;let t=u=>u.getAttribute("aria-hidden")!=="true"&&(u.checkVisibility({checkVisibilityCSS:!0})||getComputedStyle(u).display==="contents"),n=u=>`${t(u)?(u.innerText??u.textContent??"").replace(/\s+/g," ").trim():"\u2205"}|${u.getAttribute("aria-invalid")??""}`,r=u=>(u.innerText??u.textContent??"").replace(/\s+/g," ").trim().replace(/[\s×✕✖]+$/u,""),o=globalThis.recuedMessageNotes,a=new RegExp(e.errorName,"i"),i=new RegExp(e.successName,"i"),s=new RegExp(e.errorWords,"i"),c=u=>(u.match(new RegExp("\\p{L}","gu"))??[]).length,d=[];for(let u of document.querySelectorAll(e.candidates)){if(!t(u)||(o!==void 0?o.get(u)===n(u):u.closest(e.answerPlace)===null))continue;let m=`${typeof u.className=="string"?u.className:""} ${u.id}`;if(i.test(m))continue;if(u.matches(e.never)){if(u.getAttribute("aria-invalid")!=="true"||!u.matches("input, select, textarea"))continue;let y=`${u.getAttribute("aria-errormessage")??""} ${u.getAttribute("aria-describedby")??""}`.split(/\s+/).filter(T=>T!=="").map(T=>document.getElementById(T)).filter(T=>T!==null&&t(T)).map(T=>r(T)).filter(T=>T!=="").join(" "),g=u,E=g.labels?.[0]?r(g.labels[0]):g.getAttribute("aria-label")??g.name??"";d.push({element:u,text:y!==""?y:`${E!==""?`\u201C${E}\u201D`:"A field"} is marked as not valid`});continue}let p=r(u);if(c(p)<3||p.length>e.maxText)continue;let l=u.getAttribute("role")==="alert"||u.getAttribute("aria-live")==="assertive";!a.test(m)&&!(l&&s.test(p))||d.push({element:u,text:p})}let f=d.find(u=>!d.some(m=>m!==u&&u.element.contains(m.element)));return f===void 0?null:f.text.length>e.quote?`${f.text.slice(0,e.quote-1)}\u2026`:f.text};var kn={lists:'[role="listbox"], [role="menu"], [role="grid"], [role="tree"], ul, ol, [class*="suggest" i], [class*="autocomplete" i], [class*="typeahead" i], [class*="combobox" i], [class*="dropdown" i], [class*="results" i], [class*="options" i], [class*="pac-container" i]',nearPx:320,listed:10,quote:80,aroundChars:400},El=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return{blocked:!0};let r=globalThis.recuedPageRefs,o=t==null?document.querySelector(e):r?.byRef.get(t)??null;if(t!=null&&!o?.isConnected)return{stale:!0};if(!o)return{missing:!0};let a=m=>m.getAttribute("aria-hidden")!=="true"&&m.checkVisibility({checkVisibilityCSS:!0}),i=o.getRootNode(),s=[...new Set([i,o.ownerDocument,document])],c=new Map;for(let m of s.flatMap(p=>[...p.querySelectorAll(n.lists)]))a(m)&&c.set(m,m.innerText??"");let f=o.form??o.closest("form")??o.parentElement?.parentElement?.parentElement??document.body,u=new Map;for(let m of f.querySelectorAll('input[type="hidden"]'))u.set(m,m.value);return globalThis.recuedPickNote={field:o,lists:c,hidden:u,scope:f},{noted:!0}},bl=(e,t,n,r)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))return{blocked:!0};let o=globalThis,a=o.recuedPickNote,i=v=>v!==null&&v.isConnected&&v.matches('input, textarea, [contenteditable]:not([contenteditable="false"]), [role="combobox"]'),s=t==null?document.querySelector(e):o.recuedPageRefs?.byRef.get(t)??null,c=document.activeElement;for(let v=0;c!==null&&v<16;v+=1){let b=c.shadowRoot?.activeElement??(c.localName==="iframe"?(()=>{try{return c.contentDocument?.activeElement}catch{return null}})():null);if(b==null||b===c)break;c=b}let d=[s,a?.field??null,c].find(i)??null;if(d===null)return{gone:!0};let f=d.getRootNode(),u=[...new Set([f,d.ownerDocument,document])],m=v=>u.map(b=>b.getElementById(v)).find(b=>b!==null)??null,p=v=>v.getAttribute("aria-hidden")!=="true"&&v.checkVisibility({checkVisibilityCSS:!0}),l=v=>(v.innerText??v.textContent??"").trim(),_=v=>v.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g,"").replace(/[^\p{L}\p{N}]+/gu," ").trim(),y=v=>v.split(`
`).find(b=>b.trim()!=="")??"",g=v=>{let b=l(v).replace(/\s+/g," ");return b.length>r.quote?`${b.slice(0,r.quote-1)}\u2026`:b},E=new Set;for(let v of[d,d.closest('[role="combobox"]')])for(let b of["aria-controls","aria-owns"])for(let h of(v?.getAttribute(b)??"").split(/\s+/))h!==""&&E.add(h);let T=[...E].map(v=>m(v)).filter(v=>v!==null),I=d.getAttribute("aria-activedescendant"),k=I?m(I)?.closest('[role="listbox"], [role="menu"], [role="grid"], [role="tree"]'):null;k&&T.push(k);let C=T.filter(p);if(C.length===0){let v=d.getBoundingClientRect();C=[...new Set(u.flatMap(b=>[...b.querySelectorAll(r.lists)]))].filter(b=>{if(!p(b)||b.contains(d))return!1;let h=a?.lists.get(b);if(h!==void 0&&h===(b.innerText??""))return!1;let S=b.getBoundingClientRect();return S.width<=0||S.height<=0||S.left>=v.right||S.right<=v.left?!1:S.top>=v.top&&S.top<=v.bottom+r.nearPx||S.bottom<=v.bottom&&S.bottom>=v.top-r.nearPx}),C=C.filter(b=>!C.some(h=>h!==b&&b.contains(h)))}let x=[];for(let v of C){let b=[...v.querySelectorAll('[role="option"]')];b.length===0&&(b=[...v.querySelectorAll('[role="menuitem"], [role="menuitemradio"]')]),b.length===0&&(b=[...v.querySelectorAll("li")]),b.length===0&&!v.matches('[role="listbox"]')&&(b=[...v.children]);for(let h of b)p(h)&&h.getAttribute("aria-disabled")!=="true"&&l(h)!==""&&!x.includes(h)&&x.push(h)}let F=x.filter(v=>!x.some(b=>b!==v&&v.contains(b)));if(F.length===0)return{no_list:!0};let M=_(n),G=F.filter(v=>_(l(v))===M),U=G.length>0?G:F.filter(v=>_(y(l(v)))===M),j=U.length>0?U:F.filter(v=>` ${_(l(v))} `.includes(` ${M} `));if(j.length===0)return{none:F.slice(0,r.listed).map(g)};if(j.length>1)return{several:j.slice(0,r.listed).map(g)};let P=j[0],D=P.querySelectorAll("a[href]"),K=D.length===1&&p(D[0])?D[0]:P,O=o.recuedPageRefs??={next:1,byRef:new Map,byElement:new WeakMap},B=O.byElement.get(K);return(B===void 0||O.byRef.get(B)!==K)&&(B=`e${O.next++}`,O.byElement.set(K,B),O.byRef.set(B,K)),a!==void 0&&(a.chosen={option:P,label:l(P)}),{found:B,label:g(P),url:location.href}},Sl=(e,t,n)=>{let r=globalThis,o=d=>d!==null&&d.isConnected&&d.matches("input, textarea"),i=[t==null?document.querySelector(e):r.recuedPageRefs?.byRef.get(t)??null,r.recuedPickNote?.field??null,document.activeElement].find(o);if(i===void 0)return{gone:!0};let s=Object.getOwnPropertyDescriptor(i.localName==="textarea"?HTMLTextAreaElement.prototype:HTMLInputElement.prototype,"value")?.set,c=d=>s?s.call(i,d):i.value=d;i.focus(),c(""),i.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0,inputType:"deleteContentBackward"}));for(let d of n){let f=d.toUpperCase(),u=/^[A-Z]$/.test(f)?`Key${f}`:/^[0-9]$/.test(d)?`Digit${d}`:d===" "?"Space":"",m={key:d,code:u,keyCode:f.charCodeAt(0),which:f.charCodeAt(0),bubbles:!0,cancelable:!0,composed:!0};i.dispatchEvent(new KeyboardEvent("keydown",m))&&i.dispatchEvent(new KeyboardEvent("keypress",{...m,charCode:d.codePointAt(0)}))&&i.dispatchEvent(new InputEvent("beforeinput",{bubbles:!0,cancelable:!0,composed:!0,inputType:"insertText",data:d}))&&(c(i.value+d),i.dispatchEvent(new InputEvent("input",{bubbles:!0,composed:!0,inputType:"insertText",data:d}))),i.dispatchEvent(new KeyboardEvent("keyup",m))}return{typed:!0}},Rl=(e,t,n,r,o)=>{let a=globalThis,i=a.recuedPickNote;if(i?.chosen===void 0)return{unknown:!0};for(let I of i.scope.isConnected?i.scope.querySelectorAll('input[type="hidden"]'):[]){let k=i.hidden.get(I);if(k===void 0?I.value!=="":I.value!==k)return{took:"hidden"}}let s=I=>I.isConnected&&I.getAttribute("aria-hidden")!=="true"&&I.checkVisibility({checkVisibilityCSS:!0}),c=I=>I.toLowerCase().normalize("NFKD").replace(/[̀-ͯ]/g,"").replace(/[^\p{L}\p{N}]+/gu," ").trim(),d=I=>I!==null&&I.isConnected&&I.matches('input, textarea, [contenteditable]:not([contenteditable="false"]), [role="combobox"]'),u=[t==null?document.querySelector(e):a.recuedPageRefs?.byRef.get(t)??null,i.field,document.activeElement].find(d)??null,m=i.chosen.option,p=m.closest('[role="listbox"], [role="menu"], [role="grid"], [role="tree"], ul, ol')??m.parentElement,l=s(m)||p!==null&&s(p)&&p.contains(m),_=u!==null&&"value"in u?c(String(u.value??"")):"",y="";if(u!==null){let I=C=>{let x=C.innerText??"";return p!==null&&C.contains(p)&&(x=x.replace(p.innerText??""," ")),x},k=u.parentElement;for(let C=0;C<3&&k?.parentElement&&!(I(k.parentElement).length>o.aroundChars);C+=1)k=k.parentElement;y=k===null?"":c(I(k))}let g=i.chosen.label;return[c(g.split(`
`).find(I=>I.trim()!=="")??""),c(r)].filter(I=>I!=="").some(I=>_.includes(I)||y.includes(I))&&(!l||_!==c(n))?{took:"shown"}:l?{open:!0}:{not_shown:!0}};var Al=(e,t)=>{let n=globalThis.recuedPageRefs,r=n?.byRef.get(e);if(n===void 0||r===void 0)return{missing:!0};let o=p=>p.getAttribute("aria-hidden")!=="true"&&p.checkVisibility({checkVisibilityCSS:!0}),a=(p,l)=>{let _=T=>[...T.querySelectorAll(p)].filter(I=>o(I)&&l(I)),y=_(document);if(y.length>0)return y;let g=T=>{try{return globalThis.chrome?.dom?.openOrClosedShadowRoot?.(T)??T.shadowRoot}catch{return T.shadowRoot}},E=[document];for(let T=0;T<E.length&&T<1e3;T+=1)for(let I of E[T].querySelectorAll("*")){let k=g(I);if(k!==null&&E.push(k),I.localName==="iframe"||I.localName==="frame")try{let C=I.contentDocument;C!==null&&!C.documentElement.hasAttribute("data-recued-owner-surface")&&E.push(C)}catch{}}return E.slice(1).flatMap(_)},i=p=>{n.byRef.set(e,p),n.byElement.has(p)||n.byElement.set(p,e)};if(r.isConnected){let p=t===!0?n.seen?.get(r):void 0,l=n.print;if(p===void 0||l===void 0)return{kept:!0};let _=["tag","type","name","role","label","placeholder","title","text","value","href","form","row","links"],y=new Set(["label","title","text","value","row"]),g=C=>C.replace(/\d+(?:[.,:]\d+)+/g,"#"),E=(C,x,F)=>_.every(M=>F||!y.has(M)?C[M]===x[M]:g(C[M]??"")===g(x[M]??"")),T=l(r);if(E(T,p,!1))return{kept:!0};let I=a(p.tag??r.localName,C=>E(l(C),p,!0));if(I.length===1)return i(I[0]),{rebound:!0};let k=C=>`\u201C${C.shows??""}\u201D${C.in?` in \u201C${C.in}\u201D`:""}`;return{changed:{now:k(T),was:k(p)}}}let s=p=>(p??"").replace(/\s+/g," ").trim().toLowerCase(),c='li, tr, [role="row"], [role="listitem"], [role="option"], [role="article"], article',d=p=>{let l=p.form??p.closest("form"),_=p.closest(c);return{tag:p.localName,type:s(p.getAttribute("type")),name:p.getAttribute("name")??"",role:s(p.getAttribute("role")),label:s(p.getAttribute("aria-label")),placeholder:s(p.getAttribute("placeholder")),title:s(p.getAttribute("title")),text:p.matches("input, textarea, select")?"":s(p.textContent).slice(0,200),value:p.matches('input[type="submit" i], input[type="button" i], input[type="reset" i]')?s(p.value):"",href:p.getAttribute("href")??"",form:l===null?null:`${l.id}|${l.getAttribute("action")??""}|${s(l.getAttribute("method"))}`,row:_===null||_===p?null:s(_.textContent).slice(0,300)}},f=d(r),u=p=>{if(p.id!==""&&r.id!==""&&p.id!==r.id)return!1;let l=d(p);for(let _ of["tag","type","name","role","label","placeholder","title","text","value","href"])if(l[_]!==f[_])return!1;return!(f.form!==null&&l.form!==f.form||f.row!==null&&l.row!==f.row)},m=a(f.tag,u);return m.length!==1?{stale:!0}:(i(m[0]),{rebound:!0})};var Tl={max_rows:Ar,max_chars:4e4,max_value_chars:2e3},Cl=(e,t,n)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||n!=null&&location.href!==n)return{blocked:!0};let r='table, [role="table"], [role="grid"], [role="treegrid"]',o=O=>(O.getAttribute("role")??"").trim().split(/\s+/)[0],a=O=>O.localName==="table"?!["presentation","none"].includes(o(O)):["table","grid","treegrid"].includes(o(O)),i=O=>O.getAttribute("aria-hidden")!=="true"&&(O.checkVisibility({checkVisibilityCSS:!0})||getComputedStyle(O).display==="contents"),s=O=>[...O.querySelectorAll(r)].find(B=>a(B)&&i(B))??null,c=null;if(e.ref!=null){if(c=globalThis.recuedPageRefs?.byRef.get(e.ref)??null,!c?.isConnected)return{stale:!0}}else if(e.selector!=null){try{c=document.querySelector(e.selector)}catch{return{invalid:!0}}if(!c)return{missing:!0}}let d=c===null?s(document):a(c)?c:s(c)??c.closest(r);if(!d||!i(d))return{missing:!0};let f=new Set(["script","style","noscript","template","iframe","frame","object","embed","svg"]),u=/(^|\s)(current-password|new-password|one-time-code|cc-\S+)(\s|$)/i,m=O=>{let B=O.localName==="input"?O.type:"";return B==="password"||B==="hidden"||u.test(O.getAttribute("autocomplete")??"")},p=O=>{if(m(O))return"";if(O.localName==="select")return[...O.selectedOptions].map(v=>v.text.trim()).join(", ");let B=O;return O.localName==="input"&&(B.type==="checkbox"||B.type==="radio")?String(B.checked):O.localName==="input"&&["button","submit","reset","image","file"].includes(B.type)?B.type==="file"?"":B.value:B.value??""},l=O=>{if(O.nodeType===Node.TEXT_NODE)return O.nodeValue??"";if(O.nodeType!==Node.ELEMENT_NODE)return"";let B=O,v=B.localName;if(f.has(v)||!i(B))return"";if(v==="br")return" ";if(v==="input"||v==="select"||v==="textarea")return` ${p(B)} `;if(v==="img")return` ${B.getAttribute("alt")??""} `;let b="";for(let h of[...B.childNodes])b+=l(h);return getComputedStyle(B).display.startsWith("inline")?b:` ${b} `},_=O=>O.length>t.max_value_chars?`${O.slice(0,t.max_value_chars)}\u2026`:O,y=O=>_(l(O).replace(/\s+/g," ").trim()),g=()=>d.localName==="table"?[...d.rows]:[...d.querySelectorAll('[role="row"]')].filter(O=>O.closest(r)===d),E=O=>O.localName==="tr"?[...O.cells]:[...O.querySelectorAll('[role="cell"], [role="gridcell"], [role="columnheader"], [role="rowheader"]')].filter(B=>B.closest('[role="row"]')===O),T=O=>O.localName==="th"||o(O)==="columnheader",I=(O,B,v)=>{let b=Number(O.getAttribute(B)??O.getAttribute(`aria-${B}`)??1);return Number.isInteger(b)&&b>=1?Math.min(b,v):1},k=[],C=O=>{let B=[],v=0,b=()=>{for(;k[v]!==void 0&&k[v].rows>0;)B[v]=k[v].text,k[v].rows--,v++};for(let h of O){b();let S=y(h),w=I(h,"colspan",100),N=I(h,"rowspan",t.max_rows);for(let H=0;H<w;H++)B[v]=S,k[v]=N>1?{text:S,rows:N-1}:void 0,v++}return b(),Array.from({length:B.length},(h,S)=>B[S]??"")},x=g().filter(i),F=[],M=0;for(let O of x){let B=E(O),v=O.parentElement?.localName==="thead";if(B.length===0||!(v||B.every(T)))break;F.push(C(B)),M++}let G=0,U=!1,j=[];for(let O of x.slice(M)){let B=C(E(O));if(B.every(b=>b===""))continue;let v=B.reduce((b,h)=>b+h.length,0);if(j.length>=t.max_rows||G+v>t.max_chars){U=!0;break}j.push(B),G+=v}let P=Math.max(0,...F.map(O=>O.length),...j.map(O=>O.length)),D=Array.from({length:P},(O,B)=>{let v=[];for(let b of F){let h=b[B]??"";h!==""&&!v.includes(h)&&v.push(h)}return v.length>0?v.join(" / "):`column ${B+1}`}),K=document.title.length>200?`${document.title.slice(0,200)}\u2026`:document.title;return{outputs:{url:location.href,title:K,columns:D,rows:j.map(O=>Array.from({length:P},(B,v)=>O[v]??"")),truncated:U}}},Il=(e,t,n)=>{let r=(c,d)=>({status:"error",error:{code:c,message:d}}),o=r("unknown","bridge: no readable answer from the page");if(!e||typeof e!="object"||Array.isArray(e)||Object.keys(e).length!==1)return o;let a=e;if(a.blocked===!0)return r("tab_navigation_blocked","The owner client cannot be automated.");if(a.missing===!0)return r("selector_not_found","No table on the page matches.");if(a.invalid===!0)return r("selector_not_found","The selector is not valid CSS.");if(a.stale===!0)return r("selector_not_found",fe);let i=a.outputs,s=c=>Array.isArray(c)&&c.every(d=>typeof d=="string");return!i||typeof i!="object"||Array.isArray(i)||Object.keys(i).sort().join()!=="columns,rows,title,truncated,url"||typeof i.url!="string"||typeof i.title!="string"||typeof i.truncated!="boolean"||!s(i.columns)||!Array.isArray(i.rows)||!i.rows.every(s)?o:n.pattern!==void 0&&!te(i.url,[n.pattern])?r("tab_navigation_blocked","The page is no longer on a site this step may read."):{status:"ok",outputs:{page:_e(t),...i}}};var Ct=(e,t)=>{if(document.documentElement.hasAttribute("data-recued-owner-surface")||t!=null&&location.href!==t)return{blocked:!0};let n;try{n=[...document.querySelectorAll(e.selector)]}catch{return{invalid:!0}}let r=c=>c.replace(/\s+/g," ").trim().toLowerCase(),o=e.text==null?"":r(e.text),a=c=>c.getAttribute("aria-hidden")!=="true"&&(c.checkVisibility({checkVisibilityCSS:!0})||getComputedStyle(c).display==="contents"),i=n.some(c=>a(c)&&(o===""||r(c.innerText??c.textContent??"").includes(o))),s=document.title.length>200?`${document.title.slice(0,200)}\u2026`:document.title;return{outputs:{url:location.href,title:s,met:e.until==="gone"?!i:i}}},kl=(e,t,n)=>{let{selector:r,until:o,text:a,timeout_ms:i}=e;return typeof r!="string"||r.trim()===""?{error:"Name what to wait for: a CSS selector."}:o!==void 0&&o!=="shown"&&o!=="gone"?{error:"Wait until it is shown or gone."}:a!==void 0&&typeof a!="string"?{error:"The text to wait for must be text."}:i!==void 0&&(typeof i!="number"||!Number.isFinite(i)||i<0)?{error:"The time to wait must be a number of milliseconds."}:{check:{selector:r,until:o??"shown",...a!==void 0&&a!==""?{text:a}:{}},timeout_ms:Math.min(t,i??n)}},io=e=>{if(e==null)return;if(typeof e!="object"||Array.isArray(e))return null;let{selector:t,text:n,...r}=e;return Object.keys(r).length>0||typeof t!="string"||t.trim()===""||n!==void 0&&(typeof n!="string"||n==="")?null:{selector:t,until:"shown",...typeof n=="string"?{text:n}:{}}},It=e=>{let t=(o,a)=>({error:{status:"error",error:{code:o,message:a}}});if(!e||typeof e!="object"||Array.isArray(e)||Object.keys(e).length!==1)return t("unknown","bridge: no readable answer from the page");let n=e;if(n.blocked===!0)return t("tab_navigation_blocked","The owner client cannot be automated.");if(n.invalid===!0)return t("selector_not_found","The selector is not valid CSS.");let r=n.outputs;return!r||typeof r.url!="string"||typeof r.title!="string"||typeof r.met!="boolean"||Object.keys(r).length!==3?t("unknown","bridge: no readable answer from the page"):{url:r.url,title:r.title,met:r.met}};var L=(e,t,n)=>({status:"error",error:{code:e,message:t,detail:n}}),vl=e=>L("capacity_gap_tab_unavailable",`bridge: no open tab matches ${e}`,e),ot=e=>L("selector_not_found",`bridge: selector ${e} not present in DOM`,e),vn=()=>L("delivery_uncertain","The browser could not confirm the command outcome. Check the page before retrying."),wl=200,kg=1e3,vg=1200,wg=1500,Og=5e3,Ol=e=>({url:String(e.url),title:String(e.title),role:String(e.role),label:String(e.label),protected:e.protected===!0,...typeof e.stable_selector=="string"?{selector:e.stable_selector}:{}}),rt=(e,t,n,r=L("tab_navigation_blocked","The owner client cannot be automated."))=>{let o=n!=="read_dom",a=o?vn():L("unknown",`bridge: no readable answer for ${t}`,t);if(!e||typeof e!="object"||Array.isArray(e)||Object.keys(e).length!==1)return a;let i=e;if(i.blocked===!0)return r;if(i.missing===!0)return ot(t);if(i.stale===!0)return L("selector_not_found",fe,t);if(!o&&i.protected===!0)return L("field_protected","The Browser Bridge does not read password, hidden, sign-in code or payment card fields.",t);if(o&&typeof i.not_applied=="string")return L("value_not_applied",i.not_applied,t);let s=i.outputs;if(!s||typeof s!="object"||Array.isArray(s))return a;let c=s,d=Object.keys(c);return n==="press"?typeof c.pressed=="string"&&d.every(u=>u==="pressed"||u==="sent"&&c.sent===!0)?{status:"ok",outputs:c}:a:d.length!==1?a:(n==="read_dom"?typeof c.text=="string":n==="fill"?c.filled===!0:n==="submit"?c.submitted===!0:c.clicked===!0)?{status:"ok",outputs:c}:a},xl=e=>e.frame_id!==void 0&&e.frame_id>0?{frame_id:e.frame_id}:{},ee=async(e,t,n,r)=>{try{return await e.executeInDocument(t,n,r)}catch{return null}},Fe=async(e,t,n,r=!1)=>{if(n===void 0)return;let a=(await ee(e,t,Al,[n,r]))?.result?.changed;return a===void 0?void 0:L("selector_not_found",br(n,String(a.now),String(a.was)))},be=async(e,t,n,r)=>{let o=await r();return n===void 0||o?.result?.stale!==!0?o:(await Fe(e,t,n),r())},he=()=>({status:"cancelled",error:{code:"unknown",message:"bridge: cooperative cancel observed mid-execution"}}),xg=(e,t)=>{if(t.length===0)return Object.keys(e).length===0;for(let n of Object.keys(e))if(!t.includes(n))return!1;return!0},ke=(e,t)=>{let n=e[t];return typeof n!="string"?null:n},so=e=>{let t=async()=>{if(!e.blockedSites)return[];try{return await e.blockedSites()}catch{return}},n=()=>L("tab_navigation_blocked",Zc),r=(i,s)=>s===void 0?n():Ae(i,s)?L("tab_navigation_blocked",yn):null,o=async(i,s)=>{if(s===void 0)return n();if(s.length===0)return null;if(!e.tabUrl)return n();let c=await e.tabUrl(i).catch(()=>null);return c===null?L("selector_not_found",de):r(c,s)},a=async(i,s,c)=>{if(c.signalled)return he();let d=i==="os_notification"?[]:await t();if(s.reviewed_document){if(!e.executeReviewedDocument)return L("tab_navigation_blocked","This bridge cannot bind reviewed documents.");let l=r(s.reviewed_document.url,d);return l||e.executeReviewedDocument(s.reviewed_document,i,s.args)}if(i==="os_notification"){let l=ke(s.args,"title")??"Recued",_=ke(s.args,"body")??"",y=ke(s.args,"icon_url")??"";return{status:"ok",outputs:{notification_id:await e.showNotification(s.command_id,{title:l,message:_,iconUrl:y})}}}if(i==="list_tabs")return e.listPages?d===void 0?n():{status:"ok",outputs:await e.listPages(s.target_domain_pattern,l=>Ae(l,d))}:L("unknown","bridge: this browser cannot list tabs");if(i==="open_tab"){let l=ke(s.args,"url");if(l===null)return L("unknown","bridge: open_tab requires a url argument");if(!e.openPage)return L("unknown","bridge: this browser cannot open tabs");if(d===void 0)return n();let _=r(l,d);return _||e.openPage(l,s.target_domain_pattern,Math.max(1e3,Math.min(2e4,s.timeout_ms-5e3)),y=>Ae(y,d))}if(i==="navigate"||i==="go_back"||i==="reload_page"||i==="close_tab"){let l=Be(s.args.page);if(!l)return L("unknown","bridge: this needs the page handle that listing the tabs or opening a page answered");let _=await o(l.tab_id,d);if(_)return _;if(c.signalled)return he();if(i==="close_tab")return e.closePage?e.closePage(l.tab_id):L("unknown","bridge: this browser cannot close tabs");if(!e.movePage)return L("unknown","bridge: this browser cannot move tabs");let y=E=>Ae(E,d??[]),g=Math.max(1e3,Math.min(2e4,s.timeout_ms-5e3));if(i==="navigate"){let E=ke(s.args,"url");if(E===null)return L("unknown","bridge: navigate requires a url argument");let T=r(E,d);return T||e.movePage(l.tab_id,{to:"address",url:E},s.target_domain_pattern,g,y)}return e.movePage(l.tab_id,{to:i==="go_back"?"back":"reload"},s.target_domain_pattern,g,y)}if(i==="hover"){let l=xe(s.args);if("error"in l)return L("unknown",`bridge: ${l.error}`);if(!l.page)return L("unknown","bridge: hover needs the page the element is on");if(!e.executeInDocument)return L("unknown","bridge: this browser cannot act on a page by ref");let _=l.page,y=await o(_.tab_id,d);if(y)return y;let g=await Fe(e,_,l.scope.ref,!0);if(g)return g;let E=await be(e,_,l.scope.ref,()=>ee(e,_,Me,[l.scope,null,null]));if(!E||E.document_id!==_.document_id)return L("selector_not_found",de);let T=Ue(E.result,_,{pattern:s.target_domain_pattern,blockedMessage:"The owner client cannot be automated."});if(T.status!=="ok")return T;let I=r(String(T.outputs.url),d);if(I)return I;if(c.signalled)return he();let k=T.outputs.url,C=await be(e,_,l.scope.ref,()=>ee(e,_,ul,[l.scope.selector??"",k,l.scope.ref??null]));if(!C||C.document_id!==_.document_id)return L("selector_not_found",de);let x=C.result;return x?.stale===!0?L("selector_not_found",fe):x?.missing===!0?ot(l.scope.ref??l.scope.selector):x?.hovered!==!0?L("tab_navigation_blocked","The page moved before the pointer reached it."):{status:"ok",outputs:{hovered:!0,page:_e(_),url:k,title:T.outputs.title}}}if(i==="download_file"){let l=Be(s.args.page);if(!l)return L("unknown","bridge: this needs the page handle that listing the tabs or opening a page answered");if(!e.executeInDocument)return L("unknown","bridge: this browser cannot read pages by handle");let _=typeof s.args.ref=="string"?s.args.ref:null,y=typeof s.args.selector=="string"?s.args.selector:null,g=typeof s.args.address=="string"?s.args.address:null;if((_===null&&y===null)==(g===null))return L("unknown","bridge: download_file takes the link by ref or selector, or the file's address");let E=typeof s.args.max_bytes=="number"&&s.args.max_bytes>0?Math.min(s.args.max_bytes,gt):gt,T=await o(l.tab_id,d);if(T)return T;if(c.signalled)return he();let I=_===null?void 0:await Fe(e,l,_,!0);if(I)return I;let k=await be(e,l,_??void 0,()=>ee(e,l,pl,[y,_,g]));if(!k||k.document_id!==l.document_id)return L("selector_not_found",de);let C=k.result;if(C===null||"blocked"in C)return L("tab_navigation_blocked","The owner client cannot be automated.");if("stale"in C)return L("selector_not_found",fe);if("missing"in C)return ot(_??y);if("no_address"in C)return L("selector_not_found",ml);if(!te(C.url,[s.target_domain_pattern]))return L("tab_navigation_blocked","The page is no longer on a site this step may read.");let x=r(C.url,d)??r(C.address,d);if(x)return x;if(c.signalled)return he();let M=(await ee(e,l,ro,[C.address,E]))?.result;return(M==null||"failed"in M&&C.cross_origin)&&(M=await ro(C.address,E)),"too_large"in M?L("unknown",_l(M.too_large,M.at_least===!0,E)):"failed"in M?L("unknown",`The file at ${C.address} could not be fetched: ${M.failed}.`):{status:"ok",outputs:{page:_e(l),url:C.url,title:C.title,address:M.address,filename:M.filename,mime_type:M.mime_type,size:M.size,data:M.data}}}if(i==="upload_file"){let l=xe(s.args);if("error"in l)return L("unknown",`bridge: ${l.error}`);if(!l.page)return L("unknown","bridge: upload_file needs the page the field is on");if(!e.executeInDocument)return L("unknown","bridge: this browser cannot act on a page by ref");let{filename:_,mime_type:y,data:g}=s.args;if(typeof _!="string"||_===""||typeof y!="string"||typeof g!="string"||g.length>Math.ceil(gt/3)*4||!/^[A-Za-z0-9+/]*={0,2}$/.test(g))return L("unknown","bridge: upload_file takes a filename, a mime_type and the file in base64");let E=l.page,T=await o(E.tab_id,d);if(T)return T;let I=await Fe(e,E,l.scope.ref,!0);if(I)return I;let k=await be(e,E,l.scope.ref,()=>ee(e,E,Me,[l.scope,null,null]));if(!k||k.document_id!==E.document_id)return L("selector_not_found",de);let C=Ue(k.result,E,{pattern:s.target_domain_pattern,blockedMessage:"The owner client cannot be automated."});if(C.status!=="ok")return C;let x=r(String(C.outputs.url),d);if(x)return x;if(c.signalled)return he();let F=await be(e,E,l.scope.ref,()=>ee(e,E,gl,[l.scope.selector??null,l.scope.ref??null,_,y,g]));if(!F||F.document_id!==E.document_id)return L("selector_not_found",de);let M=F.result;return M===null||"blocked"in M?L("tab_navigation_blocked","The owner client cannot be automated."):"stale"in M?L("selector_not_found",fe):"missing"in M?ot(l.scope.ref??l.scope.selector):"not_file_field"in M?L("selector_not_found",fl):{status:"ok",outputs:{attached:M.attached,page:_e(E),url:M.url,title:M.title}}}if(i==="inspect"||i==="describe"||i==="reread"){let l=i!=="describe",_=l?et(s.args):xe(s.args);if("error"in _)return L("unknown",`bridge: ${_.error}`);if(!e.executeInDocument)return L("unknown","bridge: this browser cannot inspect pages");let y=_.page?.tab_id;if(y===void 0){let k=await e.findTabByUrlPattern(s.target_domain_pattern);if(!k)return vl(s.target_domain_pattern);let C=r(k.url,d);if(C)return C;y=k.tab_id}else{let k=await o(y,d);if(k)return k}if(c.signalled)return he();_.page&&await Fe(e,{tab_id:y,document_id:_.page.document_id},_.scope.ref);let g={tab_id:y,..._.page?{document_id:_.page.document_id}:{}},E=await be(e,g,_.page?_.scope.ref:void 0,()=>ee(e,g,l?bn:Me,i==="reread"?[_.scope,_.limits,null,tl]:l?[_.scope,_.limits]:[_.scope]));if(_.page&&(!E||E.document_id!==_.page.document_id))return L("selector_not_found",de);if(!E)return L("unknown","bridge: the browser did not let the Bridge read the page");let T=E.result;if(l&&typeof T?.outputs?.html=="string"&&T.outputs.html.includes('data-recued-frame="')){let k=E.frame_id===0&&e.listFrames?await e.listFrames(y).catch(()=>null):null;T.outputs.html=Rn(T.outputs.html,y,k,C=>d===void 0||Ae(C,d))}let I=(l?Sn:Ue)(E.result,{tab_id:y,document_id:E.document_id},{pattern:s.target_domain_pattern,blockedMessage:"The owner client cannot be automated."});return I.status==="ok"?r(String(I.outputs.url),d)??I:I}if((i==="fill"||i==="click"||i==="submit"||i==="press")&&(i==="submit"||i==="press"||s.args.page!==void 0||s.args.ref!==void 0)){let l=xe(s.args);if("error"in l)return L("unknown",`bridge: ${l.error}`);let _=ke(s.args,"value"),y=i==="press"?gr(s.args.key):null;if(i==="press"&&y===null)return L("unknown","bridge: key is not one the Bridge presses: a named key such as Enter or Escape, a letter, a digit, or one of those after Control, Meta, Alt or Shift and a +");if(!l.page||i==="fill"&&_===null)return L("unknown",`bridge: ${i==="fill"&&_===null?"fill action requires value argument":"a write by ref needs the page it came from"}`);if(!e.executeInDocument)return L("unknown","bridge: this browser cannot act on a page by ref");let g=l.page,E=await o(g.tab_id,d);if(E)return E;let T=l.scope.ref??l.scope.selector,I=await Fe(e,g,l.scope.ref,!0);if(I)return I;let k=s.expects_output_keys.includes(Xt),C=await be(e,g,l.scope.ref,()=>ee(e,g,Me,[l.scope,null,k?oo:null]));if(!C||C.document_id!==g.document_id)return L("selector_not_found",de);let x=Ue(C.result,g,{pattern:s.target_domain_pattern,blockedMessage:"The owner client cannot be automated."});if(x.status!=="ok")return x;let F=k?{acted_on:Ol(x.outputs)}:{},M=r(String(x.outputs.url),d);if(M)return M;if(c.signalled)return he();let G=x.outputs.url,U=l.scope.ref===void 0?[]:[l.scope.ref],j=l.scope.selector??"",P=(i==="click"||i==="submit"||i==="press")&&s.expects_output_keys.includes("problem"),D=i==="click"&&typeof s.args.send_watch_ms=="number"&&Number.isFinite(s.args.send_watch_ms)?Math.max(0,Math.min(Zt,s.args.send_watch_ms)):void 0,K=i==="fill"?void 0:io(s.args.fail);if(K===null)return L("unknown","bridge: fail is { selector, text } naming what means the step failed");let O=!1,B;if(P||D!==void 0){let z=await ee(e,g,yl,[j,l.scope.ref??null,Cn]),ve=z!==null&&z.document_id===g.document_id?z.result:null;O=ve?.sends===!0,B=i==="click"&&typeof ve?.unsent=="string"?ve.unsent:void 0}let v=i==="submit"&&_!==null,b=Date.now(),h=Math.max(0,Math.min(hr,s.timeout_ms-15e3)),S=await be(e,g,l.scope.ref,()=>i==="click"?ee(e,g,nt,[j,G,l.scope.ref??null,h]):i==="press"?ee(e,g,dl,[j,G,l.scope.ref??null,y]):i==="submit"&&!v?ee(e,g,ll,[j,G,l.scope.ref??null]):ee(e,g,tt,v?[j,_,G,l.scope.ref??null,!0]:[j,_,G,...U]));if(!S||S.document_id!==g.document_id)return vn();let w=rt(S.result,T,i,L("selector_not_found",fe)),N=w.status==="ok"?{...w,outputs:{...v?{filled:!0}:{},...w.outputs,...F}}:w;if(N.status!=="ok"||c.signalled)return N;let H=s.expects_output_keys.includes("challenge");if(i==="fill"){if(!H)return N;let z=await ee(e,g,Tn,[]);return z!==null&&z.document_id===g.document_id&&typeof z.result=="string"?{...N,outputs:{...N.outputs,challenge:z.result}}:N}let V={...i==="click"&&O&&s.expects_output_keys.includes("sent")?{sent:!0}:{},...B!==void 0&&P?{problem:B}:{}};if(!e.pageAfterClick||!s.expects_output_keys.includes("page"))return{...N,outputs:{...N.outputs,...V}};let q=d??[],Y=Math.max(0,s.timeout_ms-(Date.now()-b)-3e3),W=typeof s.args.watch_ms=="number"&&Number.isFinite(s.args.watch_ms)?Math.max(0,Math.min(Zt,s.args.watch_ms)):Qt,Z=Math.min(O&&D!==void 0?Math.max(W,D):W,Y),Q=await e.pageAfterClick(g.tab_id,{url:G,page:_e(g),...xl(C)},s.target_domain_pattern,{settleMs:Z,loadMs:Math.max(0,Math.min(Jt,Y-Z))},z=>Ae(z,q),{challenge:H,...P?{problems:Cn}:{},...K!==void 0&&s.expects_output_keys.includes("failed")?{fail:K}:{}});if(Q===void 0)return{...N,outputs:{...N.outputs,...V}};let ie=Object.fromEntries(Object.entries(Q).filter(([z])=>s.expects_output_keys.includes(z)));return{...N,outputs:{...N.outputs,...ie,...V}}}if(i==="pick"){let l=Date.now(),_=xe(s.args);if("error"in _)return L("unknown",`bridge: ${_.error}`);let y=ke(s.args,"value"),g=ke(s.args,"pick");if(!_.page||y===null||y.trim()===""||g===null||g.trim()==="")return L("unknown","bridge: pick needs the page, the field, the text to type and the suggestion to pick");if(!e.executeInDocument)return L("unknown","bridge: this browser cannot act on a page by ref");let E=_.page,T=await o(E.tab_id,d);if(T)return T;let I=_.scope.ref??_.scope.selector,k=await Fe(e,E,_.scope.ref,!0);if(k)return k;let C=s.expects_output_keys.includes(Xt),x=await be(e,E,_.scope.ref,()=>ee(e,E,Me,[_.scope,null,C?oo:null]));if(!x||x.document_id!==E.document_id)return L("selector_not_found",de);let F=Ue(x.result,E,{pattern:s.target_domain_pattern,blockedMessage:"The owner client cannot be automated."});if(F.status!=="ok")return F;let M=r(String(F.outputs.url),d);if(M)return M;if(c.signalled)return he();let G=F.outputs.url,U=_.scope.ref??null,j=_.scope.selector??"";await ee(e,E,El,[j,U,kn]);let P=await be(e,E,U??void 0,()=>ee(e,E,tt,[j,y,G,...U===null?[]:[U]]));if(!P||P.document_id!==E.document_id)return vn();let D=rt(P.result,I,"fill",L("selector_not_found",fe));if(D.status!=="ok")return D;let K=Math.max(0,Math.min(fr,s.timeout_ms-8e3)),O=typeof s.args.pick_ms=="number"&&Number.isFinite(s.args.pick_ms)?Math.max(0,Math.min(K,s.args.pick_ms)):Math.min(Og,K),B=Date.now(),v={no_list:!0},b="",h=B,S=!1,w;for(;;){if(c.signalled)return he();let Y=await ee(e,E,bl,[j,U,g,kn]);if(!Y||Y.document_id!==E.document_id)return L("value_not_applied",`The page moved on once \u201C${y}\u201D was typed, before a suggestion was picked.`);let W=Y.result??{};if(W.blocked===!0)return L("tab_navigation_blocked","The owner client cannot be automated.");if(W.gone===!0)return L("value_not_applied","The field went from the page once it was typed into, so nothing was picked.");if(typeof W.found=="string"&&typeof W.label=="string"&&typeof W.url=="string"){w={found:W.found,label:W.label,url:W.url};break}let Z=Date.now(),Q=JSON.stringify(W);if(Q!==b&&(b=Q,h=Z,v=W),v.no_list===!0&&!S&&Z-B>=kg){S=!0,await ee(e,E,Sl,[j,U,y]);continue}if(v.no_list!==!0&&Z-h>=vg||Z-B>=O)break;await new Promise(ie=>setTimeout(ie,wl))}if(w===void 0){let Y=W=>W.map(Z=>`\u201C${Z}\u201D`).join("; ");return L("value_not_applied",v.several!==void 0?`Several of its suggestions match \u201C${g}\u201D: ${Y(v.several)}. Pick one of them by its whole text.`:v.none!==void 0?`None of its suggestions is \u201C${g}\u201D. They were: ${Y(v.none)}. Pick one of them by its text.`:`No suggestions showed within ${Math.round(O/1e3)} seconds of typing \u201C${y}\u201D, so nothing was picked. The text is in the field.`)}if(c.signalled)return he();let N=await ee(e,E,nt,["",w.url,w.found]);if(!N||N.document_id!==E.document_id)return vn();let H=rt(N.result,w.label,"click",L("selector_not_found",`The suggestion \u201C${w.label}\u201D went from the page before it could be clicked.`));if(H.status!=="ok")return H;let V={filled:!0,picked:w.label,...C?{acted_on:Ol(F.outputs)}:{}},q=!1;if(e.pageAfterClick&&s.expects_output_keys.includes("page")){let Y=d??[],W=Math.max(0,s.timeout_ms-(Date.now()-l)-3e3),Z=Math.min(Qt,W),Q=await e.pageAfterClick(E.tab_id,{url:w.url,page:_e(E),...xl(x)},s.target_domain_pattern,{settleMs:Z,loadMs:Math.max(0,Math.min(Jt,W-Z))},ie=>Ae(ie,Y),{challenge:s.expects_output_keys.includes("challenge")});if(Q!==void 0){q=Q.moved;for(let[ie,z]of Object.entries(Q))s.expects_output_keys.includes(ie)&&(V[ie]=z)}}if(!q){let Y=Date.now()+wg,W;for(;;){let Z=await ee(e,E,Rl,[j,U,y,g,kn]);if(!Z||Z.document_id!==E.document_id){W=void 0;break}if(W=Z.result??{},W.took!==void 0||W.unknown===!0||Date.now()>=Y)break;await new Promise(Q=>setTimeout(Q,wl))}if(W!==void 0&&W.took===void 0&&W.unknown!==!0)return L("value_not_applied",W.open===!0?`\u201C${w.label}\u201D was clicked, but its list is still open and nothing shows it was picked.`:`\u201C${w.label}\u201D was clicked, but the field does not show it, so it may not have been picked.`)}return{status:"ok",outputs:V}}if(i==="wait_for_element"||i==="read_table"||i==="screenshot_page"||i==="scroll"){let l=Be(s.args.page);if(!l)return L("unknown","bridge: this needs the page handle that listing the tabs or opening a page answered");if(!e.executeInDocument)return L("unknown","bridge: this browser cannot read pages by handle");let _=await o(l.tab_id,d);if(_)return _;if(c.signalled)return he();if(i==="wait_for_element"){let T=Math.max(0,Math.min(Rr,s.timeout_ms-2e3)),I=kl(s.args,T,Math.min(Sr,T));if("error"in I)return L("unknown",`bridge: ${I.error}`);let k=io(s.args.fail);if(k===null)return L("unknown","bridge: fail is { selector, text } naming what means the step failed");let C=s.args.problems===!0,x=Date.now();for(;;){if(c.signalled)return he();let F=await ee(e,l,Ct,[I.check]);if(!F||F.document_id!==l.document_id)return L("selector_not_found",de);let M=It(F.result);if("error"in M)return M.error;if(!te(M.url,[s.target_domain_pattern]))return L("tab_navigation_blocked","The page is no longer on a site this step may read.");let G=r(M.url,d);if(G)return G;let U=Date.now()-x,j=P=>({status:"ok",outputs:{page:_e(l),url:M.url,title:M.title,waited_ms:U,...P}});if(k!==void 0){let P=await ee(e,l,Ct,[k]),D=P&&P.document_id===l.document_id?It(P.result):void 0;if(D!==void 0&&!("error"in D)&&D.met)return j({found:!1,failed:!0})}if(M.met)return j({found:!0});if(C){let P=await ee(e,l,In,[Cn]);if(P!==null&&P.document_id===l.document_id&&typeof P.result=="string")return j({found:!1,problem:P.result})}if(U>=I.timeout_ms)return j({found:!1});await new Promise(P=>setTimeout(P,Math.min(200,I.timeout_ms-U)))}}let y=et(s.args);if("error"in y)return L("unknown",`bridge: ${y.error}`);if(await Fe(e,l,y.scope.ref),i==="scroll"){let T=s.args.to,I=s.args.screen;if(T!==void 0&&!zt.includes(T))return L("unknown",`bridge: to is ${zt.join(", ")}`);if(I!==void 0&&(!Number.isSafeInteger(I)||I<1))return L("unknown","bridge: screen is a whole number from 1, the top of the page");let k=async U=>{let j=await be(e,l,y.scope.ref,()=>ee(e,l,to,[y.scope,null,U,null,eo,!1]));return!j||j.document_id!==l.document_id?{error:L("selector_not_found",de)}:no(j.result)},C=await k(null);if("error"in C)return C.error;let x=await k(al({screen:C.screen??1,screens:C.screens??1},T,I));if("error"in x)return x.error;await ee(e,l,cl,[250,1500,800]);let F=await k(null),M="error"in F?x:F;if(!te(M.url,[s.target_domain_pattern]))return L("tab_navigation_blocked","The page is no longer on a site this step may read.");let G=r(M.url,d);return G||{status:"ok",outputs:{page:_e(l),url:M.url,title:M.title,screen:M.screen??1,screens:M.screens??1}}}if(i==="read_table"){let T=await be(e,l,y.scope.ref,()=>ee(e,l,Cl,[y.scope,Tl]));if(!T||T.document_id!==l.document_id)return L("selector_not_found",de);let I=Il(T.result,l,{pattern:s.target_domain_pattern});return I.status==="ok"?r(String(I.outputs.url),d)??I:I}if(!e.pageCapture)return L("unknown","bridge: this browser cannot take screenshots");let g=s.args.screen;if(g!==void 0&&(!Number.isSafeInteger(g)||g<1))return L("unknown","bridge: screen is a whole number from 1, the top of the page");let E=d??[];return il(e.pageCapture,{page:l,scope:y.scope,pattern:s.target_domain_pattern,blocked:T=>Ae(T,E),...g!==void 0?{screen:g}:{},screens:s.expects_output_keys.includes("screens")})}let f=await e.findTabByUrlPattern(s.target_domain_pattern);if(!f)return vl(s.target_domain_pattern);let u=r(f.url,d);if(u)return u;if(c.signalled)return he();let m=async l=>{try{return await e.executeScript(l,()=>document.documentElement.hasAttribute("data-recued-owner-surface"),{selector:""})===!0}catch{return!0}};if(i==="screenshot"){if(await m(f.tab_id))return L("tab_navigation_blocked","The owner client cannot be captured.");let l=await e.captureVisibleTab({tab_id:f.tab_id,window_id:f.window_id,url_pattern:s.target_domain_pattern});return l?{status:"ok",outputs:{data_url:l}}:L("tab_navigation_blocked","bridge: screenshot capture blocked")}let p=ke(s.args,"selector");if(!p)return L("unknown","bridge: action requires selector argument");if(i==="read_dom")return rt(await e.executeScript(f.tab_id,An,{selector:p}),p,"read_dom");if(i==="wait_for_selector")return await e.executeScript(f.tab_id,_=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))throw new Error("The owner client cannot be automated.");return!!document.querySelector(_)},{selector:p})?{status:"ok",outputs:{present:!0}}:ot(p);if(i==="click")return rt(await e.executeScript(f.tab_id,nt,{selector:p}),p,"click");if(i==="fill"){let l=ke(s.args,"value");return l===null?L("unknown","bridge: fill action requires value argument"):rt(await e.executeScript(f.tab_id,tt,{selector:p,value:l}),p,"fill")}if(i==="extract_table"){let l=await e.executeScript(f.tab_id,_=>{if(document.documentElement.hasAttribute("data-recued-owner-surface"))throw new Error("The owner client cannot be automated.");let y=document.querySelector(_);if(!y)return null;let g=[],E=y.querySelector("tr");E&&E.querySelectorAll("th, td").forEach(k=>{g.push((k.textContent??"").trim())});let T=[];return y.querySelectorAll("tbody tr").forEach(k=>{let C=k.querySelectorAll("td"),x={};C.forEach((F,M)=>{x[g[M]??`col_${M}`]=(F.textContent??"").trim()}),T.push(x)}),T},{selector:p});return l===null?ot(p):{status:"ok",outputs:{rows:l}}}return L("unknown",`bridge: unsupported action: ${i}`)};return{async execute(i){let s=await a(i.action,i.command,i.cancel);return s.status==="ok"&&s.outputs&&!xg(s.outputs,i.command.expects_output_keys)?L("unknown","bridge: executor returned unexpected output keys",i.command.expects_output_keys.join(",")):s}}};var Pl=async(e,t,n)=>{if(n.length===0)return[];let r;try{r=await e.query({url:[...n]})}catch{return[]}if(r.length>Ir)return[];let o=[];for(let a of r)if(Number.isSafeInteger(a.id))try{let s=(await t.executeScript({target:{tabId:a.id},args:[],func:()=>document.documentElement.hasAttribute("data-recued-owner-surface")?null:location.href}))[0],c={tab_id:a.id,document_id:s?.documentId,url:s?.result};en(c)&&o.push(c)}catch{}return o},Nl=async(e,t,n,r)=>{let o=()=>({status:"error",error:{code:"tab_navigation_blocked",message:"The reviewed browser document is unavailable or changed."}}),a=()=>({status:"error",error:{code:n==="fill"||n==="click"?"delivery_uncertain":"unknown",message:"The browser could not confirm the reviewed command outcome. Check the page before retrying."}}),i=()=>n==="fill"||n==="click"?a():o();if(!en(t))return o();let s={tabId:t.tab_id,documentIds:[t.document_id]};if(n==="inspect"||n==="describe"){let _=n==="inspect"?et(r):xe(r);if("error"in _||_.page&&(_.page.tab_id!==t.tab_id||_.page.document_id!==t.document_id))return o();let y;try{y=await(n==="inspect"?e.executeScript({target:s,func:bn,args:[_.scope,_.limits,t.url]}):e.executeScript({target:s,func:Me,args:[_.scope,t.url]}))}catch{return o()}if(y[0]?.documentId!==t.document_id)return o();let g=y[0].result;return n==="inspect"&&typeof g?.outputs?.html=="string"&&(g.outputs.html=Rn(g.outputs.html,t.tab_id,null,()=>!0)),(n==="inspect"?Sn:Ue)(y[0].result,t,{blockedMessage:"The reviewed browser document is unavailable or changed."})}if(!["read_dom","fill","click"].includes(n)||n==="fill"&&typeof r.value!="string")return o();let c=n!=="read_dom"&&(r.page!==void 0||r.ref!==void 0),d=c?xe(r):null;if(d&&("error"in d||d.page&&(d.page.tab_id!==t.tab_id||d.page.document_id!==t.document_id))||!c&&typeof r.selector!="string")return o();let f=d&&!("error"in d)?d.scope:{selector:r.selector},u=f.ref===void 0?[]:[f.ref],m;try{m=await(n==="read_dom"?e.executeScript({target:s,func:An,args:[f.selector,t.url]}):n==="fill"?e.executeScript({target:s,func:tt,args:[f.selector??"",r.value,t.url,...u]}):e.executeScript({target:s,func:nt,args:[f.selector??"",t.url,...u]}))}catch{return a()}let p=m[0];if(p?.documentId!==t.document_id||!p.result||typeof p.result!="object"||Array.isArray(p.result))return i();let l=p.result;if(Object.keys(l).length!==1)return i();if(l.blocked===!0)return o();if(l.missing===!0)return{status:"error",error:{code:"selector_not_found",message:"The reviewed selector is missing."}};if(c&&l.stale===!0)return{status:"error",error:{code:"selector_not_found",message:fe}};if(n==="read_dom"&&l.protected===!0)return{status:"error",error:{code:"field_protected",message:"The Browser Bridge does not read password, hidden, sign-in code or payment card fields."}};if((n==="fill"||n==="click")&&typeof l.not_applied=="string")return{status:"error",error:{code:"value_not_applied",message:l.not_applied}};if(!l.outputs||typeof l.outputs!="object"||Array.isArray(l.outputs))return i();if(n==="fill"||n==="click"){let _=n==="fill"?"filled":"clicked";if(Object.keys(l.outputs).length!==1||l.outputs[_]!==!0)return i()}return{status:"ok",outputs:l.outputs}};var Pg=()=>globalThis.navigation?.canGoBack===!1?{nowhere:!0}:(history.back(),{going:!0}),Ng=1500,Dg=()=>document.documentElement.hasAttribute("data-recued-owner-surface")?{blocked:!0}:{url:location.href,title:document.title.length>200?`${document.title.slice(0,200)}\u2026`:document.title},$e=async(e,t,n)=>{let r;try{[r]=await e.executeScript({target:{tabId:t,...n!==void 0?{frameIds:[n]}:{}},func:Dg,args:[]})}catch{return"unreadable"}let o=r?.result;return o?.blocked===!0?"owner":typeof r?.documentId!="string"||typeof o?.url!="string"||typeof o.title!="string"?"unreadable":{page:_e({tab_id:t,document_id:r.documentId}),url:o.url,title:o.title}},se=(e,t)=>({status:"error",error:{code:e,message:t}}),Lg=()=>({url:location.href,loaded:document.readyState==="complete"}),Dl=async(e,t,n)=>{let r=Be(t);if(r===null)return{};let o=Tt(e),a=async(s,c)=>{try{let d=await o(r,s,c);return d!==null&&d.document_id===r.document_id?d.result:void 0}catch{return}},i={};if(n.challenge===!0){let s=await a(Tn,[]);typeof s=="string"&&(i.challenge=s)}if(n.fail!==void 0){let s=It(await a(Ct,[n.fail]));!("error"in s)&&s.met&&(i.failed=!0)}if(n.problems!==void 0){let s=await a(In,[n.problems]);typeof s=="string"&&(i.problem=s)}return i},Mg=500,Ll="The page went on to a site the owner listed as one Recued must never use, so its tab was closed.",Ml=(e,t,n=r=>new Promise(o=>setTimeout(o,r)))=>({async listPages(r,o=()=>!1){let a;try{a=await e.query({url:r})}catch{return{tabs:[],truncated:!1}}let i=[];for(let s of a){if(!Number.isSafeInteger(s.id)||typeof s.url=="string"&&o(s.url))continue;if(i.length===50)return{tabs:i,truncated:!0};let c=await $e(t,s.id);typeof c=="object"&&te(c.url,[r])&&!o(c.url)&&i.push(c)}return{tabs:i,truncated:!1}},async openPage(r,o,a,i=()=>!1){let s;try{s=new URL(r)}catch{return se("tab_navigation_blocked","The address is not a web address.")}if(s.protocol!=="http:"&&s.protocol!=="https:"||s.username||s.password)return se("tab_navigation_blocked","Only an http or https address, without a user name or password, can be opened.");if(!te(s.href,[o]))return se("tab_navigation_blocked","The address is not on a site this step may open.");let c;try{c=(await e.create({url:s.href,active:!1})).id}catch{return se("unknown","bridge: the browser did not open the tab")}let d=_=>se("delivery_uncertain",_);if(!Number.isSafeInteger(c))return d("The browser may have opened the tab without saying which. List the tabs before opening it again.");let f=Date.now()+a,u,m=!1;for(;;){let _=await e.get(c).catch(()=>null);if(!_)return d("The tab closed before its page could be read.");if(u=_.url,_.status==="complete"){m=!0;break}if(Date.now()>=f)break;await n(100)}let p=async _=>(await e.remove(c).catch(()=>{}),se("tab_navigation_blocked",_));if(u!==void 0&&/^https?:/i.test(u)&&!te(u,[o]))return p("The page went on to a site this step may not open, so its tab was closed.");if(u!==void 0&&/^https?:/i.test(u)&&i(u))return p(Ll);if(!m)return d("The tab opened, but its page had not finished loading. List the tabs, or inspect it, before opening it again.");let l=await $e(t,c);return l==="owner"?p("The owner client cannot be automated, so its tab was closed."):l==="unreadable"?d("The tab opened, but its page could not be read yet. List the tabs, or inspect it, before opening it again."):te(l.url,[o])?i(l.url)?p(Ll):{status:"ok",outputs:{...l}}:p("The page went on to a site this step may not open, so its tab was closed.")},async pageAfterClick(r,o,a,i,s=()=>!1,c={}){let d=typeof o.frame_id=="number"&&o.frame_id>0?o.frame_id:void 0,f=o.page===void 0?null:Be(o.page),u=async()=>{try{let[C]=await t.executeScript({target:{tabId:r,frameIds:[d]},func:Lg,args:[],injectImmediately:!0}),x=C?.result;return typeof C?.documentId=="string"&&typeof x?.url=="string"?{document_id:C.documentId,url:x.url,loaded:x.loaded===!0}:null}catch{return null}},m=C=>C===null||C.document_id!==f?.document_id||C.url!==o.url,p=Date.now()+i.settleMs,l=c.challenge===!0||c.fail!==void 0||c.problems!==void 0,_=!1,y={},g=Date.now();for(;;){let C=await e.get(r).catch(()=>null);if(!C)return;if(d===void 0?C.status==="loading"||typeof C.url=="string"&&C.url!==o.url:m(await u())){_=!0;break}if(Date.now()>=p||l&&o.page!==void 0&&Date.now()-g>=Mg&&(y=await Dl(t,o.page,c),g=Date.now(),Object.keys(y).length>0))break;await n(100)}if(_){let C=Date.now()+i.loadMs;for(;;){let x=await e.get(r).catch(()=>null);if(!x)return;let F=d===void 0?null:await u();if(F!==null?F.loaded:x.status==="complete")break;if(Date.now()>=C)return{moved:!0};await n(100)}}let E=d===void 0?null:await u(),T,I;if(E!==null){if(T={moved:m(E)},s(E.url)||!te(E.url,[a]))return T;I=await $e(t,r,d)}else{T={moved:_||d!==void 0};let C=await e.get(r).catch(()=>null);if(!C)return;if(typeof C.url=="string"&&/^https?:/i.test(C.url)&&(s(C.url)||!te(C.url,[a])))return T;I=await $e(t,r)}if(typeof I!="object"||s(I.url)||!te(I.url,[a]))return T;if(!l)return{...T,...I};let k=Object.keys(y).length>0?y:await Dl(t,I.page,c);return{...T,...I,...k}},async movePage(r,o,a,i,s=()=>!1){if(o.to==="address"){let y;try{y=new URL(o.url)}catch{return se("tab_navigation_blocked","The address is not a web address.")}if(y.protocol!=="http:"&&y.protocol!=="https:"||y.username||y.password)return se("tab_navigation_blocked","Only an http or https address, without a user name or password, can be loaded.");if(!te(y.href,[a]))return se("tab_navigation_blocked","The address is not on a site this step may open.");if(s(y.href))return se("tab_navigation_blocked","The owner listed this site as one Recued must never use.")}let c=await e.get(r).catch(()=>null);if(!c)return se("selector_not_found","The tab has closed.");if(o.to==="address"&&e.update===void 0||o.to==="reload"&&e.reload===void 0)return se("unknown","bridge: this browser cannot move a tab");try{if(o.to==="address")await e.update(r,{url:o.url});else if(o.to==="reload")await e.reload(r);else{let[y]=await t.executeScript({target:{tabId:r},func:Pg,args:[]});if(y?.result?.nowhere===!0)return se("unknown","The tab has no page to go back to.")}}catch{return o.to==="back"?se("unknown","The tab's page could not be asked to go back."):se("unknown","bridge: the browser did not move the tab")}let d=y=>se("delivery_uncertain",y),f=Date.now()+i,u=Date.now()+Ng,m=!1,p;for(;;){let y=await e.get(r).catch(()=>null);if(!y)return d("The tab closed while its page loaded.");if(p=y.url,(y.status==="loading"||y.url!==c.url)&&(m=!0),m&&y.status==="complete"||!m&&Date.now()>=u)break;if(Date.now()>=f)return d("The tab started loading a page that had not finished in time. List the tabs, or inspect it, before moving it again.");await n(100)}let l=y=>se("tab_navigation_blocked",`The tab went on to ${y}, so its page cannot be read.`);if(p!==void 0&&/^https?:/i.test(p)){if(!te(p,[a]))return l("a site this step may not read");if(s(p))return l("a site the owner listed as one Recued must never use")}let _=await $e(t,r);for(;_==="unreadable"&&Date.now()<f;)await n(100),_=await $e(t,r);return _==="owner"?l("the owner client"):_==="unreadable"?d("The tab moved, but its page could not be read yet. List the tabs, or inspect it."):te(_.url,[a])?s(_.url)?l("a site the owner listed as one Recued must never use"):{status:"ok",outputs:{..._}}:l("a site this step may not read")},async closePage(r){if(await $e(t,r)==="owner")return se("tab_navigation_blocked","The owner client cannot be automated.");try{await e.remove(r)}catch{return se("selector_not_found","The tab had already closed.")}return{status:"ok",outputs:{closed:!0}}}});var Bl=async(e,t)=>{try{return await e.update(t.tab_id,{active:!0}),(await e.query({active:!0,windowId:t.window_id,url:t.url_pattern})).some(r=>r.id===t.tab_id)?await e.captureVisibleTab(t.window_id,{format:"png"}):null}catch{return null}};var ao=(e,t,n)=>`${e}::${t}::${n}`,kt=()=>{let e=new Map;return{async get(t,n,r){return e.get(ao(t,n,r))??null},async put(t){e.set(ao(t.publisher_id,t.slug,t.version),t)},async remove(t,n,r){e.delete(ao(t,n,r))},async list(){return[...e.values()]},async clear(){e.clear()}}};var Ul="picker/picker.js",Fl=e=>typeof e=="string"&&(e.startsWith("http://")||e.startsWith("https://")),co=e=>({async injectIntoActiveTab(){let t;try{t=await e.queryActiveTab()}catch(n){return{ok:!1,reason:"no_active_tab",detail:n instanceof Error?n.message:String(n)}}if(t===null||typeof t.id!="number")return{ok:!1,reason:"no_active_tab"};if(!Fl(t.url))return{ok:!1,reason:"unsupported_page"};try{return await e.injectFile(t.id,Ul),{ok:!0}}catch(n){return{ok:!1,reason:"inject_failed",detail:n instanceof Error?n.message:String(n)}}}});var Bg=new Set(Qe),lo=e=>{if(!Bg.has(e))throw new Error(`bridge.local-store: refusing to write field outside spec \xA7 A.3.4: ${e}`)};var uo=e=>({async get(t){return lo(t),(await e.get([t]))[t]??null},async set(t,n){lo(t),await e.set({[t]:n})},async remove(t){lo(t),await e.remove([t])},async inspect(){let t=await e.get([...Qe]);return{server_url:t.server_url??null,webclient_token:t.webclient_token??null,server_public_key:t.server_public_key??null,pair_metadata:t.pair_metadata??null,cert_pin_state:t.cert_pin_state??null,chrome_permissions_state:t.chrome_permissions_state??{origins:[]},idempotency_cache:t.idempotency_cache??{store_name:"recued.bridge.idempotency",last_flush_at:0},pending_outbox:t.pending_outbox??{store_name:"recued.bridge.outbox",depth:0},blocked_sites:t.blocked_sites??null,approval_notices_shown:t.approval_notices_shown??null}},async clear(){await e.remove(Qe.filter(t=>t!=="blocked_sites"))}});var vt={name:"AES-GCM",iv_length_bytes:12,key_bits:256},Te=class extends Error{constructor(n){super(`bridge.token-store: ${n}`);this.reason=n}reason;code="webclient_token_corrupt"},Kl=e=>{if(typeof globalThis.atob=="function"){let t=globalThis.atob(e),n=new Uint8Array(t.length);for(let r=0;r<t.length;r++)n[r]=t.charCodeAt(r);return n}return Uint8Array.from(Buffer.from(e,"base64"))},Hl=e=>{if(typeof globalThis.btoa=="function"){let t="";for(let n=0;n<e.length;n++)t+=String.fromCharCode(e[n]);return globalThis.btoa(t)}return Buffer.from(e).toString("base64")},Ug=e=>{let t=new Uint8Array(e);if(typeof globalThis.crypto?.getRandomValues=="function")return globalThis.crypto.getRandomValues(t),t;throw new Error("bridge.token-store: WebCrypto.getRandomValues is unavailable; refusing to fall back to Math.random for AES-GCM IV")},Vl=e=>new TextEncoder().encode(JSON.stringify({domain:"recued.webclient.token.aad.v2",token_id:e.token_id,server_public_key:e.server_public_key})),Gl=e=>{if(!e||typeof e.token_id!="string"||typeof e.server_public_key!="string"||e.token_id.length===0||e.server_public_key.length===0)throw new Error("bridge.token-store: AAD context required (token_id + server_public_key)")},po=e=>{let t=e.randomBytes??Ug,n=e.now??Date.now;return{async wrap({token_id:r,bearer:o,aad:a}){if(!r||!o)throw new Error("bridge.token-store: token_id and bearer are required");if(Gl(a),a.token_id!==r)throw new Error("bridge.token-store: aad.token_id must equal the wrap token_id");let i=t(vt.iv_length_bytes);if(i.length!==vt.iv_length_bytes)throw new Error(`bridge.token-store: random IV length must be ${vt.iv_length_bytes} bytes`);let s=await e.resolveKey(),c=new TextEncoder().encode(o),d=await e.encrypt({key:s,iv:i,plaintext:c,additional_data:Vl(a)});return{token_id:r,ciphertext_b64:Hl(d),iv_b64:Hl(i),issued_at:n()}},async unwrap(r,o){if(!r||typeof r.ciphertext_b64!="string"||typeof r.iv_b64!="string")throw new Te("malformed token record");if(r.ciphertext_b64.length===0||r.iv_b64.length===0)throw new Te("empty ciphertext or iv");if(Gl(o),o.token_id!==r.token_id)throw new Te("aad.token_id does not match record.token_id");let a=Kl(r.iv_b64);if(a.length!==vt.iv_length_bytes)throw new Te("iv length unexpected");let i=Kl(r.ciphertext_b64),s=await e.resolveKey();try{let c=await e.decrypt({key:s,iv:a,ciphertext:i,additional_data:Vl(o)});return new TextDecoder().decode(c)}catch(c){throw c instanceof Te?c:new Te(c instanceof Error?c.message:"decrypt failed")}}}};var wn=50,On=50,xn=e=>e==="delivery_uncertain"||e==="mv3_lifecycle_killed",Ke=e=>e.status!=="timeout"&&e.status!=="cancelled"&&!xn(e.error?.code),Fg=new Set(vr.filter(e=>!xn(e))),wt=(e,t)=>(e==="error"||e==="rejected")&&typeof t=="string"&&Fg.has(t)?{error_code:t}:{},_o=(e={})=>{let t=e.now??Date.now,n=new Map,r=new Map,o=new Map,a=new Map,i=u=>{n.delete(u.command_id),r.get(u.idempotency_key)===u.command_id&&r.delete(u.idempotency_key)},s=u=>{let m=n.get(u);return m?t()>=m.expires_at?(i(m),null):m:null},c=u=>{let m=r.get(u);return m===void 0?null:s(m)},d=()=>{let u=t(),m=[...n.values()].filter(l=>l.expires_at>u),p=m.filter(l=>Ke(l.result));return p.sort((l,_)=>_.stored_at-l.stored_at||(l.command_id<_.command_id?1:l.command_id>_.command_id?-1:0)),{count:m.length,confirmed:{count:p.length,entries:p.slice(0,On).map(l=>({command_id:l.command_id,stored_at:l.stored_at,status:l.result.status,...wt(l.result.status,l.result.error?.code)}))}}},f=()=>({count:o.size,entries:[...o.keys()].sort().slice(0,wn).map(u=>{let m=o.get(u);return{command_id:m.command_id,started_at:m.started_at}})});return{async claim(u,m){if(typeof u!="string"||!u||typeof m!="string"||!m)throw new Error("bridge.receipts: command identity is required");let p=s(u)??c(m);if(p)return{kind:"completed",entry:p};let l=o.get(u)??a.get(m);if(l)return{kind:"in_flight",entry:l};let _={command_id:u,idempotency_key:m,started_at:t()};return o.set(u,_),a.set(m,_),{kind:"claimed",entry:_}},async store(u,m,p){let l=o.get(u)??a.get(m);if(l&&(l.command_id!==u||l.idempotency_key!==m))throw new Error("bridge.receipts: cannot finish another command's in-flight marker");let _=t(),y={command_id:u,idempotency_key:m,result:p,stored_at:_,expires_at:_+je},g=n.get(u);g&&i(g),n.set(u,y),r.set(m,u),l&&Ke(p)&&(o.delete(u),a.delete(m))},async lookup(u){return s(u)},async lookupByIdempotencyKey(u){return c(u)},async sweepExpired(u){let m=0;for(let p of n.values())u>=p.expires_at&&(i(p),m++);return m},async list(){return[...n.values()]},async inspectReceipts(){return d()},async inspectInFlight(){return f()},async inspectDiagnostics(){return{receipts:d(),in_flight:f()}},async clear(){n.clear(),r.clear()}}},mo=(e,t)=>t?{...t.result,idempotency_key_seen:!0}:{...e,idempotency_key_seen:!1};var jl=(e,t)=>{let n=()=>{try{Promise.resolve(t()).catch(()=>{})}catch{}};return{async claim(r,o){let a=await e.claim(r,o);return a.kind==="claimed"&&n(),a},async store(r,o,a){await e.store(r,o,a),n()},lookup:r=>e.lookup(r),lookupByIdempotencyKey:r=>e.lookupByIdempotencyKey(r),async sweepExpired(r){let o=await e.sweepExpired(r);return o>0&&n(),o},list:()=>e.list(),inspectReceipts:()=>e.inspectReceipts(),inspectInFlight:()=>e.inspectInFlight(),inspectDiagnostics:()=>e.inspectDiagnostics(),async clear(){await e.clear(),n()}}};var Wl=(e,t=50)=>{let n,r=!1,o=!1,a=!1,i=()=>{a||r||n!==void 0||!o||(n=setTimeout(()=>{n=void 0,!a&&(o=!1,r=!0,Promise.resolve().then(e).catch(()=>{}).then(()=>{r=!1,i()}))},t))};return{request(){a||(o=!0,i())},stop(){a=!0,o=!1,n!==void 0&&(clearTimeout(n),n=void 0)}}};var go=(e={})=>{let t=e.max_depth??wr,n=[],r=null,o=!1;return{enqueue(a){return n.length>=t?{ok:!1,reason:"queue_full",depth:n.length,max:t}:(n.push(a),{ok:!0,depth:n.length})},dequeue(){if(o||r!==null)return null;let a=n.shift();return a?(r=a.command_id,a):null},complete(a){r===a&&(r=null)},cancel(a){if(r===a)return"running";let i=n.findIndex(s=>s.command_id===a);return i>=0?(n.splice(i,1),"dropped"):"unknown"},state(){return{current_command_id:r,pending:[...n],paused:o}},setPaused(a){o=a},clear(){n=[]},depth(){return n.length},maxDepth(){return t}}};var Yl=e=>e.action,Xl=e=>typeof e!="number"||!Number.isFinite(e)||e<=0?kr:e>tn?tn:e,Ot=(e,t)=>Math.max(0,t()-e),Kg=async(e,t,n,r,o)=>{let a=null,i=new Promise(d=>{a=setTimeout(()=>d({timed_out:!0}),n)}),s,c;try{c=e.execute(t).then(d=>({outcome:d,duration_ms:Ot(r,o)}),d=>({error:d})),xt.running+=1,c.then(()=>{xt.running-=1,xt.last_ended_at=o()}),s=await Promise.race([c,i])}finally{a!==null&&clearTimeout(a)}if("timed_out"in s)return t.cancel.signalled=!0,{outcome:{status:"timeout",error:{code:"unknown",message:`bridge: command timed out after ${n}ms`}},duration_ms:Ot(r,o),late_completion:c};if("error"in s)throw s.error;return{outcome:s.outcome,duration_ms:s.duration_ms}},$l=(e,t)=>t.signalled&&e.status==="ok"?{...e,status:"cancelled",outputs:void 0}:e,Hg=async(e,t)=>e.get(t.ingredient.publisher_id,t.ingredient.slug,t.ingredient.version),ql=(e,t,n,r,o,a)=>({command_id:e.command_id,status:"rejected",error:{code:r,message:o,detail:a},duration_ms:n,bridge_version:t,idempotency_key_seen:!1}),xt={running:0,last_ended_at:0},fo=async(e,t,n={signalled:!1})=>{let{command_id:r,idempotency_key:o}=e,{idempotency:a,bridge_version:i,now:s}=t,c=s(),d=await a.claim(r,o);if(d.kind==="completed")return{command_id:e.command_id,result:$l({...mo(d.entry.result,d.entry),command_id:e.command_id},n),replayed_from_cache:!0};if(d.kind==="in_flight")return{command_id:e.command_id,result:{command_id:e.command_id,status:"error",error:{code:"delivery_uncertain",message:"An earlier attempt has no confirmed completion. Check the page before retrying.",detail:JSON.stringify({original_command_id:d.entry.command_id,started_at:d.entry.started_at})},duration_ms:Ot(c,s),bridge_version:i,idempotency_key_seen:!0},replayed_from_cache:!1};let f=Yl(e),u=await Hg(t.grants,e);if(!u){let _=ql(e,i,Ot(c,s),"authority_invalid_grant_scope","bridge: no per-ingredient grant for this command",`(publisher_id, slug, version) = (${e.ingredient.publisher_id}, ${e.ingredient.slug}, ${e.ingredient.version})`);return await a.store(r,o,_),{command_id:e.command_id,result:_,replayed_from_cache:!1}}if(!nn(e.target_domain_pattern,e.ingredient,u)){let _=ql(e,i,Ot(c,s),"authority_invalid_grant_scope","bridge: target_domain_pattern outside ingredient allowlist or user grant",e.target_domain_pattern);return await a.store(r,o,_),{command_id:e.command_id,result:_,replayed_from_cache:!1}}let m=Xl(e.timeout_ms),p=await Kg(t.executor,{command:e,action:f,cancel:n},m,c,s),l={command_id:r,status:p.outcome.status,outputs:p.outcome.status==="ok"?p.outcome.outputs:void 0,error:p.outcome.error,duration_ms:p.duration_ms,bridge_version:i,idempotency_key_seen:!1};return await a.store(r,o,l),p.late_completion&&p.late_completion.then(async _=>{if("error"in _)return;let y={command_id:r,status:_.outcome.status,outputs:_.outcome.status==="ok"?_.outcome.outputs:void 0,error:_.outcome.error,duration_ms:_.duration_ms,bridge_version:i,idempotency_key_seen:!1};Ke(y)&&await a.store(r,o,y)}).catch(()=>{}),{command_id:r,result:$l(l,n),replayed_from_cache:!1}};var Vg=new Set([4003,4401]),Gg=1e3,jg=3e4,Wg=2,$g=e=>new Promise(t=>setTimeout(t,e)),ho=e=>{let t=e.initial_backoff_ms??Gg,n=e.max_backoff_ms??jg,r=e.backoff_multiplier??Wg,o=e.sleep??$g,a=e.refused_close_codes??Vg,i=!1,s=!1,c=null,d=0,f=t,u=null,m=!1,p=async()=>{await o(f),f=Math.min(f*r,n)},l=y=>{c=y,m=!1,y.onMessage(g=>{m=!0,e.handlers?.onMessage?.(g)}),y.onError(()=>{}),y.onClose(g=>{if(c=null,e.handlers?.onDisconnected?.(g.reason||`code=${g.code}`),!i){if(a.has(g.code)){s=!0,i=!0,u=null,e.handlers?.onSignInRefused?.({code:g.code,reason:g.reason});return}m?(f=t,u=_()):u=p().then(()=>_())}})},_=async()=>{for(;!i;){d++;try{let y=await e.resolveBearer(),g=await e.factory.open({url:e.url,auth_bearer:y});l(g),d=0,await e.handlers?.onConnected?.(g);return}catch{await p()}}};return{async start(){s||u||(i=!1,f=t,d=0,u=_())},async stop(){if(i=!0,c)try{c.close(1e3,"bridge: shutdown")}catch{}c=null,u=null},isConnected(){return c!==null},currentBackoff(){return f},attempts(){return d},refused(){return s},send(y){if(!c)throw new Error("bridge.ws-client: send called while disconnected");c.send(y)}}};var Pn="recued.bridge.keepalive";var yo=async e=>{let t=!1;e.ws.isConnected()||(await e.ws.start(),t=!0);let n=await e.idempotency.sweepExpired(e.now());return{ws_connected:e.ws.isConnected(),reconnected:t,expired_swept:n}},Eo=(e,t,n)=>{e.create(Pn,{periodInMinutes:.5}),e.onAlarm.addListener(r=>{r.name===Pn&&(t.getPlatformInfo().catch(()=>{}),n().catch(()=>{}))})},bo=e=>{e.clear(Pn)};var So="recued-approval-";var qg="An approval is waiting",Yg="Waiting for your approval. Click to open it in Recued.",Ro=/^ask-[A-Za-z0-9-]{1,100}$/u,zl=e=>`${So}${e}`,Ql=e=>{if(!e.startsWith(So))return;let t=e.slice(So.length);return Ro.test(t)?t:void 0},Jl=e=>{let t,n=()=>(t??=e.readNotifySwitch().catch(()=>(t=void 0,!1)),t),r=Promise.resolve(),o=i=>(r=r.then(i).catch(()=>{}),r),a=async()=>{let i=await e.storage.get("approval_notices_shown");return Array.isArray(i)?i.filter(s=>typeof s=="string"):[]};return{forgetSwitch(){t=void 0},asked(i){return i.reminder===!0||!Ro.test(i.ask_id)?Promise.resolve():o(async()=>{if(!await n())return;let s=await a();s.includes(i.ask_id)||(await e.notifications.create(zl(i.ask_id),{type:"basic",title:i.title?.trim()||qg,message:Yg,iconUrl:e.icon_url,isClickable:!0}),await e.storage.set("approval_notices_shown",[...s,i.ask_id].slice(-200)))})},closed(i){return Ro.test(i)?o(async()=>{await e.notifications.clear(zl(i)).catch(()=>!1);let s=await a();s.includes(i)&&await e.storage.set("approval_notices_shown",s.filter(c=>c!==i))}):Promise.resolve()}}};var Zl=(e,t)=>{let n=t.expanded_body?e.body:Xg(e.title);return{chrome_options:{type:"basic",title:e.title,message:n,iconUrl:e.icon_url??t.default_icon_url,isClickable:!0},click_action:e.click_action??null}},Xg=e=>`${e} \u2014 open Recued for detail`,ed=(e,t)=>{if(!e)return{kind:"noop"};if(e.kind==="open_url")return{kind:"open_url",url:e.url};if(e.kind==="open_webclient"){if(!t.server_url)return{kind:"noop"};let n=Jg(t.server_url);return n?{kind:"open_webclient",url:n+zg(e.path)}:{kind:"noop"}}return{kind:"rpc_callback",rpc:{name:e.rpc,args:e.args}}},zg=e=>e.startsWith("/")?e:`/${e}`,Qg=e=>{if(/^recued-reminder-[a-f0-9]{64}$/u.test(e))return{kind:"open_webclient",path:"/#yours/occurrences"};let t=Ql(e);return t!==void 0?{kind:"open_webclient",path:`/#approvals/${encodeURIComponent(t)}`}:null},Jg=e=>{try{let t=new URL(e),n=t.protocol==="wss:"||t.protocol==="https:"?"https":"http",r=t.host;return`${n}://${r}`}catch{return null}},Ao=(e,t,n,r)=>{let o=new Map;return e.onClicked.addListener(a=>{let i=o.get(a)??Qg(a),s=ed(i,r);n(s,a)}),e.onClosed.addListener(a=>{o.delete(a)}),{async dispatch(a){let{chrome_options:i,click_action:s}=Zl(a,t);o.set(a.notification_id,s);try{await e.create(a.notification_id,i)}catch(c){throw o.delete(a.notification_id),c}}}};var To=async e=>{let t=await e.local.inspect(),n=e.queue.state(),r=null,o=null,a=null,i=e.idempotency;try{e.idempotencyForPair&&(i=t.server_url&&t.server_public_key&&t.webclient_token?.token_id?e.idempotencyForPair({server_public_key:t.server_public_key,token_id:t.webclient_token.token_id}):null)}catch{i=null}if(i)try{let d=await i.inspectDiagnostics();d.receipts&&(r=d.receipts.count,a=d.receipts.confirmed),o=d.in_flight}catch{try{o=await i.inspectInFlight()}catch{}}let s=await e.grants.list(),c=null;for(let d of s)(c===null||d.granted_at>c)&&(c=d.granted_at);return{local:t,queue:{current_command_id:n.current_command_id,pending_depth:n.pending.length,paused:n.paused},idempotency:{entry_count:r,in_flight:o,recent_confirmed:a},grants:{count:s.length,most_recent_at:c},inspected_at:e.now()}};var Zg=e=>{let t=e.split(".");if(t.length!==4)return null;let n=t.map(r=>/^\d{1,3}$/.test(r)?Number(r):Number.NaN);return n.some(r=>Number.isNaN(r)||r<0||r>255)?null:n},ef=e=>{let t=e.toLowerCase();if(t.startsWith("[")&&t.endsWith("]")){let r=t.slice(1,-1);return r==="::1"||r.startsWith("fc")||r.startsWith("fd")||/^fe[89ab]/.test(r)}let n=Zg(t);if(n===null){let r=t.endsWith(".")?t.slice(0,-1):t;return r==="localhost"||r.endsWith(".localhost")||r.endsWith(".local")}return n[0]===127||n[0]===10||n[0]===192&&n[1]===168||n[0]===172&&n[1]>=16&&n[1]<=31||n[0]===169&&n[1]===254||n[0]===100&&n[1]>=64&&n[1]<=127},Nn=e=>{let t;try{t=new URL(e)}catch{return!1}return t.protocol!=="http:"&&t.protocol!=="ws:"?!1:!ef(t.hostname.toLowerCase())};var td=new Set(["pair_completion_invalid_server_url","pair_completion_already_paired"]),tf=e=>{let t=e.trim();if(t.length===0)return null;let n=t.toLowerCase(),r;if(n.startsWith("https://"))r=`wss://${t.slice(8)}`;else if(n.startsWith("http://"))r=`ws://${t.slice(7)}`;else if(n.startsWith("wss://")||n.startsWith("ws://"))r=t;else return null;if(Nn(r))return null;let o=r.indexOf("://")+3,a=r.slice(o);if(a.length===0)return null;let i=a.endsWith("/")?a.slice(0,-1):a;if(i.length===0)return null;let s=i.indexOf("/");if(s===0)return null;let c=r.slice(0,o);if(s<0)return`${c}${i}/ws`;let d=i.slice(s);return d==="/ws"||d.endsWith("/ws")?`${c}${i}`:`${c}${i}/ws`},nf=e=>{if(!e||typeof e!="object")return null;let t=e,n=t.identity?.server_public_key;if(typeof n!="string"||n.length===0)return null;let r=typeof t.identity?.current_handle=="string"?t.identity.current_handle:"",o=t.network?.cert_fingerprint,a=t.network?.cert_expires_at;return{server_public_key:n,cert_fingerprint:typeof o=="string"&&o.length>0?o:void 0,cert_expires_at:typeof a=="number"&&Number.isFinite(a)?a:void 0,current_handle:r}},rf=(e,t)=>typeof e!="string"||e.length===0||typeof t!="number"||!Number.isFinite(t)?null:{current_fingerprint:e,current_valid_until:t},of=()=>{let e=globalThis.crypto;return e&&typeof e.randomUUID=="function"?e.randomUUID():`bridge-${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`},nd=async e=>{let t;try{t=await e.localStore.get("webclient_token")}catch(m){return{ok:!1,error:"pair_completion_persist_failed",detail:`local-store read: ${m instanceof Error?m.message:String(m)}`}}if(t!==null){if(e.token_id!==void 0&&t.token_id===e.token_id){let m;try{m=await e.localStore.get("server_url")}catch(p){return{ok:!1,error:"pair_completion_persist_failed",detail:`local-store read: ${p instanceof Error?p.message:String(p)}`}}if(m!==null)return{ok:!0,server_url:m,token_id:e.token_id}}return{ok:!1,error:"pair_completion_already_paired",detail:"webclient_token already populated \u2014 disconnect from Settings before pairing again"}}let n=tf(e.serverUrl);if(n===null)return{ok:!1,error:"pair_completion_invalid_server_url",detail:"a server address must start with http://, https://, ws://, or wss://"};let r;if(e.passport!==void 0)r={passport:e.passport};else{let m=e.token_id?`${e.token_id}.${e.bearer}`:e.bearer;try{r=await e.invokePassportFetch({server_url:n,bearer:m})}catch(p){return{ok:!1,error:"pair_completion_passport_failed",detail:p instanceof Error?p.message:String(p)}}}let o=nf(r.passport);if(!o)return{ok:!1,error:"pair_completion_server_response_invalid",detail:"passport projection missing identity.server_public_key"};let a=e.mintTokenId??of,i=e.token_id??a(),s={token_id:i,server_public_key:o.server_public_key},c;try{c=await e.tokenStore.wrap({token_id:i,bearer:e.bearer,aad:s})}catch(m){return{ok:!1,error:"pair_completion_persist_failed",detail:`token-store wrap: ${m instanceof Error?m.message:String(m)}`}}let f={paired_at:e.now?e.now():Date.now(),server_passport_fingerprint:o.server_public_key,server_handle_at_pair:o.current_handle,...e.instanceId!==void 0&&e.instanceId.length>0?{instance_id:e.instanceId}:{}},u=rf(o.cert_fingerprint,o.cert_expires_at);try{await e.localStore.set("pair_metadata",f),await e.localStore.set("cert_pin_state",u),await e.localStore.set("server_url",n),await e.localStore.set("server_public_key",o.server_public_key),await e.localStore.set("webclient_token",c)}catch(m){return{ok:!1,error:"pair_completion_persist_failed",detail:`local-store write: ${m instanceof Error?m.message:String(m)}`}}return{ok:!0,server_url:n,token_id:i}};var rd=Object.freeze({t:3,m:65536,p:4});function sf(e){return e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name==="Uint8Array"}function Pt(e,t,n=""){let r=sf(e),o=e?.length,a=t!==void 0;if(!r||a&&o!==t){let i=n&&`"${n}" `,s=a?` of length ${t}`:"",c=r?`length=${o}`:`type=${typeof e}`;throw new Error(i+"expected Uint8Array"+s+", got "+c)}return e}function Co(e,t=!0){if(e.destroyed)throw new Error("Hash instance has been destroyed");if(t&&e.finished)throw new Error("Hash#digest() has already been called")}function od(e,t){Pt(e,void 0,"digestInto() output");let n=t.outputLen;if(e.length<n)throw new Error('"digestInto() output" expected to be of length >='+n)}function Nt(...e){for(let t=0;t<e.length;t++)e[t].fill(0)}function Dn(e){return new DataView(e.buffer,e.byteOffset,e.byteLength)}function Ce(e,t){return e<<32-t|e>>>t}function id(e,t={}){let n=(o,a)=>e(a).update(o).digest(),r=e(void 0);return n.outputLen=r.outputLen,n.blockLen=r.blockLen,n.create=o=>e(o),Object.assign(n,t),Object.freeze(n)}var sd=e=>({oid:Uint8Array.from([6,9,96,134,72,1,101,3,4,2,e])});function ad(e,t,n){return e&t^~e&n}function cd(e,t,n){return e&t^e&n^t&n}var Ln=class{blockLen;outputLen;padOffset;isLE;buffer;view;finished=!1;length=0;pos=0;destroyed=!1;constructor(t,n,r,o){this.blockLen=t,this.outputLen=n,this.padOffset=r,this.isLE=o,this.buffer=new Uint8Array(t),this.view=Dn(this.buffer)}update(t){Co(this),Pt(t);let{view:n,buffer:r,blockLen:o}=this,a=t.length;for(let i=0;i<a;){let s=Math.min(o-this.pos,a-i);if(s===o){let c=Dn(t);for(;o<=a-i;i+=o)this.process(c,i);continue}r.set(t.subarray(i,i+s),this.pos),this.pos+=s,i+=s,this.pos===o&&(this.process(n,0),this.pos=0)}return this.length+=t.length,this.roundClean(),this}digestInto(t){Co(this),od(t,this),this.finished=!0;let{buffer:n,view:r,blockLen:o,isLE:a}=this,{pos:i}=this;n[i++]=128,Nt(this.buffer.subarray(i)),this.padOffset>o-i&&(this.process(r,0),i=0);for(let u=i;u<o;u++)n[u]=0;r.setBigUint64(o-8,BigInt(this.length*8),a),this.process(r,0);let s=Dn(t),c=this.outputLen;if(c%4)throw new Error("_sha2: outputLen must be aligned to 32bit");let d=c/4,f=this.get();if(d>f.length)throw new Error("_sha2: outputLen bigger than state");for(let u=0;u<d;u++)s.setUint32(4*u,f[u],a)}digest(){let{buffer:t,outputLen:n}=this;this.digestInto(t);let r=t.slice(0,n);return this.destroy(),r}_cloneInto(t){t||=new this.constructor,t.set(...this.get());let{blockLen:n,buffer:r,length:o,finished:a,destroyed:i,pos:s}=this;return t.destroyed=i,t.finished=a,t.length=o,t.pos=s,o%n&&t.buffer.set(r),t}clone(){return this._cloneInto()}},Pe=Uint32Array.from([1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225]);var af=Uint32Array.from([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),He=new Uint32Array(64),Io=class extends Ln{constructor(t){super(64,t,8,!1)}get(){let{A:t,B:n,C:r,D:o,E:a,F:i,G:s,H:c}=this;return[t,n,r,o,a,i,s,c]}set(t,n,r,o,a,i,s,c){this.A=t|0,this.B=n|0,this.C=r|0,this.D=o|0,this.E=a|0,this.F=i|0,this.G=s|0,this.H=c|0}process(t,n){for(let u=0;u<16;u++,n+=4)He[u]=t.getUint32(n,!1);for(let u=16;u<64;u++){let m=He[u-15],p=He[u-2],l=Ce(m,7)^Ce(m,18)^m>>>3,_=Ce(p,17)^Ce(p,19)^p>>>10;He[u]=_+He[u-7]+l+He[u-16]|0}let{A:r,B:o,C:a,D:i,E:s,F:c,G:d,H:f}=this;for(let u=0;u<64;u++){let m=Ce(s,6)^Ce(s,11)^Ce(s,25),p=f+m+ad(s,c,d)+af[u]+He[u]|0,_=(Ce(r,2)^Ce(r,13)^Ce(r,22))+cd(r,o,a)|0;f=d,d=c,c=s,s=i+p|0,i=a,a=o,o=r,r=p+_|0}r=r+this.A|0,o=o+this.B|0,a=a+this.C|0,i=i+this.D|0,s=s+this.E|0,c=c+this.F|0,d=d+this.G|0,f=f+this.H|0,this.set(r,o,a,i,s,c,d,f)}roundClean(){Nt(He)}destroy(){this.set(0,0,0,0,0,0,0,0),Nt(this.buffer)}},ko=class extends Io{A=Pe[0]|0;B=Pe[1]|0;C=Pe[2]|0;D=Pe[3]|0;E=Pe[4]|0;F=Pe[5]|0;G=Pe[6]|0;H=Pe[7]|0;constructor(){super(32)}};var ld=id(()=>new ko,sd(1));function Mn(e){return e instanceof Uint8Array||ArrayBuffer.isView(e)&&e.constructor.name==="Uint8Array"}function dd(e,t){return Array.isArray(t)?t.length===0?!0:e?t.every(n=>typeof n=="string"):t.every(n=>Number.isSafeInteger(n)):!1}function cf(e){if(typeof e!="function")throw new Error("function expected");return!0}function Bn(e,t){if(typeof t!="string")throw new Error(`${e}: string expected`);return!0}function it(e){if(!Number.isSafeInteger(e))throw new Error(`invalid integer: ${e}`)}function Un(e){if(!Array.isArray(e))throw new Error("array expected")}function Fn(e,t){if(!dd(!0,t))throw new Error(`${e}: array of strings expected`)}function ud(e,t){if(!dd(!1,t))throw new Error(`${e}: array of numbers expected`)}function lf(...e){let t=a=>a,n=(a,i)=>s=>a(i(s)),r=e.map(a=>a.encode).reduceRight(n,t),o=e.map(a=>a.decode).reduce(n,t);return{encode:r,decode:o}}function df(e){let t=typeof e=="string"?e.split(""):e,n=t.length;Fn("alphabet",t);let r=new Map(t.map((o,a)=>[o,a]));return{encode:o=>(Un(o),o.map(a=>{if(!Number.isSafeInteger(a)||a<0||a>=n)throw new Error(`alphabet.encode: digit index outside alphabet "${a}". Allowed: ${e}`);return t[a]})),decode:o=>(Un(o),o.map(a=>{Bn("alphabet.decode",a);let i=r.get(a);if(i===void 0)throw new Error(`Unknown letter: "${a}". Allowed: ${e}`);return i}))}}function uf(e=""){return Bn("join",e),{encode:t=>(Fn("join.decode",t),t.join(e)),decode:t=>(Bn("join.decode",t),t.split(e))}}function pf(e,t="="){return it(e),Bn("padding",t),{encode(n){for(Fn("padding.encode",n);n.length*e%8;)n.push(t);return n},decode(n){Fn("padding.decode",n);let r=n.length;if(r*e%8)throw new Error("padding: invalid, string should have whole number of bytes");for(;r>0&&n[r-1]===t;r--)if((r-1)*e%8===0)throw new Error("padding: invalid, string has too much padding");return n.slice(0,r)}}}function wo(e,t,n){if(t<2)throw new Error(`convertRadix: invalid from=${t}, base cannot be less than 2`);if(n<2)throw new Error(`convertRadix: invalid to=${n}, base cannot be less than 2`);if(Un(e),!e.length)return[];let r=0,o=[],a=Array.from(e,s=>{if(it(s),s<0||s>=t)throw new Error(`invalid integer: ${s}`);return s}),i=a.length;for(;;){let s=0,c=!0;for(let d=r;d<i;d++){let f=a[d],u=t*s,m=u+f;if(!Number.isSafeInteger(m)||u/t!==s||m-f!==u)throw new Error("convertRadix: carry overflow");let p=m/n;s=m%n;let l=Math.floor(p);if(a[d]=l,!Number.isSafeInteger(l)||l*n+s!==m)throw new Error("convertRadix: carry overflow");if(c)l?c=!1:r=d;else continue}if(o.push(s),c)break}for(let s=0;s<e.length-1&&e[s]===0;s++)o.push(0);return o.reverse()}var pd=(e,t)=>t===0?e:pd(t,e%t),Kn=(e,t)=>e+(t-pd(e,t)),vo=(()=>{let e=[];for(let t=0;t<40;t++)e.push(2**t);return e})();function Oo(e,t,n,r){if(Un(e),t<=0||t>32)throw new Error(`convertRadix2: wrong from=${t}`);if(n<=0||n>32)throw new Error(`convertRadix2: wrong to=${n}`);if(Kn(t,n)>32)throw new Error(`convertRadix2: carry overflow from=${t} to=${n} carryBits=${Kn(t,n)}`);let o=0,a=0,i=vo[t],s=vo[n]-1,c=[];for(let d of e){if(it(d),d>=i)throw new Error(`convertRadix2: invalid data word=${d} from=${t}`);if(o=o<<t|d,a+t>32)throw new Error(`convertRadix2: carry overflow pos=${a} from=${t}`);for(a+=t;a>=n;a-=n)c.push((o>>a-n&s)>>>0);let f=vo[a];if(f===void 0)throw new Error("invalid carry");o&=f-1}if(o=o<<n-a&s,!r&&a>=t)throw new Error("Excess padding");if(!r&&o>0)throw new Error(`Non-zero padding: ${o}`);return r&&a>0&&c.push(o>>>0),c}function _f(e){it(e);let t=2**8;return{encode:n=>{if(!Mn(n))throw new Error("radix.encode input should be Uint8Array");return wo(Array.from(n),t,e)},decode:n=>(ud("radix.decode",n),Uint8Array.from(wo(n,e,t)))}}function mf(e,t=!1){if(it(e),e<=0||e>32)throw new Error("radix2: bits should be in (0..32]");if(Kn(8,e)>32||Kn(e,8)>32)throw new Error("radix2: carry overflow");return{encode:n=>{if(!Mn(n))throw new Error("radix2.encode input should be Uint8Array");return Oo(Array.from(n),8,e,!t)},decode:n=>(ud("radix2.decode",n),Uint8Array.from(Oo(n,e,8,t)))}}function gf(e,t){return it(e),cf(t),{encode(n){if(!Mn(n))throw new Error("checksum.encode: input should be Uint8Array");let r=t(n).slice(0,e),o=new Uint8Array(n.length+e);return o.set(n),o.set(r,n.length),o},decode(n){if(!Mn(n))throw new Error("checksum.decode: input should be Uint8Array");let r=n.slice(0,-e),o=n.slice(-e),a=t(r).slice(0,e);for(let i=0;i<e;i++)if(a[i]!==o[i])throw new Error("Invalid checksum");return r}}}var Dt={alphabet:df,chain:lf,checksum:gf,convertRadix:wo,convertRadix2:Oo,radix:_f,radix2:mf,join:uf,padding:pf};function ff(e){if(typeof e!="string")throw new TypeError("invalid mnemonic type: "+typeof e);return e.normalize("NFKD")}function hf(e){let t=ff(e),n=t.split(" ");if(![12,15,18,21,24].includes(n.length))throw new Error("Invalid mnemonic");return{nfkd:t,words:n}}function yf(e){if(Pt(e),![16,20,24,28,32].includes(e.length))throw new Error("invalid entropy length")}var Ef=e=>{let t=8-e.length/4;return new Uint8Array([ld(e)[0]>>t<<t])};function bf(e){if(!Array.isArray(e)||e.length!==2048||typeof e[0]!="string")throw new Error("Wordlist: expected array of 2048 strings");return e.forEach(t=>{if(typeof t!="string")throw new Error("wordlist: non-string element: "+t)}),Dt.chain(Dt.checksum(1,Ef),Dt.radix2(11,!0),Dt.alphabet(e))}function _d(e,t){let{words:n}=hf(e),r=bf(t).decode(n);return yf(r),r}function md(e,t){try{_d(e,t)}catch{return!1}return!0}var gd=`abandon
ability
able
about
above
absent
absorb
abstract
absurd
abuse
access
accident
account
accuse
achieve
acid
acoustic
acquire
across
act
action
actor
actress
actual
adapt
add
addict
address
adjust
admit
adult
advance
advice
aerobic
affair
afford
afraid
again
age
agent
agree
ahead
aim
air
airport
aisle
alarm
album
alcohol
alert
alien
all
alley
allow
almost
alone
alpha
already
also
alter
always
amateur
amazing
among
amount
amused
analyst
anchor
ancient
anger
angle
angry
animal
ankle
announce
annual
another
answer
antenna
antique
anxiety
any
apart
apology
appear
apple
approve
april
arch
arctic
area
arena
argue
arm
armed
armor
army
around
arrange
arrest
arrive
arrow
art
artefact
artist
artwork
ask
aspect
assault
asset
assist
assume
asthma
athlete
atom
attack
attend
attitude
attract
auction
audit
august
aunt
author
auto
autumn
average
avocado
avoid
awake
aware
away
awesome
awful
awkward
axis
baby
bachelor
bacon
badge
bag
balance
balcony
ball
bamboo
banana
banner
bar
barely
bargain
barrel
base
basic
basket
battle
beach
bean
beauty
because
become
beef
before
begin
behave
behind
believe
below
belt
bench
benefit
best
betray
better
between
beyond
bicycle
bid
bike
bind
biology
bird
birth
bitter
black
blade
blame
blanket
blast
bleak
bless
blind
blood
blossom
blouse
blue
blur
blush
board
boat
body
boil
bomb
bone
bonus
book
boost
border
boring
borrow
boss
bottom
bounce
box
boy
bracket
brain
brand
brass
brave
bread
breeze
brick
bridge
brief
bright
bring
brisk
broccoli
broken
bronze
broom
brother
brown
brush
bubble
buddy
budget
buffalo
build
bulb
bulk
bullet
bundle
bunker
burden
burger
burst
bus
business
busy
butter
buyer
buzz
cabbage
cabin
cable
cactus
cage
cake
call
calm
camera
camp
can
canal
cancel
candy
cannon
canoe
canvas
canyon
capable
capital
captain
car
carbon
card
cargo
carpet
carry
cart
case
cash
casino
castle
casual
cat
catalog
catch
category
cattle
caught
cause
caution
cave
ceiling
celery
cement
census
century
cereal
certain
chair
chalk
champion
change
chaos
chapter
charge
chase
chat
cheap
check
cheese
chef
cherry
chest
chicken
chief
child
chimney
choice
choose
chronic
chuckle
chunk
churn
cigar
cinnamon
circle
citizen
city
civil
claim
clap
clarify
claw
clay
clean
clerk
clever
click
client
cliff
climb
clinic
clip
clock
clog
close
cloth
cloud
clown
club
clump
cluster
clutch
coach
coast
coconut
code
coffee
coil
coin
collect
color
column
combine
come
comfort
comic
common
company
concert
conduct
confirm
congress
connect
consider
control
convince
cook
cool
copper
copy
coral
core
corn
correct
cost
cotton
couch
country
couple
course
cousin
cover
coyote
crack
cradle
craft
cram
crane
crash
crater
crawl
crazy
cream
credit
creek
crew
cricket
crime
crisp
critic
crop
cross
crouch
crowd
crucial
cruel
cruise
crumble
crunch
crush
cry
crystal
cube
culture
cup
cupboard
curious
current
curtain
curve
cushion
custom
cute
cycle
dad
damage
damp
dance
danger
daring
dash
daughter
dawn
day
deal
debate
debris
decade
december
decide
decline
decorate
decrease
deer
defense
define
defy
degree
delay
deliver
demand
demise
denial
dentist
deny
depart
depend
deposit
depth
deputy
derive
describe
desert
design
desk
despair
destroy
detail
detect
develop
device
devote
diagram
dial
diamond
diary
dice
diesel
diet
differ
digital
dignity
dilemma
dinner
dinosaur
direct
dirt
disagree
discover
disease
dish
dismiss
disorder
display
distance
divert
divide
divorce
dizzy
doctor
document
dog
doll
dolphin
domain
donate
donkey
donor
door
dose
double
dove
draft
dragon
drama
drastic
draw
dream
dress
drift
drill
drink
drip
drive
drop
drum
dry
duck
dumb
dune
during
dust
dutch
duty
dwarf
dynamic
eager
eagle
early
earn
earth
easily
east
easy
echo
ecology
economy
edge
edit
educate
effort
egg
eight
either
elbow
elder
electric
elegant
element
elephant
elevator
elite
else
embark
embody
embrace
emerge
emotion
employ
empower
empty
enable
enact
end
endless
endorse
enemy
energy
enforce
engage
engine
enhance
enjoy
enlist
enough
enrich
enroll
ensure
enter
entire
entry
envelope
episode
equal
equip
era
erase
erode
erosion
error
erupt
escape
essay
essence
estate
eternal
ethics
evidence
evil
evoke
evolve
exact
example
excess
exchange
excite
exclude
excuse
execute
exercise
exhaust
exhibit
exile
exist
exit
exotic
expand
expect
expire
explain
expose
express
extend
extra
eye
eyebrow
fabric
face
faculty
fade
faint
faith
fall
false
fame
family
famous
fan
fancy
fantasy
farm
fashion
fat
fatal
father
fatigue
fault
favorite
feature
february
federal
fee
feed
feel
female
fence
festival
fetch
fever
few
fiber
fiction
field
figure
file
film
filter
final
find
fine
finger
finish
fire
firm
first
fiscal
fish
fit
fitness
fix
flag
flame
flash
flat
flavor
flee
flight
flip
float
flock
floor
flower
fluid
flush
fly
foam
focus
fog
foil
fold
follow
food
foot
force
forest
forget
fork
fortune
forum
forward
fossil
foster
found
fox
fragile
frame
frequent
fresh
friend
fringe
frog
front
frost
frown
frozen
fruit
fuel
fun
funny
furnace
fury
future
gadget
gain
galaxy
gallery
game
gap
garage
garbage
garden
garlic
garment
gas
gasp
gate
gather
gauge
gaze
general
genius
genre
gentle
genuine
gesture
ghost
giant
gift
giggle
ginger
giraffe
girl
give
glad
glance
glare
glass
glide
glimpse
globe
gloom
glory
glove
glow
glue
goat
goddess
gold
good
goose
gorilla
gospel
gossip
govern
gown
grab
grace
grain
grant
grape
grass
gravity
great
green
grid
grief
grit
grocery
group
grow
grunt
guard
guess
guide
guilt
guitar
gun
gym
habit
hair
half
hammer
hamster
hand
happy
harbor
hard
harsh
harvest
hat
have
hawk
hazard
head
health
heart
heavy
hedgehog
height
hello
helmet
help
hen
hero
hidden
high
hill
hint
hip
hire
history
hobby
hockey
hold
hole
holiday
hollow
home
honey
hood
hope
horn
horror
horse
hospital
host
hotel
hour
hover
hub
huge
human
humble
humor
hundred
hungry
hunt
hurdle
hurry
hurt
husband
hybrid
ice
icon
idea
identify
idle
ignore
ill
illegal
illness
image
imitate
immense
immune
impact
impose
improve
impulse
inch
include
income
increase
index
indicate
indoor
industry
infant
inflict
inform
inhale
inherit
initial
inject
injury
inmate
inner
innocent
input
inquiry
insane
insect
inside
inspire
install
intact
interest
into
invest
invite
involve
iron
island
isolate
issue
item
ivory
jacket
jaguar
jar
jazz
jealous
jeans
jelly
jewel
job
join
joke
journey
joy
judge
juice
jump
jungle
junior
junk
just
kangaroo
keen
keep
ketchup
key
kick
kid
kidney
kind
kingdom
kiss
kit
kitchen
kite
kitten
kiwi
knee
knife
knock
know
lab
label
labor
ladder
lady
lake
lamp
language
laptop
large
later
latin
laugh
laundry
lava
law
lawn
lawsuit
layer
lazy
leader
leaf
learn
leave
lecture
left
leg
legal
legend
leisure
lemon
lend
length
lens
leopard
lesson
letter
level
liar
liberty
library
license
life
lift
light
like
limb
limit
link
lion
liquid
list
little
live
lizard
load
loan
lobster
local
lock
logic
lonely
long
loop
lottery
loud
lounge
love
loyal
lucky
luggage
lumber
lunar
lunch
luxury
lyrics
machine
mad
magic
magnet
maid
mail
main
major
make
mammal
man
manage
mandate
mango
mansion
manual
maple
marble
march
margin
marine
market
marriage
mask
mass
master
match
material
math
matrix
matter
maximum
maze
meadow
mean
measure
meat
mechanic
medal
media
melody
melt
member
memory
mention
menu
mercy
merge
merit
merry
mesh
message
metal
method
middle
midnight
milk
million
mimic
mind
minimum
minor
minute
miracle
mirror
misery
miss
mistake
mix
mixed
mixture
mobile
model
modify
mom
moment
monitor
monkey
monster
month
moon
moral
more
morning
mosquito
mother
motion
motor
mountain
mouse
move
movie
much
muffin
mule
multiply
muscle
museum
mushroom
music
must
mutual
myself
mystery
myth
naive
name
napkin
narrow
nasty
nation
nature
near
neck
need
negative
neglect
neither
nephew
nerve
nest
net
network
neutral
never
news
next
nice
night
noble
noise
nominee
noodle
normal
north
nose
notable
note
nothing
notice
novel
now
nuclear
number
nurse
nut
oak
obey
object
oblige
obscure
observe
obtain
obvious
occur
ocean
october
odor
off
offer
office
often
oil
okay
old
olive
olympic
omit
once
one
onion
online
only
open
opera
opinion
oppose
option
orange
orbit
orchard
order
ordinary
organ
orient
original
orphan
ostrich
other
outdoor
outer
output
outside
oval
oven
over
own
owner
oxygen
oyster
ozone
pact
paddle
page
pair
palace
palm
panda
panel
panic
panther
paper
parade
parent
park
parrot
party
pass
patch
path
patient
patrol
pattern
pause
pave
payment
peace
peanut
pear
peasant
pelican
pen
penalty
pencil
people
pepper
perfect
permit
person
pet
phone
photo
phrase
physical
piano
picnic
picture
piece
pig
pigeon
pill
pilot
pink
pioneer
pipe
pistol
pitch
pizza
place
planet
plastic
plate
play
please
pledge
pluck
plug
plunge
poem
poet
point
polar
pole
police
pond
pony
pool
popular
portion
position
possible
post
potato
pottery
poverty
powder
power
practice
praise
predict
prefer
prepare
present
pretty
prevent
price
pride
primary
print
priority
prison
private
prize
problem
process
produce
profit
program
project
promote
proof
property
prosper
protect
proud
provide
public
pudding
pull
pulp
pulse
pumpkin
punch
pupil
puppy
purchase
purity
purpose
purse
push
put
puzzle
pyramid
quality
quantum
quarter
question
quick
quit
quiz
quote
rabbit
raccoon
race
rack
radar
radio
rail
rain
raise
rally
ramp
ranch
random
range
rapid
rare
rate
rather
raven
raw
razor
ready
real
reason
rebel
rebuild
recall
receive
recipe
record
recycle
reduce
reflect
reform
refuse
region
regret
regular
reject
relax
release
relief
rely
remain
remember
remind
remove
render
renew
rent
reopen
repair
repeat
replace
report
require
rescue
resemble
resist
resource
response
result
retire
retreat
return
reunion
reveal
review
reward
rhythm
rib
ribbon
rice
rich
ride
ridge
rifle
right
rigid
ring
riot
ripple
risk
ritual
rival
river
road
roast
robot
robust
rocket
romance
roof
rookie
room
rose
rotate
rough
round
route
royal
rubber
rude
rug
rule
run
runway
rural
sad
saddle
sadness
safe
sail
salad
salmon
salon
salt
salute
same
sample
sand
satisfy
satoshi
sauce
sausage
save
say
scale
scan
scare
scatter
scene
scheme
school
science
scissors
scorpion
scout
scrap
screen
script
scrub
sea
search
season
seat
second
secret
section
security
seed
seek
segment
select
sell
seminar
senior
sense
sentence
series
service
session
settle
setup
seven
shadow
shaft
shallow
share
shed
shell
sheriff
shield
shift
shine
ship
shiver
shock
shoe
shoot
shop
short
shoulder
shove
shrimp
shrug
shuffle
shy
sibling
sick
side
siege
sight
sign
silent
silk
silly
silver
similar
simple
since
sing
siren
sister
situate
six
size
skate
sketch
ski
skill
skin
skirt
skull
slab
slam
sleep
slender
slice
slide
slight
slim
slogan
slot
slow
slush
small
smart
smile
smoke
smooth
snack
snake
snap
sniff
snow
soap
soccer
social
sock
soda
soft
solar
soldier
solid
solution
solve
someone
song
soon
sorry
sort
soul
sound
soup
source
south
space
spare
spatial
spawn
speak
special
speed
spell
spend
sphere
spice
spider
spike
spin
spirit
split
spoil
sponsor
spoon
sport
spot
spray
spread
spring
spy
square
squeeze
squirrel
stable
stadium
staff
stage
stairs
stamp
stand
start
state
stay
steak
steel
stem
step
stereo
stick
still
sting
stock
stomach
stone
stool
story
stove
strategy
street
strike
strong
struggle
student
stuff
stumble
style
subject
submit
subway
success
such
sudden
suffer
sugar
suggest
suit
summer
sun
sunny
sunset
super
supply
supreme
sure
surface
surge
surprise
surround
survey
suspect
sustain
swallow
swamp
swap
swarm
swear
sweet
swift
swim
swing
switch
sword
symbol
symptom
syrup
system
table
tackle
tag
tail
talent
talk
tank
tape
target
task
taste
tattoo
taxi
teach
team
tell
ten
tenant
tennis
tent
term
test
text
thank
that
theme
then
theory
there
they
thing
this
thought
three
thrive
throw
thumb
thunder
ticket
tide
tiger
tilt
timber
time
tiny
tip
tired
tissue
title
toast
tobacco
today
toddler
toe
together
toilet
token
tomato
tomorrow
tone
tongue
tonight
tool
tooth
top
topic
topple
torch
tornado
tortoise
toss
total
tourist
toward
tower
town
toy
track
trade
traffic
tragic
train
transfer
trap
trash
travel
tray
treat
tree
trend
trial
tribe
trick
trigger
trim
trip
trophy
trouble
truck
true
truly
trumpet
trust
truth
try
tube
tuition
tumble
tuna
tunnel
turkey
turn
turtle
twelve
twenty
twice
twin
twist
two
type
typical
ugly
umbrella
unable
unaware
uncle
uncover
under
undo
unfair
unfold
unhappy
uniform
unique
unit
universe
unknown
unlock
until
unusual
unveil
update
upgrade
uphold
upon
upper
upset
urban
urge
usage
use
used
useful
useless
usual
utility
vacant
vacuum
vague
valid
valley
valve
van
vanish
vapor
various
vast
vault
vehicle
velvet
vendor
venture
venue
verb
verify
version
very
vessel
veteran
viable
vibrant
vicious
victory
video
view
village
vintage
violin
virtual
virus
visa
visit
visual
vital
vivid
vocal
voice
void
volcano
volume
vote
voyage
wage
wagon
wait
walk
wall
walnut
want
warfare
warm
warrior
wash
wasp
waste
water
wave
way
wealth
weapon
wear
weasel
weather
web
wedding
weekend
weird
welcome
west
wet
whale
what
wheat
wheel
when
where
whip
whisper
wide
width
wife
wild
will
win
window
wine
wing
wink
winner
winter
wire
wisdom
wise
wish
witness
wolf
woman
wonder
wood
wool
word
work
world
worry
worth
wrap
wreck
wrestle
wrist
write
wrong
yard
year
yellow
you
young
youth
zebra
zero
zone
zoo`.split(`
`);var Sf=256,Hk=Sf/8;var Po=e=>{let t=e.trim().split(/\s+/).join(" ").toLowerCase();return md(t,gd)};var re=(e,t)=>`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="${e}">${t}</svg>`,Id={reply:re("Reply",'<path d="m9 7-5 5 5 5M4 12h11a5 5 0 0 1 5 5v1"/>'),"reply-all":re("Reply all",'<path d="m6 7-5 5 5 5m6-10-5 5 5 5M7 12h8a5 5 0 0 1 5 5v1"/>'),forward:re("Forward",'<path d="m15 7 5 5-5 5m5-5H9a5 5 0 0 0-5 5v1"/>'),refresh:re("Refresh",'<path d="M20 4v6h-6M4 20v-6h6M5.4 8A7 7 0 0 1 17 5l3 5M4 14l3 5a7 7 0 0 0 11.6-3"/>'),close:re("Close",'<path d="m6 6 12 12M18 6 6 18"/>'),more:re("More actions",'<circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/>'),attach:re("Attach file",'<path d="m21 12-8 8a6 6 0 0 1-8.5-8.5L13 3a4 4 0 0 1 5.7 5.7l-8.5 8.5a2 2 0 0 1-2.8-2.8l7.8-7.8"/>'),send:re("Send",'<path d="m21 3-7 18-4-7-7-4 18-7ZM10 14 21 3"/>'),save:re("Save",'<path d="M5 3h12l4 4v14H3V3h2Z"/><path d="M7 3v6h10V3M7 21v-8h10v8"/>'),download:re("Download",'<path d="M12 3v12m-5-5 5 5 5-5M5 16v4h14v-4"/>'),copy:re("Copy",'<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M15 9V4H4v11h5"/>'),mailbox:re("Save to mailbox",'<path d="M12 3v9m-3-3 3 3 3-3M5 8l-2 6v6h18v-6l-2-6M3 14h5l2 3h4l2-3h5"/>'),schedule:re("Schedule",'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),rename:re("Rename",'<path d="m4 16 12-12 4 4L8 20l-5 1 1-5ZM14 6l4 4"/>'),delete:re("Delete",'<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>'),undo:re("Undo",'<path d="M3 4v6h6M3 10a8 8 0 1 1 1 8"/>'),link:re("Connect",'<path d="M10 13a4 4 0 0 0 6 0l4-4a4 4 0 0 0-6-6l-2 2M14 11a4 4 0 0 0-6 0l-4 4a4 4 0 0 0 6 6l2-2"/>'),unlink:re("Disconnect",'<path d="m7 7-3 3a5 5 0 0 0 7 7l2-2m4 2 3-3a5 5 0 0 0-7-7l-2 2M3 3l18 18"/>'),"sign-out":re("Sign out",'<path d="M10 4H4v16h6m5-12 4 4-4 4m-6-4h10"/>'),"external-link":re("Open external page",'<path d="M14 3h7v7m0-7L11 13m-1-8H3v16h16v-7"/>'),"shield-alert":re("Key security",'<path d="m12 3-8 3v6c0 4.5 8 9 8 9s8-4.5 8-9V6l-8-3ZM12 8v5m0 4h.01"/>'),upload:re("Upload",'<path d="M12 15V3m-5 5 5-5 5 5M5 16v4h14v-4"/>'),pause:re("Pause",'<path d="M8 5v14m8-14v14"/>')};var No=Object.freeze({...Id,asset:'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" role="img" aria-label="Assets"><path d="M12 3 3 7.5v9L12 21l9-4.5v-9L12 3Z"/><path d="m3 7.5 9 4.5 9-4.5M12 12v9M7.5 5.25l9 4.5"/></svg>',action:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32" role="img" aria-label="Recued">
  <title>Recued toolbar action</title>
  <desc>Recued toolbar mark \u2014 three descending lines inside a rounded teal tile.</desc>
  <rect x="4" y="4" width="24" height="24" rx="6" fill="#0e7490"/>
  <rect x="10" y="10" width="12" height="2" rx="1" fill="#fff"/>
  <rect x="10" y="16" width="10" height="2" rx="1" fill="#fff"/>
  <rect x="10" y="22" width="7" height="2" rx="1" fill="#fff"/>
</svg>`,check:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Success">
  <title>Success</title>
  <desc>Checkmark. Used to indicate successful runs and ok checklist items.</desc>
  <polyline points="5 12 10 17 19 6"/>
</svg>`,info:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Info">
  <title>Info</title>
  <desc>Information glyph. Reserved for inline hints and tooltips.</desc>
  <circle cx="12" cy="12" r="9"/>
  <line x1="12" y1="11" x2="12" y2="17"/>
  <circle cx="12" cy="8" r="0.5" fill="currentColor"/>
</svg>`,logo:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 128 128" role="img" aria-label="Recued">
  <title>Recued</title>
  <desc>Recued mark \u2014 three descending lines inside a rounded teal tile.</desc>
  <rect x="16" y="16" width="96" height="96" rx="24" fill="#0e7490"/>
  <rect x="40" y="40" width="48" height="8" rx="4" fill="#fff"/>
  <rect x="40" y="64" width="40" height="8" rx="4" fill="#fff"/>
  <rect x="40" y="88" width="28" height="8" rx="4" fill="#fff"/>
</svg>`,marketplace:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Marketplace">
  <title>Marketplace</title>
  <desc>Storefront icon. Used on "Browse marketplace" links.</desc>
  <path d="M3 9l1 -4h16l1 4"/>
  <path d="M3 9v11h18v-11"/>
  <path d="M3 9a2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 4 0 2 2 0 0 0 2 0"/>
  <path d="M10 20v-5h4v5"/>
</svg>`,play:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" role="img" aria-label="Run recipe">
  <title>Run recipe</title>
  <desc>Play triangle. Used on recipe Run buttons in popup and sidebar.</desc>
  <path d="M8 5v14l11-7z"/>
</svg>`,settings:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Settings">
  <title>Settings</title>
  <desc>Gear icon. Used by popup/sidebar/options for the settings button.</desc>
  <circle cx="12" cy="12" r="3"/>
  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>
</svg>`,spinner:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Running">
  <title>Running</title>
  <desc>Spinner ring for in-progress recipe runs. CSS animation supplies the rotation.</desc>
  <path d="M21 12a9 9 0 0 1-9 9"/>
</svg>`,x:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Failure">
  <title>Failure</title>
  <desc>X mark. Used to indicate failed runs and issue checklist items.</desc>
  <line x1="6" y1="6" x2="18" y2="18"/>
  <line x1="18" y1="6" x2="6" y2="18"/>
</svg>`,task:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Tasks">
  <title>Tasks</title>
  <desc>Checklist with two checkboxes. Used in primary nav for the task work-entity surface.</desc>
  <rect x="4" y="4" width="6" height="6" rx="1.25"/>
  <polyline points="5.5 7 7 8.5 9 5.5"/>
  <rect x="4" y="14" width="6" height="6" rx="1.25"/>
  <line x1="13" y1="6.5" x2="20" y2="6.5"/>
  <line x1="13" y1="9.5" x2="18" y2="9.5"/>
  <line x1="13" y1="16.5" x2="20" y2="16.5"/>
  <line x1="13" y1="19.5" x2="18" y2="19.5"/>
</svg>`,note:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Notes">
  <title>Notes</title>
  <desc>Document with text lines and a folded corner. Used in primary nav for the note work-entity surface.</desc>
  <path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/>
  <polyline points="14 3 14 9 20 9"/>
  <line x1="8" y1="13" x2="16" y2="13"/>
  <line x1="8" y1="16" x2="14" y2="16"/>
</svg>`,booking:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Bookings">
  <title>Bookings</title>
  <desc>Calendar with a check. Used in primary nav for the booking work-entity surface.</desc>
  <rect x="3" y="5" width="18" height="16" rx="2"/>
  <line x1="3" y1="10" x2="21" y2="10"/>
  <line x1="8" y1="3" x2="8" y2="7"/>
  <line x1="16" y1="3" x2="16" y2="7"/>
  <path d="M9 14.5l2 2 4-4"/>
</svg>`,commitment:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Commitments">
  <title>Commitments</title>
  <desc>Handshake \u2014 two clasping forearms. Used in primary nav for the commitment work-entity surface.</desc>
  <path d="M3 12l4-4 3 3 3-3 4 4-3 3-3-3-3 3z"/>
  <line x1="3" y1="12" x2="3" y2="15"/>
  <line x1="21" y1="12" x2="21" y2="15"/>
</svg>`,project:`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" role="img" aria-label="Projects">
  <title>Projects</title>
  <desc>Folder with a small tab. Used in primary nav for the project work-entity surface.</desc>
  <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
  <line x1="3" y1="11" x2="21" y2="11"/>
</svg>`}),Cf=Object.freeze(Object.keys(No).sort());var Do=`
.rx-btn {
  padding: 8px 16px;
  border: 1px solid var(--border-strong, var(--border));
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
  font-weight: 500;
  font-family: inherit;
  background: var(--bg);
  color: var(--fg);
  line-height: 1.2;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
.rx-btn[hidden] { display: none; }
.rx-btn > svg { flex-shrink: 0; }
.rx-btn:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--surface-sunk); }
.rx-btn:disabled, .rx-btn[aria-disabled="true"] { cursor: not-allowed; opacity: 0.5; }

.rx-btn-xs { padding: 4px 10px; font-size: 11px; }
.rx-btn-sm { padding: 6px 12px; font-size: 12px; }
.rx-btn-md { /* default sizing already on .rx-btn */ }
.rx-btn-icon-only { padding: 8px; min-width: 36px; min-height: 36px; }

.rx-btn-primary {
  background: var(--accent);
  color: var(--on-accent);
  border-color: var(--accent);
}
.rx-btn-primary:hover:not(:disabled):not([aria-disabled="true"]) {
  background: var(--accent-dim, var(--accent));
  color: var(--on-accent);
}

.rx-btn-secondary { /* inherits .rx-btn defaults */ }

.rx-btn-danger {
  color: var(--danger);
  border-color: var(--danger);
  background: var(--surface);
}
.rx-btn-danger:hover:not(:disabled):not([aria-disabled="true"]) { background: var(--danger-weak); }

/* "text" means text: quiet at rest (no border), so a repeated inline
 * destructive action (per-row Remove / Revoke) doesn't shout N times per
 * page. The border and wash return on hover to confirm the target.
 * Promoted from identical scoped overrides in both kitchen editors. */
.rx-btn-danger-text {
  color: var(--danger);
  border-color: transparent;
  background: transparent;
}
.rx-btn-danger-text:hover:not(:disabled):not([aria-disabled="true"]) {
  background: var(--danger-weak);
  border-color: var(--danger);
}

.rx-btn-link {
  background: none;
  border: none;
  padding: 0;
  color: var(--accent);
  font-size: 12px;
  cursor: pointer;
  text-decoration: underline;
  line-height: inherit;
  height: auto;
}
.rx-btn-link:hover:not(:disabled):not([aria-disabled="true"]) { opacity: 0.8; background: none; }

.rx-btn-oauth {
  width: 100%;
  padding: 10px 16px;
  border: 1px solid var(--border);
  border-radius: 6px;
  background: var(--surface);
  color: var(--fg);
}
.rx-btn-oauth:hover:not(:disabled):not([aria-disabled="true"]) {
  background: var(--surface-sunk);
  border-color: var(--border-strong, var(--border));
}
`;var Lo=`
.rx-section {
  margin-top: 24px;
  padding-top: 20px;
  border-top: 1px solid var(--border);
}
.rx-section:first-child {
  margin-top: 0;
  padding-top: 0;
  border-top: none;
}
.rx-section-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--fg);
  margin: 0 0 8px;
  letter-spacing: -0.2px;
}
.rx-section-hint {
  margin: 0 0 12px;
  font-size: 12px;
  color: var(--fg-muted);
  line-height: 1.5;
}
.rx-subsection { margin-top: 14px; }
.rx-subsection-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--fg);
  margin: 12px 0 8px;
}
`;var Mo=`
.rx-flash {
  padding: 10px 14px;
  border-radius: 6px;
  margin-bottom: 18px;
  font-size: 13px;
  line-height: 1.4;
  border: 1px solid transparent;
}
.rx-flash-ok {
  background: var(--surface-sunk);
  color: var(--fg);
  border-color: var(--border);
}
.rx-flash-error {
  background: var(--danger-weak);
  color: var(--danger);
  border-color: var(--danger);
}
.rx-flash-warn {
  background: var(--surface-sunk);
  color: var(--fg);
  border-color: var(--border-strong);
}
`;var Bo=`
.rx-form-row {
  display: grid;
  grid-template-columns: 120px 1fr;
  gap: 12px;
  align-items: center;
  margin-bottom: 12px;
}
.rx-form-row:last-of-type { margin-bottom: 0; }
.rx-form-row > label {
  font-size: 13px;
  color: var(--fg-dim, var(--fg-muted));
  font-weight: 500;
}
.rx-form-row-inline {
  display: flex;
  align-items: center;
  gap: 8px;
  grid-template-columns: none;
}

.rx-input {
  width: 100%;
  padding: 8px 10px;
  border: 1px solid var(--border-strong, var(--border));
  border-radius: 4px;
  font-size: 13px;
  font-family: inherit;
  background: var(--bg);
  color: var(--fg);
}
.rx-input:focus { outline: none; border-color: var(--accent); }
.rx-input:disabled { opacity: 0.6; cursor: not-allowed; }

.rx-select {
  width: 100%;
  padding: 8px 10px;
  border: 1px solid var(--border-strong, var(--border));
  border-radius: 4px;
  font-size: 13px;
  font-family: inherit;
  background: var(--bg);
  color: var(--fg);
}
.rx-select:focus { outline: none; border-color: var(--accent); }
.rx-select:disabled { opacity: 0.6; cursor: not-allowed; }

.rx-checkbox-row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 12px;
  color: var(--fg);
  cursor: pointer;
}
.rx-checkbox { accent-color: var(--accent); }

.rx-field-hint {
  margin: 4px 0 0;
  font-size: 11px;
  color: var(--fg-muted);
  line-height: 1.4;
  grid-column: 1 / -1;
}
`;var Uo=`
.rx-dot {
  display: inline-block;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  margin-right: 6px;
  vertical-align: middle;
  background: var(--border);
}
.rx-dot-ok,      .rx-dot-online,  .rx-dot-active     { background: var(--fg); }
.rx-dot-idle,    .rx-dot-configured                  { background: var(--fg-muted); }
.rx-dot-off,     .rx-dot-offline                     { background: var(--danger); }
.rx-dot-none                                         { background: var(--border); }

.rx-badge {
  display: inline-block;
  font-size: 10px;
  padding: 1px 8px;
  border-radius: 10px;
  font-weight: 600;
  line-height: 1.6;
  background: var(--surface-sunk);
  color: var(--fg-muted);
  border: 1px solid transparent;
}
.rx-badge-upper {
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.rx-badge-neutral { background: var(--surface-sunk); color: var(--fg-muted); }
.rx-badge-ok      { background: var(--surface-sunk); color: var(--fg); }
.rx-badge-idle    { background: var(--surface-sunk); color: var(--fg-muted); }
.rx-badge-off     { background: var(--danger-weak); color: var(--danger); }
.rx-badge-accent  { background: var(--accent-weak); color: var(--accent); }
`;var Fo=`
.rx-code {
  font-family: ui-monospace, 'SF Mono', Menlo, Consolas, monospace;
  font-size: 11px;
  background: var(--bg-code, var(--surface-sunk));
  color: var(--fg);
  padding: 1px 5px;
  border-radius: 3px;
  word-break: break-all;
}
.rx-code-block {
  display: block;
  font-family: ui-monospace, 'SF Mono', Menlo, Consolas, monospace;
  font-size: 12px;
  background: var(--bg-code, var(--surface-sunk));
  color: var(--fg);
  padding: 10px 12px;
  border: 1px solid var(--border);
  border-radius: 4px;
  white-space: pre-wrap;
  word-break: break-word;
  margin: 6px 0;
}
`;var Ko=`
.rx-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
  color: var(--fg);
}
.rx-table caption,
.rx-table-caption {
  caption-side: top;
  text-align: left;
  font-size: 11px;
  color: var(--fg-muted);
  padding: 0 0 6px;
  text-transform: uppercase;
  letter-spacing: 0.3px;
}
.rx-table thead th {
  text-align: left;
  font-size: 10px;
  font-weight: 500;
  color: var(--fg-muted);
  text-transform: uppercase;
  letter-spacing: 0.3px;
  padding: 4px 8px 4px 0;
  border-bottom: 1px solid var(--border);
}
.rx-table tbody td {
  padding: 6px 8px 6px 0;
  border-bottom: 1px solid var(--border);
  vertical-align: top;
}
.rx-table tbody tr:last-child td { border-bottom: none; }
.rx-td-right  { text-align: right; }
.rx-td-center { text-align: center; }
.rx-table-empty {
  margin: 0;
  font-size: 12px;
  color: var(--fg-muted);
  font-style: italic;
}
`;var Ho=`
.rx-action-bar {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
}
.rx-action-bar-start   { justify-content: flex-start; }
.rx-action-bar-end     { justify-content: flex-end; }
.rx-action-bar-center  { justify-content: center; }
.rx-action-bar-between { justify-content: space-between; }

.rx-action-bar-gap-4   { gap: 4px; }
.rx-action-bar-gap-6   { gap: 6px; }
.rx-action-bar-gap-8   { gap: 8px; }
.rx-action-bar-gap-10  { gap: 10px; }
.rx-action-bar-gap-12  { gap: 12px; }

.rx-action-bar-bordered {
  margin-top: 12px;
  padding-top: 12px;
  border-top: 1px solid var(--border);
}
`;var Vo=`
.rx-msg {
  margin: 4px 0 0;
  font-size: 12px;
  line-height: 1.4;
}
.rx-msg-error { color: var(--danger); }
.rx-msg-warn  { color: var(--fg); }
.rx-msg-ok    { color: var(--fg); }
.rx-msg-hint  { color: var(--fg-muted); }
`;var Go=`
.rx-panel {
  padding: 14px;
  border: 1px solid var(--border);
  border-radius: 6px;
  background: var(--bg);
  font-size: 13px;
  line-height: 1.5;
}
.rx-panel-compact { padding: 8px 12px; border-radius: 4px; font-size: 12px; }
.rx-panel-title {
  margin: 0 0 8px;
  font-size: 13px;
  font-weight: 600;
  color: var(--fg);
}
.rx-panel > *:last-child { margin-bottom: 0; }

.rx-panel-neutral { /* inherits .rx-panel defaults */ }

.rx-panel-warn {
  border-color: var(--border-strong);
}

.rx-panel-danger {
  border-color: var(--danger);
  background: var(--danger-weak);
}
.rx-panel-danger .rx-panel-title { color: var(--danger); }

.rx-panel-info {
  border-color: var(--accent);
  background: var(--accent-weak);
}
.rx-panel-info .rx-panel-title { color: var(--accent); }
`;var jo=`
.rx-empty-hint {
  color: var(--fg-muted, var(--fg));
  opacity: 0.7;
  font-size: 13px;
  margin: 0;
  padding: 8px 0;
}
`;var If=`
:root {
  --bg-soft: var(--surface-sunk);
  --accent-soft: var(--accent-weak);
  --accent-dim: var(--accent);
  --fail: var(--danger);
  --fail-soft: var(--danger-weak);
  --ok: var(--fg);
  --ok-soft: var(--surface-sunk);
  --warn: var(--fg);
  --warn-soft: var(--surface-sunk);
  --warning: var(--warn);
  --bg-code: var(--surface-sunk);
  --fg-dim: var(--fg-muted);
  --panel-bg: var(--surface);
  --font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
  --mono: var(--font-mono);
  --rx-bg: var(--surface);
  --rx-fg: var(--fg);
  --rx-muted: var(--fg-muted);
  --rx-divider: var(--border);
  --rx-input-bg: var(--surface);
  --rx-hover-bg: var(--surface-sunk);
  --rx-chip-bg: var(--surface-sunk);
  --rx-accent: var(--accent);
  --rx-accent-soft: var(--accent-weak);
  --rx-warning-fg: var(--fg);
  --rx-warning-bg: var(--surface-sunk);
  --rx-error-fg: var(--danger);
  --rx-error-bg: var(--danger-weak);
  --rx-error-border: var(--danger);
  --color-border: var(--border);
  --color-warning: var(--danger);
  --color-text-secondary: var(--fg-muted);
  --color-input-bg: var(--surface);
  --color-chip-bg: var(--surface-sunk);
  --color-chip-fg: inherit;
  --color-object-bg: transparent;
  --color-union-variant-bg: transparent;
}
`,kf=[If,Do,Lo,Mo,Bo,Uo,Fo,Ko,Ho,Vo,Go,jo].join(`
`);var Lt={invalid_code:"That pairing code is wrong, has run out, or has been used. Get a new one from the server terminal.",recovery_key_invalid:"Those words do not match what your server has. Check what you wrote down and type them again.",bad_request:"Your server said no. Check what you typed and try again.",server_not_configured:"This server is not ready to verify a recovery key. Ask the person who runs it to check the server logs and configuration, then restart Recued before trying again. A fresh pairing code will not fix this server setup problem.",instance_revoked:"This device was removed from your server, so it can\u2019t re-use its old identity. Clear this browser from Settings (or use a different one) to pair again as a new device.",realm_directory_conflict:"Your server\u2019s data directory already holds another realm, and one directory can hold only one. Point this server at its own data directory, then pair again.",encryption_enrollment_busy:"Your server is busy finishing encryption setup \u2014 usually a moment. Wait, then try again with a fresh pairing code.",database_encryption_not_configured:"Your server can\u2019t turn on at-rest encryption. Check the server logs; this is a server-side setup problem, not something to fix from here.",not_found:"Something answered at that address, but it is not a Recued server, or it is too old to pair like this. Check the address.",payload_too_large:"Your server said that was too big. Check what you typed. A recovery key is 24 words.",internal_error:"Your server hit an internal error while pairing. Check its logs, then try again.",too_many_attempts:"Your server has had too many wrong codes or recovery keys, so it is not checking any for a minute. Wait a minute, then try again."},Hn="Your server refused the pairing request.";var kd=e=>{if(typeof e!="string")return null;let n=e.replace(/[\u0000-\u001F\u007F-\u009F]+/g," ").replace(/\s+/g," ").trim();return n.length===0?null:n.length<=280?n:`${n.slice(0,279).trimEnd()}\u2026`},vd=e=>Object.prototype.hasOwnProperty.call(Lt,e),Wo=(e,t)=>vd(e)?{code:e,copy:Lt[e],serverSaid:null,tailored:!0}:{code:e,copy:Hn,serverSaid:kd(t),tailored:!1};var xf={pair_code_input_no_server_url:"Enter the URL your recued-server is reachable at.",pair_code_input_insecure_server_url:"A public server must use https:// \u2014 a plaintext http:// address would expose your pairing code and bearer. Use https:// (or http:// only for localhost / your LAN).",pair_code_input_no_input:"Enter your 24-word recovery key, or a pairing code from the server terminal, or both.",pair_code_input_invalid_recovery_key:"That doesn't look like a valid 24-word recovery key. Check for typos or missing words.",pair_code_input_transport_failed:"Couldn't reach your recued-server. Check the URL and that the server is running, then try again.",pair_code_input_server_unknown_error:"The server returned an unexpected response. Check the URL and try again.",pair_code_input_server_refused:Hn,pair_code_input_handoff_failed:"This bridge didn't finish setting up. Select Finish pairing to try again. You don't need a new pairing code.",pair_code_input_handoff_final:"This bridge couldn't finish pairing, and trying again won't change that.",pair_code_input_handoff_lost:"This bridge no longer has the pairing your server accepted, so it can't finish it. Pair again with a new code from your server.",pair_code_input_worker_failed:"Recued Bridge's background service didn't respond. Try again in a moment.",pair_code_input_sign_in_refused:"Your server stopped accepting this bridge, so it was unpaired. That happens when the bridge is removed from the server's devices, or the server is reset. Pair it again with a new code from your server.",pair_code_input_disconnected_untold:"This bridge is disconnected, but your server could not be reached to be told, so it still lists this bridge under Devices. Remove it there, or pair this bridge again with a new code from your server.",...Lt};var Pf=e=>e.trim().replace(/\/$/,""),$o=async e=>{let t=Pf(e.serverUrl??"");if(t.length===0)return{ok:!1,error:"pair_code_input_no_server_url"};if(Nn(t))return{ok:!1,error:"pair_code_input_insecure_server_url"};let n=e.code?.trim()??"",r=e.recoveryKey?.trim()??"";if(!n&&!r)return{ok:!1,error:"pair_code_input_no_input"};if(r&&!Po(r))return{ok:!1,error:"pair_code_input_invalid_recovery_key"};let o={};n&&(o.code=n),r&&(o.recoveryKey=r),e.instanceId&&(o.instanceId=e.instanceId),e.displayName&&(o.displayName=e.displayName),o.clientKind="bridge";let a=e.fetch??globalThis.fetch,i;try{i=await a(`${t}/auth/pair`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(o)})}catch(p){return{ok:!1,error:"pair_code_input_transport_failed",detail:p instanceof Error?p.message:String(p)}}let s;try{s=await i.json()}catch{return{ok:!1,error:"pair_code_input_server_unknown_error",detail:`HTTP ${i.status} (non-JSON response)`}}if(i.ok){let p=s;if(typeof p.token!="string"||p.token.length===0)return{ok:!1,error:"pair_code_input_server_unknown_error",detail:"response missing realm token"};let l={ok:!0,token:p.token};return typeof p.token_id=="string"&&p.token_id.length>0&&(l.token_id=p.token_id),typeof p.bearer=="string"&&p.bearer.length>0&&(l.bearer=p.bearer,l.token=p.bearer),p.passport!==void 0&&(l.passport=p.passport),typeof p.serverId=="string"&&p.serverId.length>0&&(l.serverId=p.serverId),l}let c=s?.error,d=c&&typeof c.code=="string"?c.code:"",f=c&&typeof c.message=="string"?c.message:"",u=Wo(d,f);if(u.tailored){let p={ok:!1,error:u.code};return f&&(p.detail=f),p}let m={ok:!1,error:"pair_code_input_server_refused",detail:f||`HTTP ${i.status}`};return u.serverSaid&&(m.serverSaid=u.serverSaid),d&&(m.serverCode=d),m};var Nf=e=>{if(!e||typeof e!="object")return!1;let t=e;return t.type==="rpc_result"&&typeof t.request_id=="string"},qo=class extends Error{constructor(n,r,o,a){super(r);this.code=n;this.status=o;this.details=a}code;status;details},Df=()=>{let e=globalThis.crypto;return e&&typeof e.randomUUID=="function"?e.randomUUID():`bridge-passport-${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`},wd=e=>{let t=e.timeout_ms??3e4,n=e.randomId??Df;return async({server_url:r,bearer:o})=>{let a=n(),i=!1,s,c,d=new Promise((_,y)=>{s=_,c=y});d.catch(()=>{});let f=setTimeout(()=>{i||(i=!0,c(new Error(`passport.fetch: server did not respond within ${t}ms`)))},t),u=null,m=null,p=null,l=null;try{let _=[e.wsTransportFactory.open({url:r,auth_bearer:o}).then(E=>({kind:"open",transport:E})).catch(E=>({kind:"open-error",err:E})),d.then(()=>({kind:"settled"}),()=>({kind:"settled"}))],y=await Promise.race(_);if(y.kind==="open-error")return i||(i=!0,c(y.err)),await d;if(y.kind==="settled")return _[0].then(T=>{if(T.kind==="open")try{T.transport.close()}catch{}}).catch(()=>{}),await d;if(u=y.transport,i)return await d;if(m=u.onMessage(E=>{if(i)return;let T;try{T=JSON.parse(E)}catch{return}if(Nf(T)&&T.request_id===a){if(T.error){i=!0,c(new qo(T.error.code,T.error.message,T.error.status,T.error.details));return}if(T.result===void 0){i=!0,c(new Error(`passport.fetch: rpc_result for ${a} carried neither result nor error`));return}i=!0,s(T.result)}}),p=u.onClose(E=>{i||(i=!0,c(new Error(`passport.fetch: WebSocket closed before rpc_result (code=${E.code}${E.reason?` reason="${E.reason}"`:""})`)))}),l=u.onError(E=>{i||(i=!0,c(new Error(`passport.fetch: WebSocket error before rpc_result: ${E instanceof Error?E.message:String(E)}`)))}),i)return await d;let g={type:"rpc",request_id:a,method:"passport.fetch",args:{}};return u.send(JSON.stringify(g)),await d}finally{if(clearTimeout(f),m&&m(),p&&p(),l&&l(),u)try{u.close()}catch{}}}};var Bt="bridge_pending_pair",Mt=e=>typeof e=="string"&&e.length>0,Lf=e=>{if(!e||typeof e!="object")return null;let t=e;return!Mt(t.serverUrl)||!Mt(t.token)||t.token_id!==void 0&&!Mt(t.token_id)||t.serverId!==void 0&&!Mt(t.serverId)||t.instanceId!==void 0&&!Mt(t.instanceId)?null:{serverUrl:t.serverUrl,token:t.token,...t.token_id!==void 0?{token_id:t.token_id}:{},...t.passport!==void 0?{passport:t.passport}:{},...t.serverId!==void 0?{serverId:t.serverId}:{},...t.instanceId!==void 0?{instanceId:t.instanceId}:{}}},Yo=e=>({async load(){let t=await e.get([Bt]);return Lf(t[Bt])},async save(t){await e.set({[Bt]:{serverUrl:t.serverUrl,token:t.token,...t.token_id!==void 0?{token_id:t.token_id}:{},...t.passport!==void 0?{passport:t.passport}:{},...t.serverId!==void 0?{serverId:t.serverId}:{},...t.instanceId!==void 0?{instanceId:t.instanceId}:{}}})},async clear(){await e.remove([Bt])}});var Vn="bridge_sign_in_refused",Xo=e=>{let t;try{t=new URL(e)}catch{return""}let n=t.protocol==="wss:"?"https:":t.protocol==="ws:"?"http:":null;if(n===null)return"";let r=t.pathname.replace(/\/ws\/?$/u,"").replace(/\/+$/u,"");return`${n}//${t.host}${r}`},Mf=e=>{if(!e||typeof e!="object")return null;let t=e;return typeof t.serverUrl=="string"&&t.serverUrl.length>0&&typeof t.at=="number"?{serverUrl:t.serverUrl,at:t.at,...t.kind==="disconnected"?{kind:"disconnected"}:{}}:null},Od=e=>({async load(){return Mf((await e.get([Vn]))[Vn])},async save(t){await e.set({[Vn]:{serverUrl:t.serverUrl,at:t.at,...t.kind!==void 0?{kind:t.kind}:{}}})},async clear(){await e.remove([Vn])}}),xd=()=>{let e=null;return{async load(){return e},async save(t){e={...t}},async clear(){e=null}}};var Gn="recued.bridge.pair",zo=e=>{if(!e||typeof e!="object")return null;let t=e;if(typeof t.serverUrl!="string")return null;let n=i=>typeof i=="string"&&i.length>0?i:void 0,r=n(t.code),o=n(t.recoveryKey),a=n(t.displayName);return{serverUrl:t.serverUrl,...r!==void 0?{code:r}:{},...o!==void 0?{recoveryKey:o}:{},...a!==void 0?{displayName:a}:{}}},Bf=()=>{let e=globalThis.crypto;return e&&typeof e.randomUUID=="function"?e.randomUUID():`bridge-${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`},Pd=e=>e instanceof Error?e.message:String(e),Qo=e=>{let t=null,n=null,r=async()=>{if(n!==null)return n;try{return await e.pendingStore?.load()??null}catch{return null}},o=async u=>{n=u;try{await e.pendingStore?.save(u)}catch{}},a=async()=>{n=null;try{await e.pendingStore?.clear()}catch{}},i=async()=>{try{return await e.readPaired()}catch{return null}},s=async()=>{await e.refusals?.clear().catch(()=>{});try{await e.onPaired?.()}catch{}},c=(u,m)=>{let p={serverUrl:u},l=m(p).catch(_=>({ok:!1,kind:"error",detail:Pd(_)})).finally(()=>{t?.done===l&&(t=null)});return t={get serverUrl(){return p.serverUrl},done:l},l},d=()=>t===null?null:{ok:!1,kind:"busy",serverUrl:t.serverUrl},f=async u=>{let m;try{m=await e.finalize(u)}catch(p){m={ok:!1,error:"pair_completion_persist_failed",detail:`finalize crashed: ${Pd(p)}`}}return m.ok?(await a(),await s(),{ok:!0,serverUrl:u.serverUrl}):td.has(m.error)?(await a(),{ok:!1,kind:"final",error:m.error,...m.detail?{detail:m.detail}:{}}):{ok:!1,kind:"accepted",serverUrl:u.serverUrl,reason:m.error,...m.detail?{detail:m.detail}:{}}};return{async status(){if(t!==null)return{state:"pairing",serverUrl:t.serverUrl};let u=await i();if(u!==null)return{state:"paired",serverUrl:u.serverUrl};let m=await r();if(m!==null)return{state:"accepted",serverUrl:m.serverUrl};let p=await e.refusals?.load().catch(()=>null);return p?p.kind==="disconnected"?{state:"unpaired",disconnected:{serverUrl:p.serverUrl}}:{state:"unpaired",refused:{serverUrl:p.serverUrl}}:{state:"unpaired"}},async wait(){return t===null?null:t.done},start(u){let m=d();return m?Promise.resolve(m):c(u.serverUrl,async()=>{let p=await i();if(p!==null)return{ok:!1,kind:"paired",serverUrl:p.serverUrl};let l=await r();if(l!==null)return{ok:!1,kind:"accepted",serverUrl:l.serverUrl};let _=(e.mintInstanceId??Bf)(),y=u.code?.trim()??"",g=await e.submit({serverUrl:u.serverUrl,...y.length>0?{code:y}:{},...u.recoveryKey?{recoveryKey:u.recoveryKey}:{},...u.displayName?{displayName:u.displayName}:{},instanceId:_});if(!g.ok)return{ok:!1,kind:"refused",error:g.error,...g.detail?{detail:g.detail}:{},...g.serverSaid?{serverSaid:g.serverSaid}:{},...g.serverCode?{serverCode:g.serverCode}:{}};let E={serverUrl:u.serverUrl,token:g.token,...g.token_id!==void 0?{token_id:g.token_id}:{},...g.passport!==void 0?{passport:g.passport}:{},...g.serverId!==void 0?{serverId:g.serverId}:{},instanceId:_};return await o(E),f(E)})},finish(){let u=d();return u?Promise.resolve(u):c(n?.serverUrl??"",async m=>{let p=await r();return p===null?{ok:!1,kind:"nothing_to_finish"}:(m.serverUrl=p.serverUrl,n=p,f(p))})},async abandon(){return t!==null?{ok:!1}:(await a(),{ok:!0})}}};var Nd=3e4,Uf=()=>{let e=globalThis.crypto;return e&&typeof e.randomUUID=="function"?e.randomUUID():`rpc-${Date.now().toString(36)}-${Math.floor(Math.random()*1e9).toString(36)}`},Ff=e=>{if(!e||typeof e!="object")return!1;let t=e;return t.type==="rpc_result"&&typeof t.request_id=="string"},Kf=(e,t)=>e?typeof e.code!="string"||typeof e.message!="string"?new me("rpc_unknown","rpc reply carried malformed error envelope",void 0,t):new me(e.code,e.message,e.status,t,e.details):new me("rpc_unknown","rpc reply carried no error envelope",void 0,t),Jo=e=>{let t=e.default_timeout_ms??Nd,n=e.randomId??Uf,r=mn(),o=!1;return{call:((s,c,d)=>{if(o)return Promise.reject(new me("transport_disposed","bridge rpc conn is disposed",void 0,s));let f=c??{},u=n(),m=d?.timeout??t;return new Promise((p,l)=>{let _=I=>{let k=r.get(u);k&&(r.delete(u),k.reject(I))},g=setTimeout(()=>{_(new me("timeout",`bridge rpc: method '${s}' did not respond within ${m}ms`,void 0,s))},m),E=()=>{_(new me("aborted",`bridge rpc: method '${s}' aborted by caller`,void 0,s))};if(d?.signal){if(d.signal.aborted){clearTimeout(g),l(new me("aborted",`bridge rpc: method '${s}' aborted before send`,void 0,s));return}d.signal.addEventListener("abort",E,{once:!0})}r.set(u,{method:s,request_id:u,resolve:I=>{d?.signal&&d.signal.removeEventListener("abort",E),p(I)},reject:I=>{d?.signal&&d.signal.removeEventListener("abort",E),l(I)},timeout:g});let T={type:"rpc",request_id:u,method:s,args:f};try{e.send(T)}catch(I){let k=r.get(u);if(!k)return;r.delete(u),k.reject(new me("transport",I instanceof Error?I.message:String(I),void 0,s))}})}),dispatchInbound:s=>{if(!Ff(s))return;let c=r.get(s.request_id);if(c){if(r.delete(s.request_id),s.error){c.reject(Kf(s.error,c.method));return}c.resolve(s.result)}},pendingCount:()=>r.size(),dispose:()=>{if(!o){o=!0;for(let s of[...r.values()])r.delete(s.request_id),s.reject(new me("transport_disposed","bridge rpc conn is disposed",void 0,s.method))}}}};var Zo=["execution","notification.ask","notification.ask_closed","notification.bridge_mode_changed","notification.notify"],Hf=e=>{if(!e||typeof e!="object")return!1;let t=e;return typeof t.kind=="string"&&Gr.has(t.kind)},ei=()=>{let e=new Map,t=new Set;return{on(n,r){let o=e.get(n);return o||(o=new Set,e.set(n,o)),o.add(r),()=>{o?.delete(r),o&&o.size===0&&e.delete(n)}},onAny(n){return t.add(n),()=>t.delete(n)},dispatch(n){if(!Hf(n))return;let r=e.get(n.kind);if(r)for(let o of[...r])try{o(n)}catch{}for(let o of[...t])try{o(n)}catch{}},size(n){if(n===void 0){let r=t.size;for(let o of e.values())r+=o.size;return r}return e.get(n)?.size??0}}};var ti=e=>{let t=e?.now??Date.now,n=Math.max(1,e?.cap??50),r=[],o=[],a=[],i=(s,c)=>[c,...s].slice(0,n);return{apply(s){switch(s.kind){case"notification.notify":{o=i(o,{id:`notify:${s.cursor}`,...s.title!==void 0?{title:s.title}:{},text:s.text,fired_at:t()});return}case"notification.ask":{if(s.reminder===!0)return;let c={ask_id:s.ask_id,...s.title!==void 0?{title:s.title}:{},text:s.text,options:s.options.map(d=>({id:d.id,label:d.label})),created_at:t(),...s.link_url!==void 0?{link_url:s.link_url}:{},...s.note_prompt!==void 0?{note_prompt:s.note_prompt}:{},...s.body!==void 0?{body:s.body}:{},...s.resource_review?{resource_review:s.resource_review}:{}};a=i(a.filter(d=>d.ask_id!==s.ask_id),c);return}case"notification.ask_closed":{a=a.filter(c=>c.ask_id!==s.ask_id);return}case"execution":{(s.op==="complete"||s.op==="error")&&(r=i(r.filter(c=>c.run_id!==s.run_id),{run_id:s.run_id,recipe_id:s.recipe_id,status:s.op==="complete"?"ok":"error",started_at:t(),duration_ms:null}));return}default:return}},seed(s){r=s.recipe_results.slice(0,n),o=s.notifications.slice(0,n),a=s.approvals.slice(0,n)},snapshot:()=>({recipe_results:r,notifications:o,approvals:a}),reset(){r=[],o=[],a=[]}}};var Vf=async e=>{let t=await e.chromePermissions.getAll()??{},n=await e.snapshot({granted_origins:[...t.origins??[]]}),r={software_version:n.software_version,chrome_version:n.chrome_version,permissions_granted:[...t.permissions??[]],granted_origins:[...t.origins??[]],offscreen_supported:n.offscreen_supported??!1,alarms_supported:n.alarms_supported??!1,supported_actions:[...mr]};return n.user_agent!==void 0&&(r.user_agent=n.user_agent),n.dom_documents!==void 0&&(r.dom_documents=n.dom_documents),r},Dd=e=>{let t=!1,n=null,r=!1,o=async()=>{if(!t)try{let c=await Vf({chromePermissions:e.chromePermissions,snapshot:e.snapshot});if(t)return;await Promise.resolve(e.push(c))}catch(c){if(t)return;e.onPushError?.(c)}},a=()=>t?Promise.resolve():n?(r=!0,n):(n=(async()=>{try{await o()}finally{n=null,r&&!t?(r=!1,a()):r=!1}})(),n),i=()=>{a()},s=()=>{a()};return e.chromePermissions.onAdded.addListener(i),e.chromePermissions.onRemoved.addListener(s),{pushNow:a,stop(){t||(t=!0,e.chromePermissions.onAdded.removeListener(i),e.chromePermissions.onRemoved.removeListener(s))}}};var Ld="recued.bridge.picker.result",Md=e=>{let t=e.trim();return t.length>0&&!t.includes("{{")},ni=e=>{if(typeof e!="object"||e===null)return!1;let t=e;if(t.type!==Ld)return!1;let n=t.result;if(typeof n!="object"||n===null)return!1;if(n.status==="cancelled")return!0;if(n.status!=="picked")return!1;let r=n;return typeof r.selector=="string"&&Md(r.selector)&&typeof r.page_url=="string"&&(r.sample_text===null||typeof r.sample_text=="string")};var ri=e=>{let t;try{t=new URL(e)}catch{return null}if(t.protocol!=="http:"&&t.protocol!=="https:")return null;let n=`${t.protocol}//${t.host}`,o=t.pathname.split("/").filter(c=>c.length>0).slice(0,-1),a=o.length>0?`/${o.join("/")}/*`:"/*",i=`${n}${a}`;if(!i.includes(" ")&&rn(i))return i;let s=`${n}/*`;return!s.includes(" ")&&rn(s)?s:null};var Gf=5e3,Bd=e=>e.server_url!==null&&e.webclient_token!==null&&e.server_public_key!==null,oi=(e,t)=>{let n={kind:"result",result:t};try{e.send(JSON.stringify(n))}catch{}},jf=e=>{let t=!1,n=new WeakMap,r=async()=>{if(!t){t=!0;try{for(;;){let o=e.queue.dequeue();if(!o)return;let a={signalled:!1};e.inflight.set(o.command_id,a);try{let i=await fo(o,{bridge_version:e.bridgeVersion,now:e.now,executor:e.executor,grants:e.grants,idempotency:n.get(o)??e.getIdempotencyCache()},a);oi(e.ws,i.result)}catch{}finally{n.delete(o),e.inflight.delete(o.command_id),e.queue.complete(o.command_id)}}}finally{t=!1}}};return o=>{if(o.kind==="command"){let i=o.command,s=e.queue.enqueue(i);if(!s.ok){oi(e.ws,{command_id:i.command_id,status:"rejected",error:{code:"queue_full",message:`bridge: command queue full (${s.depth}/${s.max} pending)`},duration_ms:0,bridge_version:e.bridgeVersion,idempotency_key_seen:!1});return}n.set(i,e.getIdempotencyCache()),r();return}if(o.kind==="cancel"){let i=o.cancel.command_id,s=e.queue.cancel(i);if(s==="running"){let c=e.inflight.get(i);c&&(c.signalled=!0)}else s==="dropped"&&oi(e.ws,{command_id:i,status:"cancelled",duration_ms:0,bridge_version:e.bridgeVersion,idempotency_key_seen:!1});return}let a=(i,s,c)=>{try{let d={kind:"notification_receipt",receipt:{request_id:i,outcome:s,...c?{notification_id:c}:{}}};e.ws.send(JSON.stringify(d))}catch{}};if(o.kind==="notification.probe"){e.notificationPermission().then(i=>a(o.request_id,i==="granted"?"ready":"denied"),()=>a(o.request_id,"failed"));return}if(o.kind==="notification.clear"){e.notificationClear(o.notification_id).then(()=>a(o.request_id,"cleared",o.notification_id),()=>a(o.request_id,"failed",o.notification_id));return}if(o.kind==="notification"){let i=o.receipt_request_id;(async()=>{try{if(i&&await e.notificationPermission()!=="granted"){a(i,"denied",o.notification.notification_id);return}await e.notificationDispatch(o.notification),i&&a(i,"displayed",o.notification.notification_id)}catch{i&&a(i,"failed",o.notification.notification_id)}})();return}}},Wf=e=>t=>{let n;try{n=JSON.parse(t)}catch{return}if(!n||typeof n!="object")return;let r=n,o=r.type==="rpc_result",a=r.type==="server_event",i=typeof r.kind=="string";if(!((o||a)&&i)){if(o){e.rpcConn.dispatchInbound(n);return}if(a){e.dispatchServerEvent(r.event);return}if(i){e.envelopeRouter(n);return}}},Ud=async e=>{let t=e.now??(()=>Date.now());e.swLifecycle.onInstall(()=>{Promise.resolve(e.swLifecycle.skipWaiting())}),e.swLifecycle.onActivate(b=>{b.waitUntil(Promise.resolve(e.swLifecycle.claim()))});let n=uo(e.chromeStorage),r=e.queue??go(),o=Wl(()=>e.chromeRuntimeSendMessage?.({type:"recued.bridge.side-panel.diagnostics-invalidated"})),a=b=>jl(b,()=>{e.chromeRuntimeSendMessage&&o.request()}),i=a(e.idempotency??_o({now:t})),s=new Map,c=b=>{if(e.idempotency||!e.idempotencyForPair)return i;let h=JSON.stringify([b.server_public_key,b.token_id]),S=s.get(h);return S||(S=a(e.idempotencyForPair(b)),s.set(h,S)),S},d=b=>{i=c(b)},f=async()=>{let{server_url:b,server_public_key:h,webclient_token:S}=await n.inspect();b!==null&&h!==null&&S!==null&&d({server_public_key:h,token_id:S.token_id})},u=e.grants??kt(),m=()=>To({local:n,queue:r,idempotency:i,grants:u,now:t,...e.idempotencyForPair&&!e.idempotency?{idempotencyForPair:c}:{}}),p=e.pairPassportInvoker??wd({wsTransportFactory:e.wsTransportFactory}),l=async()=>{throw new Error("the paired runtime is not wired yet")},_=async()=>{let[b,h,S]=await Promise.all([n.get("server_url"),n.get("webclient_token"),n.get("server_public_key")]);return b!==null&&h!==null&&S!==null?{serverUrl:b}:null},y=e.chromeStorageSession?Od(e.chromeStorageSession):xd(),g=Qo({submit:b=>$o({...b,...e.fetch?{fetch:e.fetch}:{}}),finalize:b=>nd({serverUrl:b.serverUrl,bearer:b.token,...b.token_id!==void 0?{token_id:b.token_id}:{},...b.passport!==void 0?{passport:b.passport}:{},...b.instanceId!==void 0?{instanceId:b.instanceId}:{},localStore:n,tokenStore:e.tokenStore,invokePassportFetch:p,now:t,...e.pairCompletionMintTokenId?{mintTokenId:e.pairCompletionMintTokenId}:{}}),readPaired:_,...e.chromeStorageSession?{pendingStore:Yo(e.chromeStorageSession)}:{},onPaired:()=>l(),...e.pairMintInstanceId?{mintInstanceId:e.pairMintInstanceId}:{},refusals:y}),E=null,T=null,I=null,k=null,C=ti({now:t}),x=null,F=0,M=()=>{if(e.chromeRuntimeSendMessage)try{let b=e.chromeRuntimeSendMessage({type:"recued.bridge.side-panel.bridge-mode-invalidated"});b&&typeof b.catch=="function"&&b.catch(()=>{})}catch{}},G=()=>{if(e.chromeRuntimeSendMessage)try{let b=e.chromeRuntimeSendMessage({type:"recued.bridge.side-panel.server-connected"});b&&typeof b.catch=="function"&&b.catch(()=>{})}catch{}},U=b=>{if(e.chromeRuntimeSendMessage)try{let h=e.chromeRuntimeSendMessage({type:"recued.bridge.side-panel.picker-result",...b});h&&typeof h.catch=="function"&&h.catch(()=>{})}catch{}};e.chromeRuntimeOnMessage.addListener((b,h,S)=>{let w=b;if(w&&w.type==="recued.bridge.inspect")return m().catch(()=>null).then(N=>{try{S(N)}catch{}}),!0;if(w&&w.type==="recued.bridge.side-panel.disconnect")return(async()=>{if(k===null){S({ok:!1,error:"bridge_not_ready"});return}try{S({ok:!0,...await k()})}catch(N){S({ok:!1,error:N instanceof Error?N.message:String(N)})}})(),!0;if(w&&w.type==="recued.bridge.side-panel.fetch-status")return(async()=>{if(E===null){let N=null;try{N=await _()}catch{N=null}S({ok:!1,error:N!==null?"bridge_connecting":"bridge_not_paired"});return}if(T!==null&&!T()){S({ok:!1,error:"bridge_connecting"});return}try{let N=await E.call("system.status");S({ok:!0,status:N.status})}catch(N){S({ok:!1,error:N instanceof Error?N.message:String(N)})}})(),!0;if(w&&w.type==="recued.bridge.side-panel.fetch-bridge-mode")return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}try{let N=await E.call("notifications.my_bridge_mode");S({ok:!0,modes:N.modes})}catch(N){S({ok:!1,error:N instanceof Error?N.message:String(N)})}})(),!0;if(w&&w.type==="recued.bridge.side-panel.fetch-frames")return S({ok:!0,...C.snapshot()}),!0;if(w&&w.type==="recued.bridge.side-panel.fetch-history")return(async()=>(x!==null&&await x(),S({ok:!0,...C.snapshot()})))(),!0;if(w&&w.type==="recued.bridge.side-panel.submit-answer"){let N=b,H=typeof N.ask_id=="string"?N.ask_id:"",V=typeof N.option_id=="string"?N.option_id:"";return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}if(H===""||V===""){S({ok:!1,error:"submit-answer requires string ask_id + option_id"});return}try{await E.call("notification.submitAnswer",{ask_id:H,option_id:V,...typeof N.note=="string"&&N.note!==""?{note:N.note}:{}}),x!==null&&await x(),S({ok:!0,...C.snapshot()})}catch(q){S({ok:!1,error:q instanceof Error?q.message:String(q)})}})(),!0}if(w&&w.type==="recued.bridge.side-panel.fetch-active")return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}try{let N=await E.call("execution.active",{});S({ok:!0,entries:N.entries,lanes:N.lanes})}catch(N){S({ok:!1,error:N instanceof Error?N.message:String(N)})}})(),!0;if(w&&w.type==="recued.bridge.side-panel.execution-kill"){let N=b,H=typeof N.run_id=="string"?N.run_id:"";return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}if(H===""){S({ok:!1,error:"execution-kill requires a string run_id"});return}try{let V=await E.call("execution.kill",{run_id:H});S({ok:!0,status:V.status})}catch(V){S({ok:!1,error:V instanceof Error?V.message:String(V)})}})(),!0}if(w&&w.type==="recued.bridge.side-panel.execution-cancel"){let N=b,H=typeof N.queued_call_id=="string"?N.queued_call_id:"";return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}if(H===""){S({ok:!1,error:"execution-cancel requires a string queued_call_id"});return}try{let V=await E.call("execution.cancel",{queued_call_id:H});S({ok:!0,status:V.status})}catch(V){S({ok:!1,error:V instanceof Error?V.message:String(V)})}})(),!0}if(w&&w.type==="recued.bridge.side-panel.execution-promote"){let N=b,H=typeof N.queued_call_id=="string"?N.queued_call_id:"";return(async()=>{if(E===null){S({ok:!1,error:"bridge_not_paired"});return}if(H===""){S({ok:!1,error:"execution-promote requires a string queued_call_id"});return}try{let V=await E.call("execution.promote",{queued_call_id:H});S({ok:!0,status:V.status})}catch(V){S({ok:!1,error:V instanceof Error?V.message:String(V)})}})(),!0}if(w&&w.type==="recued.bridge.side-panel.launch-picker")return(async()=>{if(!e.pickerInjector){S({ok:!1,reason:"picker_unavailable"});return}S(await e.pickerInjector.injectIntoActiveTab())})(),!0;if(ni(b)){let N=b.result;return N.status!=="picked"?(S({ok:!0,cancelled:!0}),!1):((async()=>{if(E===null){U({ok:!1,error:"bridge_not_paired"}),S({ok:!1,error:"bridge_not_paired"});return}let H=ri(N.page_url);if(H===null){U({ok:!1,error:"unsupported_page"}),S({ok:!1,error:"unsupported_page"});return}try{let V=await E.call("triggers.createElementWatch",{url:H,selector:N.selector});U({ok:!0,created:V.created,recipe_id:V.recipe_id,url:H}),S({ok:!0,created:V.created,recipe_id:V.recipe_id})}catch(V){let q=V instanceof Error?V.message:String(V);U({ok:!1,error:q}),S({ok:!1,error:q})}})(),!0)}if(w&&w.type===Gn){let N=w;return(async()=>{try{switch(N.op){case"status":S(await g.status());return;case"wait":S(await g.wait());return;case"start":{let H=zo(N.input);S(H===null?{ok:!1,kind:"error",detail:"pair start is missing the server address"}:await g.start(H));return}case"finish":S(await g.finish());return;case"abandon":S(await g.abandon());return;default:S({ok:!1,kind:"error",detail:`unknown pair op: ${String(N.op)}`})}}catch(H){S({ok:!1,kind:"error",detail:`pairing crashed: ${H instanceof Error?H.message:String(H)}`})}})(),!0}}),await f();let j=await m(),P=j,D=null,K=null,O=async(b,h)=>{console.warn(`bridge.service-worker-bootstrap: the server refused this bridge's sign-in (close ${String(h.code)}); unpairing it so it can be paired again`),await y.save({serverUrl:Xo(b),at:t()}).catch(()=>{}),await K?.catch(()=>{});let S=D;D=null,await S?.stop().catch(()=>{}),await n.clear().catch(w=>{console.warn("bridge.service-worker-bootstrap: clearing the refused pairing failed",w)})};k=async()=>{let b=P.local,h=typeof b.server_url=="string"?b.server_url:"",S=b.pair_metadata?.instance_id,w=E,N=!1;if(w!==null&&typeof S=="string"&&S!==""&&T?.()===!0){let V=!1,q=new Promise(Q=>{I=()=>{V=!0,Q()}}),Y=w.call("pair.revoke",{instance_id:S}).then(()=>!0,()=>!1),W=new Promise(Q=>{setTimeout(()=>Q(!1),Gf)}),Z=await Promise.race([Y,q.then(()=>!0),W]);!Z&&!V&&await Promise.race([q,new Promise(Q=>{setTimeout(Q,1e3)})]),N=Z||V}await K?.catch(()=>{});let H=D;return D=null,await H?.stop().catch(()=>{}),I=null,!N&&h!==""&&await y.save({serverUrl:Xo(h),at:t(),kind:"disconnected"}).catch(()=>{}),await n.clear(),{told_server:N}};let B=async b=>{let h=b.local,S=new Map;if(h.server_url===null||h.webclient_token===null||h.server_public_key===null)throw new Error("bridge.service-worker-entry: paired discriminant failed post-narrow");let w=h.server_url,N=h.server_public_key,H=h.webclient_token.token_id,V=e.chromeNotifications?Ao(e.chromeNotifications,{default_icon_url:e.defaultNotificationIconUrl},$=>{if($.url)try{Promise.resolve(e.openNotificationUrl?.($.url)).catch(()=>{})}catch{}},{server_url:w}):null,q=null,Y=null,W=null,Z=null,Q=ho({url:w,resolveBearer:async()=>{let $=await n.get("webclient_token");if($===null)throw console.warn("bridge.service-worker-bootstrap: webclient_token missing on resolveBearer (post-paired-boot)"),new Te("webclient_token missing on resolveBearer");try{let pe=await e.tokenStore.unwrap($,{token_id:$.token_id,server_public_key:N});return d({server_public_key:N,token_id:$.token_id}),`${$.token_id}.${pe}`}catch(pe){throw console.warn("bridge.service-worker-bootstrap: bearer unwrap failed",pe),pe}},factory:e.wsTransportFactory,handlers:{onMessage($){q?.($)},onSignInRefused($){if(I!==null){I();return}O(w,$)},onConnected(){Y?.pushNow(),W?.(),x?.(),M(),Z?.forgetSwitch(),G()}}}),ie=jf({ws:Q,bridgeVersion:e.bridgeVersion,now:t,executor:e.actionExecutor,grants:u,getIdempotencyCache:()=>i,queue:r,notificationDispatch:V?$=>V.dispatch($):()=>{throw new Error("OS notifications are unavailable")},notificationPermission:()=>e.chromeNotifications?.getPermissionLevel?.()??Promise.resolve("denied"),notificationClear:async $=>{if(!e.chromeNotifications)throw new Error("OS notifications are unavailable");await e.chromeNotifications.clear($)},inflight:S}),z=Jo({send:$=>{Q.send(JSON.stringify($))}});E=z,T=()=>Q.isConnected(),e.chromeNotifications&&(Z=Jl({notifications:e.chromeNotifications,storage:n,icon_url:e.defaultNotificationIconUrl,readNotifySwitch:async()=>(await z.call("notifications.my_bridge_mode")).modes?.notification===!0}));let ve=ei();if(ve.onAny($=>{C.apply($),$.kind==="notification.bridge_mode_changed"&&(M(),Z?.forgetSwitch()),$.kind==="notification.ask"&&Z?.asked($),$.kind==="notification.ask_closed"&&Z?.closed($.ask_id)}),q=Wf({rpcConn:z,envelopeRouter:ie,dispatchServerEvent:$=>ve.dispatch($)}),W=()=>{jr($=>z.call("events.subscribe",$),{kinds:[...Zo]}).then(({left_out:$})=>{$.length!==0&&console.warn(`bridge.service-worker-bootstrap: this server does not send ${$.join(", ")}`)}).catch($=>{console.warn("bridge.service-worker-bootstrap: events.subscribe failed",$)})},Q.isConnected()&&W(),x=async()=>{let $=++F;try{let[pe,Yd,Xd]=await Promise.all([z.call("execution.recent",{limit:50}),z.call("notification.recent",{limit:50}),z.call("notification.pending_asks")]);if($!==F)return;C.seed({recipe_results:pe.executions.map(J=>({run_id:J.run_id,recipe_id:J.recipe_id,status:J.status==="succeeded"?"ok":J.status==="awaiting_approval"?"paused":"error",started_at:J.started_at,duration_ms:J.duration_ms,...J.error_category!==void 0?{error_category:J.error_category}:{}})),notifications:Yd.notifications.map(J=>({id:J.id,...J.title!==void 0?{title:J.title}:{},text:J.text,fired_at:J.fired_at})),approvals:Xd.asks.map(J=>({ask_id:J.ask_id,...J.title!==void 0?{title:J.title}:{},text:J.text,options:J.options.map(gi=>({id:gi.id,label:gi.label})),created_at:J.created_at,...J.link_url!==void 0?{link_url:J.link_url}:{},...J.note_prompt!==void 0?{note_prompt:J.note_prompt}:{},...J.body!==void 0?{body:J.body}:{},...J.resource_review?{resource_review:J.resource_review}:{}}))})}catch(pe){console.warn("bridge.service-worker-bootstrap: historical-view fetch failed",pe)}},Q.isConnected()&&x(),e.chromePermissions&&e.capabilityProfileSnapshot){let $=e.capabilityProfileSnapshot;Y=Dd({chromePermissions:e.chromePermissions,snapshot:$,push:async pe=>{await z.call("bridge.capabilityProfile.push",{profile:pe})},onPushError:pe=>{console.warn("bridge.service-worker-bootstrap: capability profile push failed",pe)}})}e.chromeAlarms&&e.chromeRuntimeInfo&&Eo(e.chromeAlarms,e.chromeRuntimeInfo,async()=>yo({ws:Q,idempotency:i,now:t})),await Q.start(),P=b,D={ws:Q,rpcConn:z,capabilityMonitor:Y,async stop(){Y?.stop(),z.dispose();for(let $ of S.values())$.signalled=!0;r.clear(),await Q.stop(),e.chromeAlarms&&bo(e.chromeAlarms),E=null,T=null,x=null}}},v=b=>D!==null?Promise.resolve():(K===null&&(K=B(b).finally(()=>{K=null})),K);return l=async()=>{try{await f();let b=await m();if(!Bd(b.local))throw new Error("the stored pair is incomplete");await v(b)}catch(b){console.warn("bridge.service-worker-bootstrap: the paired runtime did not start in place; reloading the extension",b),e.chromeRuntimeReload?.()}},Bd(j.local)&&await v(j),{get paired(){return D!==null},get pairSnapshot(){return P},get wsClient(){return D?.ws??null},get rpcConn(){return D?.rpcConn??null},get capabilityMonitor(){return D?.capabilityMonitor??null},async stop(){o.stop();let b=D;D=null,await b?.stop()}}};var Fd=e=>{let t=[],n=[],r=!1,o=!1,a=null,i=f=>{let u=!1;for(let m of t)try{m(f.message,f.sender,f.sendResponse)===!0&&(u=!0)}catch{}return u},s=(f,u)=>{try{f.sendResponse({ok:!1,error:"bridge_boot_failed",detail:u})}catch{}};return e.chromeRuntimeOnMessage&&e.chromeRuntimeOnMessage.addListener((f,u,m)=>{let p={message:f,sender:u,sendResponse:m};return o?(s(p,a??"bridge boot failed"),!1):r?i(p):(n.push(p),!0)}),{proxy:{addListener(f){t.push(f)},drainQueuedMessages(){if(!o)for(r=!0;n.length>0;){let f=n.shift();i(f)}}},failQueuedAfterBootRejection:f=>{if(r||o)return;let u=f instanceof Error?f.message:String(f);for(o=!0,a=u;n.length>0;){let m=n.shift();s(m,u)}}}};var Kd=e=>{e&&typeof e.catch=="function"&&e.catch(()=>{})},Hd=e=>{let t=e?.sidePanel;if(t){try{Kd(t.setPanelBehavior?.({openPanelOnActionClick:!0}))}catch{}e.action?.onClicked.addListener(n=>{let r={};typeof n.id=="number"?r.tabId=n.id:typeof n.windowId=="number"&&(r.windowId=n.windowId);try{Kd(t.open(r))}catch{}})}};var Ve="keep_signed_in",si="keep_signed_in_status",ai="recued.keep_signed_in",$f=.5,qf=1,Yf=60;var Xf=20,zf=6e4,li=/^([01]\d|2[0-3]):([0-5]\d)$/,jn=e=>{let[,t,n]=li.exec(e);return Number(t)*60+Number(n)},Qf=e=>{if(e===null||typeof e!="object")return null;let t=e;if(typeof t.until=="number"&&Number.isFinite(t.until))return{until:t.until};if(!Array.isArray(t.days)||typeof t.from!="string"||typeof t.to!="string")return null;let n=[...new Set(t.days)].filter(r=>Number.isInteger(r)&&r>=0&&r<=6).sort((r,o)=>r-o);return n.length===0||!li.test(t.from)||!li.test(t.to)||jn(t.from)>=jn(t.to)?null:{days:n,from:t.from,to:t.to}},Jf=e=>{if(e===null||typeof e!="object")return null;let t=e,n=typeof t.site=="string"?Zr(t.site):null,r=t.every_minutes;if(n===null||typeof r!="number"||!Number.isInteger(r)||r<qf||r>Yf||t.mode!=="session"&&t.mode!=="reload")return null;let o=t.window===void 0?void 0:Qf(t.window);return o===null?null:{site:n,every_minutes:r,mode:t.mode,...o!==void 0?{window:o}:{},...t.off===!0?{off:!0}:{}}},di=e=>{if(!Array.isArray(e))return[];let t=[];for(let n of e){let r=Jf(n);r!==null&&!t.some(o=>o.site===r.site)&&t.push(r)}return t.slice(0,Xf)},Zf=(e,t)=>{if(e===void 0)return!0;if("until"in e)return t.getTime()<e.until;let n=t.getHours()*60+t.getMinutes();return e.days.includes(t.getDay())&&n>=jn(e.from)&&n<jn(e.to)},eh=e=>[`*://${e}/*`,`*://*.${e}/*`],th=async()=>{try{let e=await fetch(location.href,{credentials:"include",cache:"no-store"});return await e.arrayBuffer().catch(()=>{}),{status:e.status}}catch(e){return{failed:e instanceof Error?e.message:String(e)}}},nh=()=>{for(let t of document.querySelectorAll("input, textarea, select"))if(t instanceof HTMLInputElement){if(t.type==="checkbox"||t.type==="radio"){if(t.checked!==t.defaultChecked)return!0}else if(!["hidden","submit","button","reset","image","file"].includes(t.type)&&t.value!==t.defaultValue)return!0}else if(t instanceof HTMLTextAreaElement){if(t.value!==t.defaultValue)return!0}else if(t instanceof HTMLSelectElement&&[...t.options].some(n=>n.selected!==n.defaultSelected))return!0;let e=document.activeElement;return e instanceof HTMLElement&&e.isContentEditable},rh=async(e,t)=>{let n=t.filter(r=>r.discarded!==!0);if(n.length===0)return{done:!1,said:"Chrome put its tabs to sleep, so nothing could be sent. Reloading the page keeps one awake."};for(let r of n)try{let o=await e.runInTab(r.id,th);if(o!==null&&typeof o=="object"&&typeof o.status=="number")return{done:!0,said:"Kept the session."}}catch{}return{done:!1,said:"Its page could not be reached."}},oh=async(e,t)=>{let n=await e.focusedWindow().catch(()=>null),r=0,o=0,a=0;for(let s of t){if(s.active===!0&&n!==null&&s.windowId===n){o+=1;continue}if(s.discarded!==!0&&await e.runInTab(s.id,nh).catch(()=>!1)===!0){a+=1;continue}try{await e.tabs.reload(s.id),r+=1}catch{}}let i=[...o>0?["the one you were using"]:[],...a>0?[`${a===1?"one":String(a)} holding something typed and not sent`]:[]];return r===0?{done:!1,said:i.length>0?`Left alone: ${i.join(" and ")}.`:"Its tabs could not be reloaded."}:{done:!0,said:`Reloaded ${r===1?"its tab":`${String(r)} tabs`}${i.length>0?`, leaving ${i.join(" and ")}`:""}.`}},ci=!1,ih=async e=>{if(!ci){ci=!0;try{let t=await e.storage.get([Ve,si]),n=di(t[Ve]);if(n.length===0)return;let r=await En(e.storage).catch(()=>null),o=t[si],a=o!==null&&typeof o=="object"?{...o}:{},i=e.now(),s=[];for(let d of n){if(d.off===!0)continue;let f=a[d.site]??{};if(d.window!==void 0&&"until"in d.window&&i>=d.window.until){s.push(d.site),a[d.site]={last:{at:i,what:"stopped",said:"Its hours ran out, so it stopped."}};continue}if(!Zf(d.window,new Date(i))){a[d.site]=f.last!==void 0?{last:f.last}:{};continue}if(f.next_at!==void 0&&i<f.next_at)continue;let u=e.activity();if(u.running>0||d.mode==="reload"&&i-u.last_ended_at<zf){a[d.site]={...f,last:{at:i,what:"skipped",said:"Recued was acting in the browser."}};continue}let m=i+d.every_minutes*6e4,p=(await e.tabs.query({url:eh(d.site)}).catch(()=>[])).filter(y=>typeof y.id=="number");if(p.length===0){a[d.site]={next_at:m,last:{at:i,what:"skipped",said:"No tab shows it."}};continue}let l=r===null?[]:p.filter(y=>!Ae(y.url??`https://${d.site}/`,r));if(l.length===0){a[d.site]={next_at:m,last:{at:i,what:"skipped",said:r===null?"The list of sites never to use could not be read, so nothing was done.":"Left alone: it is on your list of sites never to use."}};continue}let _=d.mode==="session"?await rh(e,l):await oh(e,l);a[d.site]=_.done?{next_at:m,last:{at:i,what:"kept",said:_.said}}:{...f,last:{at:i,what:"skipped",said:_.said}}}if(s.length===0&&JSON.stringify(a)===JSON.stringify(o??{}))return;let c={[si]:a};if(s.length>0){let d=di((await e.storage.get([Ve]))[Ve]);c[Ve]=d.map(f=>s.includes(f.site)&&f.window!==void 0&&"until"in f.window&&i>=f.window.until?{...f,off:!0}:f)}await e.storage.set(c)}finally{ci=!1}}},Vd=(e,t)=>{if(e?.alarms===void 0||e.storage?.local===void 0)return;let n=e,r={storage:n.storage.local,tabs:n.tabs,async focusedWindow(){if(n.windows===void 0)return null;let a=await n.windows.getLastFocused();return a.focused===!0&&typeof a.id=="number"?a.id:null},async runInTab(a,i){return(await n.scripting.executeScript({target:{tabId:a},func:i}))?.[0]?.result},activity:t,now:()=>Date.now()},o=async()=>{di((await n.storage.local.get([Ve]))[Ve]).some(i=>i.off!==!0)?n.alarms.create(ai,{periodInMinutes:$f}):n.alarms.clear(ai)};n.alarms.onAlarm.addListener(a=>{a.name===ai&&ih(r).catch(()=>{})}),n.storage.onChanged?.addListener((a,i)=>{i==="local"&&Ve in a&&o().catch(()=>{})}),o().catch(()=>{})};var sh=$c,ah=e=>e.url,Gd=(e={})=>{let t=e.webSocket??globalThis.WebSocket;if(!t)throw new Error("bridge.ws-transport-factory: globalThis.WebSocket unavailable \u2014 pass options.webSocket");let n=e.subprotocol??sh,r=e.buildConnectUrl??ah;return{async open({url:o,auth_bearer:a}){let i=r({url:o}),s;try{s=new t(i,[n,qc(a)])}catch(_){throw _ instanceof Error?_:new Error(`bridge.ws-transport-factory: WebSocket ctor threw \u2014 ${String(_)}`)}let c=new Set,d=new Set,f=new Set,u=_=>{let y=_?.data;if(typeof y=="string")for(let g of[...c])try{g(y)}catch{}},m=_=>{let y=_,g={code:y?.code??1006,reason:y?.reason??""};for(let E of[...d])try{E(g)}catch{}},p=()=>{let _=new Error("bridge.ws-transport-factory: WebSocket error event");for(let y of[...f])try{y(_)}catch{}};return s.addEventListener("message",u),s.addEventListener("close",m),s.addEventListener("error",p),await new Promise((_,y)=>{let g=!1,E=C=>{g||(g=!0,C())},T=()=>E(()=>_()),I=C=>{let x=C?.code;E(()=>{s.removeEventListener("message",u),s.removeEventListener("close",m),s.removeEventListener("error",p),y(new Error(`bridge.ws-transport-factory: WS closed before open (code=${x??"unknown"})`))})},k=()=>{E(()=>{s.removeEventListener("message",u),s.removeEventListener("close",m),s.removeEventListener("error",p),y(new Error("bridge.ws-transport-factory: WebSocket error before open"))})};s.addEventListener("open",T),s.addEventListener("close",I),s.addEventListener("error",k)}),{send(_){s.send(_)},close(_,y){try{s.close(_,y)}catch{}},onMessage(_){return c.add(_),()=>{c.delete(_)}},onClose(_){return d.add(_),()=>{d.delete(_)}},onError(_){return f.add(_),()=>{f.delete(_)}}}}}};var jd="recued.bridge.receipts.v1",Ge="recued.bridge.idempotency",at="recued.bridge.in_flight",ch=new Set(["ok","error","rejected","cancelled","timeout"]),Ut=e=>typeof e=="object"&&e!==null&&!Array.isArray(e),ct=e=>typeof e=="number"&&Number.isFinite(e),Wn=(e,t)=>{if(!Ut(e)||e.scope!==t||typeof e.command_id!="string"||!e.command_id||typeof e.idempotency_key!="string"||!e.idempotency_key||!ct(e.started_at))throw new Error("bridge.receipts: invalid in-flight marker; refusing another dispatch");return{command_id:e.command_id,idempotency_key:e.idempotency_key,started_at:e.started_at}},st=(e,t)=>{if(!Ut(e)||typeof e.scope!="string"||t!==void 0&&e.scope!==t||typeof e.command_id!="string"||!e.command_id||typeof e.idempotency_key!="string"||!e.idempotency_key||!ct(e.stored_at)||!ct(e.expires_at)||e.expires_at!==e.stored_at+je||!Ut(e.result)||e.result.command_id!==e.command_id||typeof e.result.status!="string"||!ch.has(e.result.status)||!ct(e.result.duration_ms)||e.result.duration_ms<0||typeof e.result.bridge_version!="string"||typeof e.result.idempotency_key_seen!="boolean"||e.result.outputs!==void 0&&!Ut(e.result.outputs)||e.result.error!==void 0&&(!Ut(e.result.error)||typeof e.result.error.code!="string"||typeof e.result.error.message!="string"))throw new Error("bridge.receipts: invalid stored receipt; refusing to treat it as a cache miss");return{command_id:e.command_id,idempotency_key:e.idempotency_key,stored_at:e.stored_at,expires_at:e.expires_at,result:e.result}},lh=(e,t)=>new Promise((n,r)=>{if(!e){r(new Error("bridge.receipts: IndexedDB is unavailable"));return}let o=e.open(t,5),a=!1;o.onerror=()=>{a=!0,r(o.error??new Error("bridge.receipts: database open failed"))},o.onblocked=()=>{a=!0,r(new Error("bridge.receipts: database open is blocked"))},o.onupgradeneeded=i=>{if(a){o.transaction?.abort();return}let s=o.result;if(!s.objectStoreNames.contains(Ge)){let f=s.createObjectStore(Ge,{keyPath:["scope","command_id"]});f.createIndex("by_scope","scope"),f.createIndex("by_key",["scope","idempotency_key"]),f.createIndex("by_expiry","expires_at")}let c=s.objectStoreNames.contains(at)?o.transaction.objectStore(at):s.createObjectStore(at,{keyPath:["scope","command_id"]});c.indexNames.contains("by_key")||c.createIndex("by_key",["scope","idempotency_key"],{unique:!0}),c.indexNames.contains("by_scope")||c.createIndex("by_scope","scope");let d=o.transaction.objectStore(Ge);if(i.oldVersion<5){d.indexNames.contains("by_confirmation")&&d.deleteIndex("by_confirmation"),d.createIndex("by_confirmation",["scope","confirmation","stored_at","command_id","result.status","diagnostic_error_code"]);let f=d.openCursor();f.onsuccess=()=>{let u=f.result;if(!u)return;let m;try{m=st(u.value)}catch{u.continue();return}u.update({...u.value,confirmation:Ke(m.result)?1:0,diagnostic_error_code:wt(m.result.status,m.result.error?.code).error_code??""}),u.continue()}}},o.onsuccess=()=>{let i=o.result;if(a){i.close();return}i.onversionchange=()=>i.close(),n(i)}}),ui=e=>{if(!e.scope.server_public_key||!e.scope.token_id)throw new Error("bridge.receipts: an explicit pair scope is required");let t=JSON.stringify([e.scope.server_public_key,e.scope.token_id]),n=e.indexedDB??globalThis.indexedDB,r=e.database_name??jd,o=e.now??Date.now,a=!1,i=()=>{if(a)throw new Error("bridge.receipts: a prior receipt write failed; refusing another dispatch")},s=async(p,l="readwrite")=>{let _=await lh(n,r);try{return await new Promise((y,g)=>{let E=_.transaction([Ge,at],l,l==="readwrite"?{durability:"strict"}:{}),T,I,k=C=>{I=C;try{E.abort()}catch{g(C)}};E.onerror=()=>{I??=E.error??new Error("bridge.receipts: transaction request failed")},E.onabort=()=>g(I??E.error??new Error("bridge.receipts: transaction aborted")),E.oncomplete=()=>{I?g(I):y(T)};try{p(E.objectStore(Ge),C=>{T=C},k,E.objectStore(at))}catch(C){k(C)}})}finally{_.close()}},c=(p,l,_,y)=>{let g=p.get([t,l]);g.onsuccess=()=>{try{if(g.result===void 0){_(null);return}let E=st(g.result,t);E.expires_at<=o()?(p.delete([t,l]),_(null)):_(E)}catch(E){y(E)}}},d=(p,l,_,y)=>{let g=p.index("by_key").openCursor([t,l]);g.onsuccess=()=>{try{let E=g.result;if(!E){_(null);return}let T=st(E.value,t);T.expires_at<=o()?(E.delete(),E.continue()):_(T)}catch(E){y(E)}}},f=(p,l,_,y,g)=>{let E=p.get([t,l]);E.onsuccess=()=>{try{if(E.result!==void 0){y(Wn(E.result,t));return}let T=p.index("by_key").get([t,_]);T.onsuccess=()=>{try{y(T.result===void 0?null:Wn(T.result,t))}catch(I){g(I)}}}catch(T){g(T)}}},u=(p,l,_)=>{let y=p.index("by_scope").count(t);y.onsuccess=()=>{try{let g=o()-je;if(!ct(g))throw new Error("bridge.receipts: invalid inspection time");let E=p.index("by_confirmation"),T=(G,U)=>IDBKeyRange.bound(U?[t,G,g,[]]:[t,G],[t,G,[]]),I=E.count(T(1,!0)),k=E.count(T(0,!0)),C=E.count(T(1,!1)),x=E.count(T(0,!1)),F=[],M=E.openKeyCursor(T(1,!0),"prev");M.onsuccess=()=>{try{if(y.result!==C.result+x.result)throw new Error("bridge.receipts: incomplete receipt metadata");let G=M.result;if(G){let U=G.key;if(!Array.isArray(U)||U.length!==6||U[0]!==t||U[1]!==1||!ct(U[2])||!Number.isFinite(new Date(U[2]).getTime())||typeof U[3]!="string"||!U[3]||U[4]!=="ok"&&U[4]!=="error"&&U[4]!=="rejected"||typeof U[5]!="string"||xn(U[5]))throw new Error("bridge.receipts: invalid receipt metadata");if(F.push({command_id:U[3],stored_at:U[2],status:U[4],...wt(U[4],U[5])}),F.length<On){G.continue();return}}l({count:I.result+k.result,confirmed:{count:I.result,entries:F}})}catch(G){_(G)}}}catch(g){_(g)}}},m=(p,l,_)=>{let y=p.index("by_scope"),g=y.count(t),E=y.getAll(t,wn);E.onsuccess=()=>{try{l({count:g.result,entries:E.result.map(T=>{let I=Wn(T,t);return{command_id:I.command_id,started_at:I.started_at}})})}catch(T){_(T)}}};return{async claim(p,l){if(i(),typeof p!="string"||!p||typeof l!="string"||!l)throw new Error("bridge.receipts: command identity is required");return s((_,y,g,E)=>{c(_,p,T=>{if(T){y({kind:"completed",entry:T});return}d(_,l,I=>{if(I){y({kind:"completed",entry:I});return}f(E,p,l,k=>{if(k){y({kind:"in_flight",entry:k});return}let C={command_id:p,idempotency_key:l,started_at:o()};Wn({scope:t,...C},t),E.add({scope:t,...C}),y({kind:"claimed",entry:C})},g)},g)},g)})},async store(p,l,_){i();try{let y=o(),g={scope:t,command_id:p,idempotency_key:l,result:_,stored_at:y,expires_at:y+je,confirmation:Ke(_)?1:0,diagnostic_error_code:wt(_.status,_.error?.code).error_code??""};st(g,t),await s((E,T,I,k)=>{f(k,p,l,C=>{if(C&&(C.command_id!==p||C.idempotency_key!==l))throw new Error("bridge.receipts: cannot finish another command's in-flight marker");E.put(g),C&&Ke(_)&&k.delete([t,p]),T(void 0)},I)})}catch(y){throw a=!0,y}try{Promise.resolve(e.onStored?.(o())).catch(()=>{})}catch{}},async lookup(p){return i(),s((l,_,y)=>c(l,p,_,y))},async lookupByIdempotencyKey(p){return i(),s((l,_,y)=>d(l,p,_,y))},async sweepExpired(p){return s((l,_,y)=>{let g=0,E=l.index("by_expiry").openCursor();E.onsuccess=()=>{try{let T=E.result;if(!T||st(T.value).expires_at>p){_(g);return}T.delete(),g++,T.continue()}catch(T){y(T)}}})},async list(){return s((p,l,_)=>{let y=[],g=p.index("by_scope").openCursor(t);g.onsuccess=()=>{try{let E=g.result;if(!E){l(y);return}let T=st(E.value,t);T.expires_at<=o()?E.delete():y.push(T),E.continue()}catch(E){_(E)}}})},async inspectReceipts(){return s((p,l,_)=>u(p,l,_),"readonly")},async inspectInFlight(){return s((p,l,_,y)=>m(y,l,_),"readonly")},async inspectDiagnostics(){return s((p,l,_,y)=>{let g={receipts:null,in_flight:null};try{u(p,E=>{g.receipts=E},()=>{})}catch{}try{m(y,E=>{g.in_flight=E},()=>{})}catch{}l(g)},"readonly")},async clear(){await s((p,l,_)=>{let y=p.index("by_scope").openCursor(t);y.onsuccess=()=>{try{let g=y.result;if(!g){l(void 0);return}g.delete(),g.continue()}catch(g){_(g)}}}),a=!1}}};var jx=new Set(Or),Wx=new Set(xr);var pi="0.0.8";var _i="icons/logo-128.png";var dh="recued.bridge.v1",$n="recued.bridge.token_key",Wd="bridge.aes_gcm_key",uh=()=>new Promise((e,t)=>{let n=indexedDB.open(dh,1);n.onerror=()=>t(n.error??new Error("bridge.service-worker-entry: IDB open failed")),n.onupgradeneeded=()=>{let r=n.result;r.objectStoreNames.contains($n)||r.createObjectStore($n)},n.onsuccess=()=>e(n.result)}),$d=(e,t,n,r)=>new Promise((o,a)=>{let i=e.transaction(t,n),s=r(i.objectStore(t)),c;s.onsuccess=()=>{c=s.result},s.onerror=()=>a(s.error??new Error(`bridge.idb: ${t} request failed`)),i.oncomplete=()=>o(c),i.onerror=()=>a(i.error??new Error(`bridge.idb: ${t} txn failed`)),i.onabort=()=>a(i.error??new Error(`bridge.idb: ${t} txn aborted`))}),Ft=null,ph=e=>Ft||(Ft=(async()=>{let t=await $d(e,$n,"readonly",r=>r.get(Wd));if(t)return t;let n=await crypto.subtle.generateKey({name:"AES-GCM",length:256},!1,["encrypt","decrypt"]);return await $d(e,$n,"readwrite",r=>r.put(n,Wd)),n})().catch(t=>{throw Ft=null,t}),Ft),_h=e=>po({resolveKey:()=>ph(e),async encrypt({key:t,iv:n,plaintext:r,additional_data:o}){let a=await crypto.subtle.encrypt({name:"AES-GCM",iv:n,additionalData:o},t,r);return new Uint8Array(a)},async decrypt({key:t,iv:n,ciphertext:r,additional_data:o}){let a=await crypto.subtle.decrypt({name:"AES-GCM",iv:n,additionalData:o},t,r);return new Uint8Array(a)}}),mh=()=>{let e=globalThis.chrome;if(!e)throw new Error("bridge.service-worker-entry: globalThis.chrome unavailable");return{executeReviewedDocument:(t,n,r)=>Nl(e.scripting,t,n,r),executeInDocument:Tt(e.scripting),listFrames:rl(e.scripting),...Ml(e.tabs,e.scripting),pageCapture:sl(e,Tt(e.scripting)),blockedSites:()=>En(e.storage.local),async tabUrl(t){try{let n=await e.tabs.get(t);return typeof n.url=="string"&&n.url!==""?n.url:null}catch{return null}},async findTabByUrlPattern(t){let r=(await e.tabs.query({url:t}))?.[0];return!r||typeof r.id!="number"||typeof r.url!="string"?null:{tab_id:r.id,url:r.url,window_id:typeof r.windowId=="number"?r.windowId:-1}},async executeScript(t,n,r){return(await e.scripting.executeScript({target:{tabId:t},func:n,args:r.value===void 0?[r.selector]:[r.selector,r.value]}))?.[0]?.result},captureVisibleTab(t){return Bl(e.tabs,t)},async showNotification(t,n){return e.notifications.create(t,{type:"basic",title:n.title,message:n.message,iconUrl:n.iconUrl})}}},gh=()=>{let e=globalThis.chrome;if(!e)throw new Error("bridge.service-worker-entry: globalThis.chrome unavailable");return{async queryActiveTab(){let n=(await e.tabs.query({active:!0,currentWindow:!0}))?.[0];return!n||typeof n.id!="number"?null:{id:n.id,url:typeof n.url=="string"?n.url:void 0}},async injectFile(t,n){await e.scripting.executeScript({target:{tabId:t},files:[n]})}}},qd=globalThis.chrome,mi=Fd({chromeRuntimeOnMessage:qd?.runtime.onMessage});Hd(qd);Vd(globalThis.chrome,()=>xt);var fh=async()=>{let e=globalThis.chrome;if(!e)return;let t=e.runtime.getURL?e.runtime.getURL(_i):_i,n={onInstall(m){self.addEventListener("install",()=>m())},onActivate(m){self.addEventListener("activate",p=>{m(p)})},skipWaiting(){return self.skipWaiting()},claim(){return self.clients.claim()}},r=await uh(),o=_h(r),a=e.permissions,i=()=>{let m=globalThis.navigator;if(!m)return"unknown";let p=m.userAgentData?.brands;if(p){for(let l of p)if(l.brand==="Chromium"||l.brand==="Google Chrome")return l.version}if(typeof m.userAgent=="string"){let l=m.userAgent.match(/Chrome\/(\d+)/);if(l)return l[1]}return"unknown"},s=globalThis.navigator?.userAgent,c=typeof globalThis.chrome?.offscreen<"u",d=typeof e.alarms<"u",f=await Ud({chromeStorage:e.storage.local,chromeRuntimeOnMessage:mi.proxy,chromeAlarms:e.alarms,chromeRuntimeInfo:{getPlatformInfo:()=>e.runtime.getPlatformInfo()},chromeRuntimeSendMessage:m=>e.runtime.sendMessage?.(m),chromeNotifications:e.notifications,openNotificationUrl:m=>e.tabs.create({url:m}),...a?{chromePermissions:a}:{},...e.runtime.reload?{chromeRuntimeReload:()=>e.runtime.reload?.()}:{},...e.storage.session?{chromeStorageSession:e.storage.session}:{},...a?{capabilityProfileSnapshot:async({granted_origins:m})=>({software_version:pi,chrome_version:i(),offscreen_supported:c,alarms_supported:d,dom_documents:{version:1,documents:await Pl(e.tabs,e.scripting,m)},...typeof s=="string"?{user_agent:s}:{}})}:{},swLifecycle:n,grants:Jc({grantedOrigins:async()=>(await a?.getAll())?.origins??[],fallback:kt()}),wsTransportFactory:Gd(),tokenStore:o,idempotencyForPair:m=>ui({scope:m,onStored:p=>e.storage.local.set({idempotency_cache:{store_name:Ge,last_flush_at:p}})}),bridgeVersion:pi,defaultNotificationIconUrl:t,actionExecutor:so(mh()),pickerInjector:co(gh())}),u=()=>{f.capabilityMonitor?.pushNow()};e.tabs.onUpdated?.addListener((m,p)=>{p?.url!==void 0&&u()}),e.tabs.onRemoved?.addListener(u),e.tabs.onReplaced?.addListener(u),mi.proxy.drainQueuedMessages()};fh().catch(e=>{mi.failQueuedAfterBootRejection(e)});
/*! Bundled license information:

@noble/hashes/utils.js:
  (*! noble-hashes - MIT License (c) 2022 Paul Miller (paulmillr.com) *)

@scure/base/index.js:
  (*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) *)

@scure/bip39/index.js:
  (*! scure-bip39 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) *)
*/
//# sourceMappingURL=service-worker.js.map
